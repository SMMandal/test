package com.tcupiot.exception;

public class ServerException extends Exception {
    public ServerException(String message) {
        super(message);
    }
}
