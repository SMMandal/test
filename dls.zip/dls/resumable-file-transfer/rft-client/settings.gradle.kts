
rootProject.name = "rft-client"

