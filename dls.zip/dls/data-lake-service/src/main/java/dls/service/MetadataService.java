package dls.service;

import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.repo.DirectoryMetaRepo;
import dls.repo.DirectoryRepo;
import dls.repo.FileMetaRepo;
import dls.repo.FileRepo;
import dls.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static dls.service.DlsServiceHelper.MAX_VAL_LEN;
import static dls.service.DlsServiceHelper.METADATA_KEY_REGEX;

@Service
public class MetadataService {

    @Autowired
    UserService uservice;
    @Autowired
    DlsServiceHelper dhelper;
    @Autowired
    FileRepo fileRepo;
    @Autowired
    DirectoryRepo directoryRepo;
    @Autowired
    FileMetaRepo fileMetaRepo;

    @Autowired
    DirectoryMetaRepo directoryMetaRepo;


    @Transactional
    public Map<String, String> insertBulkMetadata(String apiKey, String dlsKey, List<MetadataPayload> payload) throws DlsSecurityException, DlsPrivacyException {

        UserVO user = uservice.authorize(apiKey, dlsKey);

        Map<String, String> response = new HashMap<>();

        Map<String, MetadataMap> fileMap = new HashMap<>();
        Map<String, MetadataMap> directoryMap = new HashMap<>();

        payload.forEach(p -> {

            Map<String, String> metadata = new HashMap<>();

            // check metadata list
            if(null != p.metadata && !p.metadata.isEmpty()) {
                p.metadata.forEach((k,v) -> {
                    Optional.ofNullable(validateMetadata(k,v))
                            .ifPresentOrElse(err -> response.put(k, err),
                            () -> metadata.put(k,v));

                });
            }


            // check files
            if (null != p.files) {
                p.files.forEach(f -> {

                    FileVO fvo = fileRepo.findByUserAndFsPathAndDeleted(user, f, false);
                    Optional.ofNullable(fvo).ifPresentOrElse(vo -> {

                                if (!fileMap.containsKey(f)) {
                                    fileMap.put(f, new MetadataMap(vo, metadata));

                                } else {
                                    response.put(f, "duplicate file URI in payload");
                                    fileMap.remove(f);
                                }
                            },
                            () -> response.put(f, "file not found"));


                });
            }

            // check directories
            if (null != p.directories) {
                p.directories.forEach(d -> {
                    DirectoryVO dvo = directoryRepo.findByDirectoryIgnoreCaseAndDeletedAndTenantId(d, false, user.getTenant().getId());
                    Optional.ofNullable(dvo)
                            .ifPresentOrElse(vo -> {
                                        if (!directoryMap.containsKey(d)) {
                                            directoryMap.put(d, new MetadataMap(vo, metadata));
                                        } else {
                                            response.put(d, "duplicate directory path in payload");
                                            directoryMap.remove(d);
                                        }
                                    },
                                    () -> response.put(d, "directory not found"));
                });
            }

        });


        fileMap.forEach((f,m) -> {
            FileVO vo = (FileVO) m.vo;
            fileMetaRepo.deleteByFileId(vo.getId());
            vo.getMeta().clear();
            m.metadata.forEach((k,v) -> vo.getMeta().add( FileMetaVO.builder().file(vo).name(k).value(v).user(user).build()));
            fileRepo.save(vo);
            response.put(f, "file metadata updated");
        });

        directoryMap.forEach((d,m) -> {
            DirectoryVO vo = (DirectoryVO) m.vo;
            directoryMetaRepo.deleteByDirectoryIdAndIsMeta(vo.getId(), true);
            directoryMetaRepo.flush();
            vo.getDirectoryMetaVOList().clear();
            m.metadata.forEach((k,v) -> vo.getDirectoryMetaVOList().add(DirectoryMetaVO.builder().isMeta(true).name(k).value(v).directory(vo).deleted(false).user(user).build()));
            directoryRepo.save(vo);
            response.put(d, "directory metadata updated");
        });

        return response;
    }

    private String validateMetadata(String key, String value) {

        if(! key.matches(METADATA_KEY_REGEX)) {
            return "invalid metadata key";
        }
        if(value.length() > MAX_VAL_LEN) {
            return "too lengthy value";
        }
        return null;

    }

    public record MetadataPayload(List<String> files, List<String> directories, Map<String, String> metadata) {

    }

    private record MetadataMap(Object vo, Map<String, String> metadata) {}
}
