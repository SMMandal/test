package dls.service;

import com.google.common.collect.Maps;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.repo.FileMetaRepo;
import dls.repo.FileRepo;
import dls.vo.FileMetaVO;
import dls.vo.FileVO;
import dls.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class FileLockService {

	@Autowired private UserService uservice;
	@Autowired private FileRepo fileRepo;
	@Autowired private FileMetaRepo fileMetaRepo;

	public void lock(String apiKey, String dlsKey, String file, boolean hide, String comment) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		String lockVal = hide ? "RW" : "W";
		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO vo = Optional.ofNullable(fileRepo.findByFsPathAndDeleted(file, false))
				.orElseThrow(DlsNotFoundException::new);
		char [] l = vo.getLock();
		if(l != null) {
			throw new DataIntegrityViolationException("already.locked");
		}
		if(vo.getExternal()) {
			throw new DataIntegrityViolationException("outofband.lock.impossible");
		}
		if(!vo.getUploaded()) {
			throw new DataIntegrityViolationException("notuploaed.lock.impossible");
		}

		Optional.ofNullable(vo.getDirectory())
				.map(d -> Optional.ofNullable(d.getPermission())
						.map(ps -> {
							if(ps.stream().noneMatch(p ->
									Arrays.asList(p.getPermittedUser(), p.getAcquiredUser()).contains(user.getId())
								&& p.getAction().contains("W"))){
							throw new DataIntegrityViolationException("invalid.lock.permission");
		}
							return true;
						})
						.orElseThrow(() -> new DataIntegrityViolationException("invalid.lock.permission")) )
				.orElseThrow(() -> new DataIntegrityViolationException("nodirectory.lock.impossible"));

		vo.getMeta().add(FileMetaVO.builder().file(vo).name("dls:lockedOn").value(new Date().toString()).user(user).build());
		vo.getMeta().add(FileMetaVO.builder().file(vo).name("dls:lockReason").value(comment).user(user).build());
		vo.setLock(lockVal.toCharArray());
		fileRepo.save(vo);
	}

	@Transactional("transactionManager")
	public void unlock(String apiKey, String dlsKey, String file) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO vo = Optional.ofNullable(fileRepo.findByUserAndFsPathAndDeleted(user, file, false))
				.orElseThrow(DlsNotFoundException::new);
		char [] l = vo.getLock();
		if(l == null) {
			throw new DataIntegrityViolationException("already.unlocked");
		}
		List<FileMetaVO> meta = vo.getMeta();
		fileMetaRepo.deleteByIds(meta.stream().filter(m -> m.getName().startsWith("dls:lock"))
				.peek(m -> {
					if(!user.getAdmin() && m.getUser().getId() != user.getId()) {
						throw new DataIntegrityViolationException("unlock.permission.error");
					}
				})
				.map(FileMetaVO::getId)
				.collect(Collectors.toList()));
//		meta.removeIf(m -> "dls:lockedOn".equalsIgnoreCase(m.getName()));
//		meta.removeIf(m -> "dls:lockReason".equalsIgnoreCase(m.getName()));
		vo.setLock(null);
		fileRepo.save(vo);
	}



	public Map <String, String> getLockStatus(String apiKey, String dlsKey, String file) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO vo = Optional.ofNullable(fileRepo.findByUserAndFsPathAndDeleted(user, file, false))
				.orElseThrow(DlsNotFoundException::new);
		Map <String, String> response = Maps.newHashMap();
		char[] lock = vo.getLock();
		response.put("status", lock == null ? "unlocked" : "locked");
		Optional.ofNullable(lock).ifPresent(l -> {
			if(Arrays.binarySearch(l, 'R') == 0) {
				response.put("hidden", "true");
			} else {
				response.put("hidden", "false");
			}
		});

		vo.getMeta()
				.forEach(m -> {
					if(m.getName().startsWith("dls:lockedOn")) {

						response.put("locked-by", m.getUser().getDlsUser());
						response.put("locked-at", m.getValue());
					}
					if(m.getName().startsWith("dls:lockReason")) {
						response.put("reason", m.getValue());
					}
				});
		return response;
	}

	public void updateLock(String apiKey, String dlsKey, String file, boolean hide) throws DlsSecurityException,
			DlsPrivacyException, DlsNotFoundException {

		String lockVal = hide ? "RW" : "W";
		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO vo = Optional.ofNullable(fileRepo.findByFsPathAndDeleted(file, false))
				.orElseThrow(DlsNotFoundException::new);
		char [] lock = vo.getLock();
		if(lock == null) {
			throw new DataIntegrityViolationException("not.locked.hide");
		}
		List<FileMetaVO> meta = vo.getMeta();
		meta.stream().filter(m -> m.getName().startsWith("dls:lock"))
				.findFirst()
				.ifPresent(m -> {
					if(!user.getAdmin() && m.getUser().getId() != user.getId()) {
						throw new DataIntegrityViolationException("hide.permission.error");
					}
				});


		vo.setLock(lockVal.toCharArray());
		fileRepo.save(vo);
	}
}
