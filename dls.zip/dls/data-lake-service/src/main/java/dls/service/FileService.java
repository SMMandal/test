package dls.service;

import com.diffplug.common.base.Errors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import dls.bean.*;
import dls.exception.DlsBlobException;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.repo.*;
import dls.util.BundlingUtil;
import dls.vo.*;
import dls.web.FileController;
import dls.web.LinkController;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.lang3.ArrayUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.commons.CommonsMultipartFile;
import reactor.core.publisher.Flux;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static dls.bean.FileDescriptor.UploadMode.APPEND;
import static dls.exception.GlobalExceptionHandler.UPDATED;
import static dls.util.BeanValidationConstraint.*;
import static dls.service.CatalogExplorerViewService.CATALOG_TYPE_DIRECTORY;
import static dls.service.CatalogExplorerViewService.CATALOG_TYPE_FILE;


@Service
@Slf4j
public class FileService {

	private static final int KB = 1024;
	static final String DLS_ARCHIVE_TO = "dls:archivedTo";
	static final String DLS_LINEAGE = "dls:lineage";
	static final String DLS_INTERNAL = "dls:internal";
	static final String DLS_RENAMED_TO = "dls:renamedTo";
	static final String DLS_ = "dls:";
	public static final String ARCHIVE_TIMESTAMP_FORMAT = "ddMMyyyyHHmmss";
	public static final String LINKED = "linked";
	public static final String META_UPDATED = "METADATA_UPDATE";
	private static final String SAVEPOINT_UPDATE = "SAVEPOINT_UPDATE";
	@Autowired private UserService uservice;
	@Autowired private DlsServiceHelper dhelper;
	@Autowired private FileRepo fileRepo;
	@Autowired private CatalogTextSearchRepo catalogTextSearchRepo;
	@Autowired private FileMetaRepo fileMetaRepo;
	@Autowired private LinkRepo linkRepo;
	@Autowired private DirectoryRepo directoryRepo;
	@Autowired private CommentRepo commentRepo;
	@Autowired private FileServiceHelper helper;
	@Autowired private IFileManagementService dfsService;
//	@Autowired private IBlobService blobService;
//	@Autowired private MetaDataSchemaService mdsService;
	@Autowired private PermissionService permissionService;
	@Autowired private MetaDataSchemaRepo metaDataSchemaRepo;

	@Autowired private CatalogRepo catalogRepo;
	protected static Map<String,String> mapOfMetaValStandardEnf = new HashMap<>();
//	protected static Boolean standardEnfInsertMeta = false;
	@Value("${web.hdfs.path}") 
	private String webHdfsPath;
	@Value("${local.fs.bundle.path}") 
	private String bundleFilePath;
	@Value("${local.fs.failsafe.path}")
	private String failsafeFilePath;
	@Value("${dls.enable.hdfs}")
	private Boolean enableHDFS;
	@Value("${dls.enable.azureblob}")
	private Boolean enableBlob;
	@Value("${dls.append.file.max.size}")
	private short maxAppendSize;
	@Value("${local.fs.bundle.path}")
	private String bundlePath;
	@Value("${dls.staging-url}" )
	private String stagingURL;



	public String upload(String apiKey, String dlsKey, String filename,
			String savepoint, MultipartFile file,
			FileDescriptor.UploadMode mode, String directory, String[] metadata ,String comment) throws DlsSecurityException, DlsPrivacyException,
	IOException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		if(APPEND == mode && file.getSize() > maxAppendSize * KB * KB) {
			throw new DlsValidationException("append.too.large");
		}
		return helper.saveAndUpload(filename, savepoint, file, mode, directory, metadata, user,comment);
	}

	public String saveAndUploadBundle(
			String[] metadata, 
			String descriptor, 
			UserVO user,
			String bundleName,
			String bundleType,
			String bundleHash,
			String savepoint,
			String directory,
			String comment) throws IOException, SQLException {

		
		BundlingUtil bUtil = new BundlingUtil();
		File bundleFile=bUtil.createBundle(bundleFilePath, bundleName,bundleType);		
//		DiskFileItem fileItem = new DiskFileItem(bundleFile.getName(),
//				Files.probeContentType(bundleFile.toPath()), false, bundleFile.getName(),
//				(int) bundleFile.length(), bundleFile.getParentFile());
//		fileItem.getOutputStream();
//		MultipartFile multipartFileToSend = new CommonsMultipartFile(fileItem);




		Map <String, String>  props = dhelper.validate(bundleFile.getName(), savepoint, bundleFile.getName(), metadata);

		FileVO vo = FileVO.builder()
				.fileName(bundleFile.getName())
				.sizeInByte(bundleFile.length())
				.user(user)
				.deleted(false)
				.external(false)
				.bundled(true)
				.bundle(descriptor)
				.savepoint(savepoint)
				.createdOn(Timestamp.from(Instant.now()))
				.bundleHash(bundleHash)
				.storage(enableHDFS ? "H" : "L")
				.build();

		List <FileMetaVO> meta = helper.matchSchemaAndBuildMetadata(user, vo, props);
//		props.keySet().forEach(p -> meta.add(FileMetaVO.builder().name(p)
//				.value(props.get(p))
//				.file(vo)
//				.user(user)
//				.build()));
		DirectoryVO directoryVO = helper.checkDirectory(directory, vo, user, meta);
		final String fsPath = dhelper.generateDfsPath(user, bundleFile.getName(),savepoint,
				Optional.ofNullable(directoryVO).map(DirectoryVO::getId).orElse(null));
		File tempDir= new File(bundleFilePath+"/"+bundleName);
		if(null != fileRepo.findByFsPathAndDeleted(fsPath, false)) {
			bUtil.deleteTempDirectory(tempDir);
			bUtil.deleteTempDirectory(bundleFile);
			throw new DataIntegrityViolationException("already.exists");
		}
		vo.setDirectory(directoryVO);
		vo.setFsPath(fsPath);

		SimpleDateFormat dateFormat = new SimpleDateFormat(ARCHIVE_TIMESTAMP_FORMAT);
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		try {
			
			meta.add(FileMetaVO.builder()
					.user(user)
					.file(vo)
					.name(DLS_LINEAGE)
					.value("CREATED")
					.build());
			vo.setMeta(meta);
			
			FileVO saved = fileRepo.saveAndFlush(vo);
//			if(standardEnfInsertMeta)
			dhelper.insertMetaForStandardRule(user,fsPath,mapOfMetaValStandardEnf);
//			if(enableHDFS) {
				dfsService.writeBundle(bundleFile, fsPath, saved.getId());
//			} else {
//				dfsService.writeToNFSforBundle(bundleFile, fsPath, saved.getId());
//			}
			if(comment != null && !comment.isEmpty())
			{
				helper.addComment(comment, saved, user);
			}

			bUtil.deleteTempDirectory(tempDir);
			bUtil.deleteTempDirectory(bundleFile);			
		} catch (DataIntegrityViolationException e) {
			throw new DataIntegrityViolationException((e.getMessage() == null) ? "already.exists" : e.getMessage());
		}
		return fsPath;
	}

	@Transactional("transactionManager")
	public void update(String apiKey, String dlsKey, String filename, String savepoint, String directory, String[] metadata) throws DlsNotFoundException, DlsSecurityException, DlsValidationException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		Map <String, String>  props = dhelper.validate(metadata);

		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");

		List<FileMetaVO> meta = helper.matchSchemaAndBuildMetadata(user, null, props);
		DirectoryVO directoryVO = helper.checkDirectory(directory, null, user, meta);

		String fsPath = dhelper.generateDfsPath(user, filename, savepoint,
				Optional.ofNullable(directoryVO).map(DirectoryVO::getId).orElse(null));

		FileVO query = FileVO.builder().fsPath(fsPath).user(user).deleted(false).build();

		FileVO vo = fileRepo.findOne(Example.of(query, matcher)).orElseThrow(DlsNotFoundException::new);

		if(null != vo.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}
		if(null != directory) {
			vo.setDirectory(directoryVO);
		}

//		List <FileMetaVO> metaList = vo.getMeta();

		fileMetaRepo.deleteInBatch(vo.getMeta());

//		props.keySet().forEach(p -> {
//
//			FileMetaVO metaVO = FileMetaVO.builder().name(p)
//					.value(props.get(p))
//					.file(vo)
//					.user(user)
//					.build();
//
//			metaList.add(metaVO);
//
//		});

		meta.forEach(m -> m.setFile(vo));
		vo.setMeta(meta);

		fileRepo.saveAndFlush(vo);

	}

	public String getFilePath(String apiKey, String dlsKey, String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsBlobException {

		CatalogTextSearchVO fileVO = helper.getFile(apiKey, dlsKey, fileURI, !enableHDFS);
		if(! Optional.ofNullable(fileVO.getAction())
				.map(a -> a.contains(Permission.Action.R.name()))
				.orElse(Boolean.TRUE)) {
			throw new DataIntegrityViolationException("no.read.privilege");
		}
		if(null != fileVO.getStorage() && fileVO.getStorage().equalsIgnoreCase("L")) {
			return stagingURL.concat("?file-uri=").concat(URLEncoder.encode(fileURI, StandardCharsets.UTF_8));
		}
		
		//Get file from Azure Blob storage
		/*if(null != fileVO.getStorage() && fileVO.getStorage().equalsIgnoreCase("B")) {
			String url = blobService.getBlobURL(fileURI);
			if(url == null) {
				throw new DlsBlobException();
			}
			return url;
		}*/

		return webHdfsPath.concat(fileURI).concat("?op=OPEN");
	}

	public File download(String apiKey, String dlsKey, String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		CatalogTextSearchVO fileVO = helper.getFile(apiKey, dlsKey, fileURI, true);
		if(! Optional.ofNullable(fileVO.getAction())
				.map(a -> a.contains(Permission.Action.R.name()))
				.orElse(Boolean.TRUE)) {
			throw new DataIntegrityViolationException("no.read.privilege");
		}
		if(null != fileVO.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}
		String stagingPath = failsafeFilePath.concat("/").concat(fileVO.getFsPath());
//				.concat(fileVO.getUser().getTenant().getTcupUser())
//				.concat("/")
//				.concat(fileVO.getUser().getDlsUser())
//				.concat("/")
//				.concat(fileVO.getId().toString()).concat("/").concat(fileVO.getFileName());
		log.info("downloading from staging {}", stagingPath);
		FileSystemResource res = new FileSystemResource(stagingPath);

		return res.getFile();

	}

	public void relate(String apiKey, String dlsKey, String lhsFile, String relation, String rhsFile) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO lhs = dhelper.validateFile(user, lhsFile);
		FileVO rhs = dhelper.validateFile(user, rhsFile);

		linkRepo.saveAndFlush(LinkVO.builder().lhsFile(lhs).rhsFile(rhs)
				.relation(relation.toLowerCase(Locale.getDefault())).user(user).build());

	}

	public List<DlsResponse> relateMultiple(String apiKey, String dlsKey, List<Link> links) throws DlsSecurityException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		List<DlsResponse> responses = Lists.newArrayList();

		Set <String> fsPathSet = Sets.newHashSet();
		links.forEach(link -> {
			fsPathSet.add(link.getLhsFile());
			fsPathSet.add(link.getRhsFile());
		});
		List <FileVO> existingFiles = fileRepo.findByFsPathIn(Lists.newArrayList(fsPathSet));

		links.forEach(link -> {

			DlsResponse response = DlsResponse.builder()
					.code(HttpStatus.CREATED.value())
					.value(link.toString())
					.messages(Set.of(LINKED))
					.build();
			try {
				LinkVO linkVO = LinkVO.builder().user(user).build();
				linkVO.setLhsFile(
						existingFiles
						.stream()
						.filter(f -> f.getFsPath().matches(link.getLhsFile()))
						.findAny()
						.orElseThrow(() -> new DlsValidationException("invalid.lhs.file")));

				if(!link.getRelation().matches(LinkController.RELATION_NAME_PATTERN)) {
					throw new DlsValidationException("link.invalid.relation");
				} else {
					linkVO.setRelation(link.getRelation());
				}
				linkVO.setRhsFile(
						existingFiles
						.stream()
						.filter(f -> f.getFsPath().matches(link.getRhsFile()))
						.findAny()
						.orElseThrow(() -> new DlsValidationException("invalid.rhs.file")));

				linkRepo.saveAndFlush(linkVO);
			} catch (DlsValidationException ex) {
				response.setCode(HttpStatus.BAD_REQUEST.value());
				response.setMessages(Set.of(ev.getProperty(ex.getMessage())));
			} catch (DataIntegrityViolationException ex) {
				response.setCode(HttpStatus.CONFLICT.value());
				response.setMessages(Set.of(ev.getProperty("already.exists")));
			} catch (Exception ex) {
				response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				response.setMessages(Set.of(ev.getProperty("internal.error")));
			}
			responses.add(response);
		});


		return responses;
	}



	public String findLinks(String apiKey, String dlsKey, String lhsFile, String relation, String rhsFile) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		FileVO lhs = dhelper.validateFile(user, lhsFile);

		FileVO rhs = dhelper.validateFile(user, rhsFile);

		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues();//.withIgnorePaths("id");

		LinkVO query = LinkVO.builder().user(user).lhsFile(lhs).rhsFile(rhs).relation(relation).build();

		List <LinkVO> results = linkRepo.findAll(Example.of(query, matcher));

		if(results.isEmpty())
			throw new DlsNotFoundException();

		List <String> linkResults = Lists.newArrayList();

		results.forEach(link -> linkResults.add(link.getLhsFile().getFsPath().concat(" ").concat(link.getRelation()).concat(" ").concat(link.getRhsFile().getFsPath())));

		return Joiner.on("\n").join(linkResults);
	}

	public String getAllRelationNames(String apiKey, String dlsKey) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {

		uservice.authorize(apiKey, dlsKey);
		List<String> names = linkRepo.getAllRelationNames();
		names.removeIf(n -> n.matches(DLS_ARCHIVE_TO));
		List <String> relations = Optional.of(names).orElseThrow(DlsNotFoundException::new);

		if(relations.isEmpty())
			throw new DlsNotFoundException();

		return Joiner.on("\n").join(relations);
	}

	public void uploadOutOfBand(String apiKey, String dlsKey, String filename, String savepoint, String[] metadata) throws DlsSecurityException, DlsPrivacyException, DlsValidationException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		Map <String, String>  props = dhelper.validate(metadata);

		FileVO vo = FileVO.builder()
				.fileName(filename)
				.savepoint(savepoint)
				.user(user)
				.uploaded(true)
				.fsPath(filename)
				.external(true)
				.deleted(false)
				.createdOn(Timestamp.from(Instant.now()))
				.build();

		List <FileMetaVO> meta = Lists.newArrayList();

		props.keySet().forEach(p -> meta.add(FileMetaVO.builder().name(p)
				.value(props.get(p))
				.file(vo)
				.user(user)
				.build()));

		vo.setMeta(meta);

		FileVO saved = fileRepo.saveAndFlush(vo);
		log.info("Out-of-band file saved with id {}",saved.getId());

	}

	public void delete(String apiKey, String dlsKey, String fileURI, boolean forced) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
//		FileVO query = FileVO.builder().fsPath(fileURI).user(user).build();
//		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");
//		List <FileVO> results = fileRepo.findAll(Example.of(query, matcher));

		List<CatalogTextSearchVO> results = catalogTextSearchRepo.getFilePath(user.getId(), fileURI);

		if(results.isEmpty())
			throw new DlsNotFoundException();


		if(results.stream().allMatch(CatalogTextSearchVO::getDeleted)) {
			throw new DataIntegrityViolationException("deleted.file");
		}

		CatalogTextSearchVO result = results.stream().filter(r -> !r.getDeleted()).findFirst().orElseThrow(DlsNotFoundException::new);

		if(! Optional.ofNullable(user.getAdmin()).orElse(Boolean.FALSE) && ! Optional.ofNullable(result.getAction())
				.map(a -> a.contains(Permission.Action.D.name()))
				.orElse(Boolean.TRUE)) {
			throw new DataIntegrityViolationException("no.delete.privilege");
		}

		if(!Optional.ofNullable(result.getUploaded()).orElse(Boolean.FALSE)) {
			if(!forced)
			throw new DataIntegrityViolationException("transfer.fail");
		}

		if(null != result.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}



		if(!Optional.ofNullable(result.getExternal()).orElse(Boolean.FALSE)) {

//			if("L".equalsIgnoreCase(result.getStorage())) {
				dfsService.delete(false, result.getFsPath());
//			} else {
//				dfsService.deleteFile(false, result.getFsPath());
//			}
		}


		FileVO fileVO = FileVO.builder().build();
		BeanUtils.copyProperties(result, fileVO);
		fileVO.setDeleted(true);
		fileVO.setDeletedOn(Timestamp.from(Instant.now()));
		fileRepo.saveAndFlush(fileVO);

	}

	public void deleteLinks(String apiKey, String dlsKey, String lhsFile, String relation, String rhsFile) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		FileVO lhs = dhelper.validateFile(user, lhsFile);

		FileVO rhs = dhelper.validateFile(user, rhsFile);

		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");

		LinkVO query = LinkVO.builder().user(user).lhsFile(lhs).rhsFile(rhs).relation(relation).build();

		LinkVO link = linkRepo.findOne(Example.of(query, matcher)).orElseThrow(DlsNotFoundException::new);

		linkRepo.delete(link);

	}

	private FileVO checkPermissionAndGetFile(String fsPath, String action, UserVO user) throws DlsNotFoundException {
		FileVO file = fileRepo.findByFsPathAndDeleted(fsPath, false);

		if(file == null) throw new DlsNotFoundException();
		boolean permittedWrite = Optional.ofNullable(file.getDirectory())
				.flatMap(d -> Optional.ofNullable(d.getPermission()))
				.map(ps ->
					ps.stream()
							.filter(p -> Objects.equals(p.getPermittedUser(), user.getId()))
							.anyMatch(p -> p.getAction().contains(action))

					)
				.orElse(Objects.equals(file.getUser().getId(), user.getId()));

		if (!permittedWrite) throw new DataIntegrityViolationException("no.write.privilege");
		return file;
	}

	public void updateMetadata(String apiKey, String dlsKey, String fsPath, String[] metadata/*, FileController.PrivacyEnum privacy*/) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		Map <String, String>  props = dhelper.validate(metadata);

//		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");

//		FileVO query = FileVO.builder().fsPath(fsPath).user(user).build();
		FileVO catalog = checkPermissionAndGetFile(fsPath, Permission.Action.W.name(), user);

		if(null != catalog.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}


		if(catalog.getDeleted()) {
			throw new DataIntegrityViolationException("deleted.file");
		}





		if(!Optional.ofNullable(catalog.getUploaded()).orElse(Boolean.FALSE)) {
			throw new DataIntegrityViolationException("transfer.fail");
		}

		FileVO vo = fileRepo.findByFsPathAndDeleted(catalog.getFsPath(), false);

		List <FileMetaVO> meta = helper.matchSchemaAndBuildMetadata(user, vo, props);

		meta.forEach(m -> {
			m.setName(m.getName().replaceFirst("(?i)public@", "").replaceFirst("(?i)private@", user.getId() + "@" ));
//			if(m.getName(). privacy != null) {
//				m.setQualifier(new String[]{privacy.name()});
//			if(privacy.name().equalsIgnoreCase("private")) {
//				m.setName(user.getId() + "@" + m.getName());
//			}
//			}
		});
		DirectoryVO directoryVO = helper.checkDirectory( Optional.ofNullable(catalog.getDirectory())
				.map(DirectoryVO::getDirectory).orElse(null),  vo, user, meta);


		List <FileMetaVO> deletionList = vo.getMeta().stream()
				.filter(m -> !m.getName().startsWith(DLS_))
				.filter(m -> m.getQualifier() == null || Arrays.stream(m.getQualifier()).anyMatch(v -> v.equalsIgnoreCase("public"))
						|| m.getName().startsWith(user.getId() + "@"))
//				.filter(m -> Objects.equals(m.getUser().getId(), user.getId()))
				.filter(m -> ! props.containsKey(m.getName()))
				.collect(Collectors.toList());

		fileMetaRepo.deleteAllInBatch(deletionList);

//		props.keySet().forEach(p -> {
//
//			FileMetaVO metaVO = FileMetaVO.builder().name(p)
//					.value(props.get(p))
//					.file(vo)
//					.user(user)
//					.build();
//
//			metaList.add(meta);
//
//		});

//		metaList.add(FileMetaVO.builder()
//				.user(user)
//				.file(vo)
//				.name(DLS_LINEAGE)
//				.value(META_UPDATED)
//				.build());

		vo.setMeta(meta);

		fileRepo.saveAndFlush(vo);

	}

	@Autowired private Environment ev;

	public List<DlsResponse> uploadMultipleFiles(String apiKey,
                                                 String dlsKey,
                                                 MultipartFile [] files,
                                                 String descriptor) throws DlsSecurityException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		List<DlsResponse> response = new ArrayList<>();

		List<FileDescriptor> fileInfos =
				Errors
				.createRethrowing(e ->  new DlsValidationException("invalid.descriptor.json"))
				.get(() -> new ObjectMapper().readValue(descriptor, new TypeReference<>() {
				}));

		Long fileLen = Flux.fromArray(files).distinct(MultipartFile::getOriginalFilename).count().block();
		Long infoLen = Flux.fromIterable(fileInfos).distinct(f -> f.getFilename() + f.getSavepoint()).count().block();

		if(files.length != Objects.requireNonNullElse(fileLen, Long.MAX_VALUE))
			throw new DlsValidationException("duplicate.file");

		if(fileInfos.size() != Objects.requireNonNullElse(infoLen, Long.MAX_VALUE))
			throw new DlsValidationException("duplicate.descriptor");

		if(files.length != fileInfos.size()){
			throw new DlsValidationException("File Number and File information mismatch");
		}

		Stream
		.of(files)
		.forEach(file ->

		fileInfos.stream()
		.filter(f -> f.getFilename().equalsIgnoreCase(file.getOriginalFilename()))
		.findFirst()
		.ifPresentOrElse(fileInfo -> {
			//validate permission to directory and meta data <TBD>
			String fileName = fileInfo.getFilename();
			DlsResponse res = DlsResponse.builder()
					.value(Joiner.on('/').skipNulls().join(fileInfo.getSavepoint(), fileName))
					.build();
			try {

				String savepoint = Strings.emptyToNull(fileInfo.getSavepoint());
				if(null != savepoint && savepoint.length() > SAVEPOINT_LEN) throw new DlsValidationException("too.long.savepoint");
				if(null != savepoint && !savepoint.matches(SAVEPOINT_REGEX)) throw new DlsValidationException("invalid.savepoint.format");

				if(null != fileName && fileName.length() > FILENAME_LEN) throw new DlsValidationException("too.long.filename");
				if(null != fileName && !fileName.matches(FILENAME_REGEX)) throw new DlsValidationException("invalid.filename.format");

				String directory = Strings.emptyToNull(fileInfo.getDirectory());
				if(null != directory && directory.length() > DIRECTORY_LEN) throw new DlsValidationException("too.long.directory");
				if(null != directory && !directory.matches(DIRECTORY_REGEX)) throw new DlsValidationException("invalid.directory.regex");

				FileDescriptor.UploadMode mode;

				if (null == fileInfo.getMode()) {
					mode = FileDescriptor.UploadMode.RESTRICT;
				} else {

					mode = Errors.createRethrowing(e -> new DlsValidationException("invalid.upload.mode"))
							.get(() -> FileDescriptor.UploadMode.valueOf(fileInfo.getMode()));
				}
				String message = helper.saveAndUpload(fileName,
						savepoint,
						file,
						mode,
						fileInfo.getDirectory(),
						fileInfo.getMetadata(),
						user,
						fileInfo.getComment());
				res.setMessages(Set.of(message));
				res.setCode(HttpStatus.ACCEPTED.value());

			} catch (DlsValidationException ex) {
				String message = Optional.ofNullable(ev.getProperty(ex.getMessage())).orElse(ex.getMessage());
				res.setMessages(Set.of(message));
				res.setCode(HttpStatus.BAD_REQUEST.value());
			}
			catch (DataIntegrityViolationException ex) {
				res.setMessages(Set.of( Optional.ofNullable(ev.getProperty(ex.getMessage())).orElse(ev.getProperty("already.exists"))));
				res.setCode(HttpStatus.CONFLICT.value());
			}
			catch (IOException ex) {
				res.setMessages(Set.of(ev.getProperty("hdfs.error")));
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			catch (Exception ex) {
				res.setMessages(Set.of(ev.getProperty("internal.error")));
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			response.add(res);
		}, () -> response.add(DlsResponse.builder()
				.value(file.getOriginalFilename())
				.code(HttpStatus.BAD_REQUEST.value())
				.messages(Set.of(ev.getProperty("unmatching.filename")))
				.build())));
		return response;
	}



	@Transactional("transactionManager")
	public String updateSavepoint(String apiKey, String dlsKey, @NonNull final String fileUri, String savepoint) throws DlsSecurityException,
	DlsPrivacyException, DlsNotFoundException, IOException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		String fileName = fileUri.substring(fileUri.lastIndexOf('/')+1);

		List<FileVO> fileVOs = fileRepo.findByFsPathContaining(fileUri);
		fileVOs.removeIf(FileVO::getDeleted);
		if(fileVOs.isEmpty()) {
			throw new DlsNotFoundException();
		}
		if(fileVOs.stream().anyMatch(f -> null != f.getLock())) {
			throw new DataIntegrityViolationException("file.locked");
		}

		String newFsPath = dhelper.generateDfsPath(user, fileName, savepoint ,
				Errors.suppress().getWithDefault(() -> fileVOs.get(0).getDirectory().getId(), null));
		if(newFsPath.compareTo(fileUri) == 0) {
			throw new DlsValidationException("same.savepoint");
		}


		if(fileRepo.findByFsPathAndDeleted(newFsPath, false) != null) {
			throw new DataIntegrityViolationException("savepoint.already.exists");
		}

		FileVO oldFile = FileVO.builder().build();

		fileVOs.forEach(vo -> {

			String newSp = StringUtils.trimTrailingCharacter(StringUtils.trimLeadingCharacter(savepoint, '/'), '/');
			String path;
			if(null == vo.getSavepoint()) {
				newSp = StringUtils.trimTrailingCharacter(StringUtils.trimLeadingCharacter(newSp, '/'), '/');
				String uri = vo.getFsPath();
				int lastIndex = uri.lastIndexOf('/');
				path = Joiner.on('/').skipNulls().join(uri.substring(0, lastIndex), newSp, uri.substring(lastIndex + 1));
			} else {
				String oldSp = StringUtils.trimTrailingCharacter(StringUtils.trimLeadingCharacter(vo.getSavepoint(), '/'), '/');
				path = vo.getFsPath().replace(oldSp, Strings.nullToEmpty(newSp)).replace("//", "/");
			}

			if(vo.getFsPath().equalsIgnoreCase(fileUri)) {
				helper.addOldFileToLineage(oldFile, vo, user, fileUri, path);
			}
			vo.setFsPath(path);
			vo.setDirectory(oldFile.getDirectory());
			vo.setSavepoint(savepoint);

		});
		fileVOs.add(oldFile);
		fileRepo.saveAll(fileVOs);

		Optional.ofNullable( catalogRepo.findByPathAndType(fileUri, CATALOG_TYPE_FILE))
						.ifPresent(vo -> {
							vo.setSavepoint(savepoint);
							vo.setPath(newFsPath);
							catalogRepo.saveAndFlush(vo);
						});


//		if ((enableHDFS)) {
			dfsService.renameDirectory(fileUri, newFsPath);
//		} else {
//			dfsService.renameLocalDirectory(fileUri, newFsPath);
//		}

		return newFsPath;

	}

	/*public FileVO getFileByPath(String fsPath) {
		FileVO fVO=fileRepo.findByFsPath(fsPath);
		if(fVO!=null) {
			if(fVO.getDeleted())
				throw new DlsValidationException("error.file.deleted");
			return fVO;
		}else {
			throw new DlsValidationException("error.file.not.found");
		}
		
		
		
	}*/
	
	public String updateFileComment(String apiKey, String dlsKey, String fileUri, String comment)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		FileVO fileVO = checkPermissionAndGetFile(fileUri, Permission.Action.W.name(), user);


		if(null != fileVO.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}
		helper.addComment(comment, fileVO, user);
		
		return UPDATED;

	}
	
	public String deleteFileComment(String apiKey, String dlsKey, String fileUri)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		FileVO fileVO = checkPermissionAndGetFile(fileUri, Permission.Action.W.name(), user);
		if(null != fileVO.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}
		long fileId = fileVO.getId();
		
		List<CommentsVO> listCommentsVO = commentRepo.findByFileId(fileId);
		if(listCommentsVO != null)
		{
			listCommentsVO.stream().forEach(cVO -> {
				
				commentRepo.delete(cVO);
			});
		}
		else {
			throw new DlsValidationException("comment.not.found");
		}

		return "DELETED";

	}

	/**
	 * Get the comments for this file
	 * @param apiKey
	 * @param dlsKey
	 * @param fileUri
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public List<Comment> getFileComment(String apiKey, String dlsKey, String fileUri)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO fileVO = checkPermissionAndGetFile(fileUri, Permission.Action.R.name(), user);
//		CommentsVO search = CommentsVO.builder().file(fileVO).user(user).build();
		List<Comment> comments = Optional.of(commentRepo.findByFileId(fileVO.getId()))
				.orElseThrow(DlsNotFoundException::new)
				.stream()
				.map(vo -> Comment.builder()
						.comment(vo.getComment())
						.createdOn(vo.getCreatedOn())
						.fileUri(vo.getFile().getFsPath())
						.user(vo.getUser().getDlsUser())
						.build())
				.collect(Collectors.toList());
		if(comments.isEmpty()) {
			throw new DlsNotFoundException();
		}
		return comments;
	}


	/**
	 * Update the directory of a file, if both file exists and directory exists with proper
	 * WRITE permission of the user.
	 * There should not be any existing file with the new directory name provided by user.
	 * For out-of-band files, only FILE table inDB will be updated with new
	 * directory. Otherwise, for HDFS and Local stored files, actual directory will be renamed to new one.
	 * @param apiKey
	 * @param dlsKey
	 * @param fileUri
	 * @param directory
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 * @throws IOException
	 */
	@Transactional("transactionManager")
	public String updateFileDirectory(String apiKey, String dlsKey, String fileUri, String directory)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException, IOException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		DirectoryVO directoryVO = (null == directory) ? null :
				Optional
						.ofNullable(directoryRepo.getDirectoryByPermittedUser(directory, user.getTenant().getId(), user.getId()))
						.orElseThrow(() -> new DataIntegrityViolationException("invalid.directory.permission"));

		if(Optional.ofNullable(directoryVO)
				.map(d -> d.getPermission()
						.stream()
						.map(PermissionVO::getAction)
						.noneMatch(a -> a.contains("W"))).orElse(Boolean.FALSE)) {

			throw new DataIntegrityViolationException("Write permission is not available in destination directory");
		}
		final FileVO fileVO = checkPermissionAndGetFile(fileUri, Permission.Action.W.name(), user);

		final String oldDirectory = Optional.ofNullable(fileVO.getDirectory()).map(DirectoryVO::getDirectory).orElse(null);

		if(Optional.ofNullable(fileVO.getDirectory())
				.map(d -> d.getPermission()
						.stream()
						.filter(p -> user.getId().equals(p.getPermittedUser()))
						.map(PermissionVO::getAction)
						.noneMatch(a -> a.contains("D"))).orElse(Boolean.FALSE)) {

			throw new DataIntegrityViolationException("Delete permission is not available from source directory");
		}



		if(null != fileVO.getLock()) {
			throw new DataIntegrityViolationException("file.locked");
		}

		FileVO oldFile = FileVO.builder().build();

		if(!fileVO.getUploaded()) {
			throw new DataIntegrityViolationException("notuploaed.lock.impossible");
		}

		Optional
				.ofNullable(fileVO.getSharedTo())
				.filter(s -> s.length > 0)
				.ifPresent(a ->  {
					throw new DataIntegrityViolationException("invalid.update.directory.shared.already");
				});


		fileVO.setDirectory(directoryVO);
		String fileName = fileUri.substring(fileUri.lastIndexOf('/')+1);

		String newFsPath = dhelper.generateDfsPath(user, fileName, fileVO.getSavepoint(),
				Optional.ofNullable(directoryVO).map(DirectoryVO::getId).orElse(null));
		fileVO.setFsPath(newFsPath);

		helper.addOldFileToLineage(oldFile, fileVO, user, fileUri, newFsPath);
		fileRepo.save(oldFile);
		Long newFileId = fileRepo.save(fileVO).getId();

		// update file parent in catalog
		Optional.ofNullable(catalogRepo.findByPathAndType(fileUri, CATALOG_TYPE_FILE))
				.ifPresent(vo -> {
							vo.setParent(directory);
							vo.setPath(newFsPath);
							catalogRepo.saveAndFlush(vo);
						});

		// increase new directory's file count
		Optional.ofNullable(catalogRepo.findByPathAndTypeAndPermittedUser(directory, CATALOG_TYPE_DIRECTORY, user.getId()))
				.ifPresent(vo -> {
					vo.setFileCount(vo.getFileCount() + 1);
					catalogRepo.saveAndFlush(vo);
				});

		// reduce old directory's file count
		Optional.ofNullable(oldDirectory)
				.flatMap(d -> Optional.ofNullable(catalogRepo.findByPathAndTypeAndPermittedUser(d, CATALOG_TYPE_DIRECTORY, user.getId())))
				.ifPresent(vo -> {
					int fileCount = vo.getFileCount() - 1;
            vo.setFileCount(Math.max(fileCount, 0));
            catalogRepo.saveAndFlush(vo);
        });

		// update permission of the new file URI from new directory
		Optional.ofNullable(directoryVO)
				.map(d -> d.getPermission().stream().map(PermissionVO::getPermittedUser).collect(Collectors.toList()))
				.ifPresentOrElse(ps ->
					catalogRepo.findById(newFileId)
							.ifPresent(vo -> {
								vo.setPermittedUsers(ps .toArray(Long[]::new));
								catalogRepo.saveAndFlush(vo);
							})
						,
						() ->
							catalogRepo.findById(newFileId)
									.ifPresent(vo -> {
										vo.setPermittedUsers(new Long[]{user.getId()});
										catalogRepo.saveAndFlush(vo);
									})
						);




		if(!Optional.ofNullable(fileVO.getExternal()).orElse(Boolean.FALSE)) {
//			if ((enableHDFS)) {
				dfsService.renameDirectory(fileUri, newFsPath);
//			} else {
//				dfsService.renameLocalDirectory(fileUri, newFsPath);
//			}
			return newFsPath;

		}
		return "ERROR";
	}

	public String getFileStatus(String apiKey, String dlsKey, String fileName, String directory, String savepoint)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		DirectoryVO directoryVO = (null == directory) ? null :
				Optional
						.ofNullable(directoryRepo.getDirectoryByPermittedUser(directory, user.getTenant().getId(), user.getId()))
						.orElseThrow(() -> new DataIntegrityViolationException("invalid.directory.permission"));
		if(Optional.ofNullable(directoryVO)
				.map(d -> d.getPermission()
						.stream()
						.map(PermissionVO::getAction)
						.noneMatch(a -> a.contains("W"))).orElse(Boolean.FALSE)) {

			throw new DataIntegrityViolationException("Write permission is not available in destination directory");
		}
		String fsPath = dhelper.generateDfsPath(user, fileName, savepoint,
				Optional.ofNullable(directoryVO).map(DirectoryVO::getId).orElse(null));

		FileVO file = fileRepo.findByFsPathAndDeleted(fsPath, false);

		if(null == file) {
//			return DlsResponse.builder().key(fsPath).value("NEW").code(HttpStatus.OK.value()).build();
			return fsPath;
		}

		if(Optional.ofNullable(file.getLock())
				.map(l -> ArrayUtils.contains(l, 'W'))
				.orElse(Boolean.FALSE)) {
//			return DlsResponse.builder().key(fsPath).messages(Set.of("File is locked"))
//					.code(HttpStatus.BAD_REQUEST.value()).build();
			throw new DataIntegrityViolationException("file.locked");
		}
		if(file.getUploaded()) {
//			return DlsResponse.builder().key(fsPath).messages(Set.of("File is already uploaded successfully"))
//					.code(HttpStatus.CONTINUE.value()).build();
			throw new DataIntegrityViolationException("duplicate.file");
		}
		switch (Optional.ofNullable(file.getUploadStatus())
				.map(DlsFileStatus.UploadStatus::valueOf)
				.orElse(DlsFileStatus.UploadStatus.UPLOADED)){

			case UPLOADED :
//				return DlsResponse.builder()
//						.key(fsPath).value(file.getUploadStatus())
//						.messages(Set.of("File is already uploaded using DLS REST end-point"))
//						.code(HttpStatus.CONFLICT.value()).build();
				throw new DataIntegrityViolationException("duplicate.file");
			case UPLOADING:
//				return DlsResponse.builder()
//						.key(fsPath)
//						.value(file.getUploadStatus())
//						.messages(Set.of("Another client is already uploading this file"))
//						.code(HttpStatus.CONFLICT.value()).build();
				throw new DataIntegrityViolationException("Another client is already uploading this file");

			case RESUMED:
//				return DlsResponse.builder()
//						.key(fsPath)
//						.value(file.getUploadStatus())
//						.messages(Set.of("Another client has already resumed this file transfer"))
//						.code(HttpStatus.CONFLICT.value()).build();
				throw new DataIntegrityViolationException("Another client has already resumed this file transfer");

			case PAUSED:
//				return DlsResponse.builder().key(fsPath).value(file.getUploadStatus()).code(HttpStatus.OK.value()).build();
				return fsPath;

			default : throw new DataIntegrityViolationException("Invalid status for file");

		}

	}

	public void updateFileStatus(String apiKey, String dlsKey, String fileUri, DlsFileStatus.UploadStatus status)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		FileVO fileVO = Optional.ofNullable(fileRepo.findByFsPathAndDeleted(fileUri, false)).orElseThrow(DlsNotFoundException::new);
		if(fileVO.getUploaded()) {
			log.info("Resumable file upload status is not updated as uploaded is already true");
			return;
		}
		if(status.name() == fileVO.getUploadStatus()) {
			log.info("Resumable file upload status is not updated as supplied status is same as before");
			return;
		}
		fileVO.setUploadStatus(status.name());

		if(status.compareTo(DlsFileStatus.UploadStatus.UPLOADED) == 0) {
			fileVO.setUploaded(true);
			fileVO.setStorage(enableHDFS ? "H" : "L");
		} else {
			fileVO.setUploaded(false);
		}

		fileRepo.save(fileVO);

	}

	public String uploadResumable(String apiKey, String dlsKey, String fileName, String savepoint, String directory,
								String[] metadata, String comment, Long sizeInBytes)
			throws DlsSecurityException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		helper.checkAvailableStorage(user.getTenant(), sizeInBytes);
		Map <String, String>  props = dhelper.validate(metadata);
		FileVO fileVO = FileVO.builder()
				.deleted(false)
				.external(false)
				.createdOn(Timestamp.from(Instant.now()))
				.user(user)
				.fileName(fileName)
				.savepoint(savepoint)
				.sizeInByte(sizeInBytes)
				.storage(enableHDFS ? "H" : "L")
				.uploaded(false)
				.build();

		List<FileMetaVO> meta = helper.matchSchemaAndBuildMetadata(user, fileVO, props);
		meta.add(FileMetaVO.builder()
				.user(user)
				.file(fileVO)
				.name(DLS_LINEAGE)
				.value("CREATED")
				.build());
		fileVO.setMeta(meta);
		DirectoryVO directoryVO = helper.checkDirectory(directory, fileVO, user, meta);
		fileVO.setDirectory(directoryVO);

		String fsPath = dhelper.generateDfsPath(user, fileName, savepoint,
				Optional.ofNullable(directoryVO).map(DirectoryVO::getId).orElse(null));
		if(null != fileRepo.findByFsPathAndDeleted(fsPath, false)) {
			throw new DataIntegrityViolationException("already.exists");
		}
		fileVO.setFsPath(fsPath);
		FileVO saved = fileRepo.saveAndFlush(fileVO);
		dhelper.insertMetaForStandardRule(user,fsPath,mapOfMetaValStandardEnf);
		if(comment != null && !comment.isEmpty()) {
			helper.addComment(comment, saved, user);
		}
		return fsPath;

	}
	@Value("${dls.download.zip.limit}") Long zipDownloadLimit;
	public Flux <CatalogTextSearchVO> findZipEntries(String apiKey, String dlsKey,
													 String directory, DateTime from, DateTime to, String metadata, String filename,
													 List<String> fileUriList,
													 int pageNo, int pageSize)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		Timestamp t1 = (null == from) ? null : new Timestamp(from.toDateTime(DateTimeZone.UTC).toDateTime(DateTimeZone.getDefault()).getMillis());
		Timestamp t2 = (null == to) ? null : new Timestamp(to.toDateTime(DateTimeZone.UTC).toDateTime(DateTimeZone.getDefault()).getMillis());
		if(t1 == null && t2 != null) {
			t1 = Timestamp.from(Instant.EPOCH);
		}
		if(t1 != null && t2 == null) {
			t2 = Timestamp.from(Instant.now());
		}


		FileSearchCriteria criteria = FileSearchCriteria.builder()
				.external(Boolean.FALSE)
				.transferred(Boolean.TRUE)
				.filename(filename)
//                .savepoint(query.getSavepoint())
				.deleted(Boolean.FALSE)
				.fromTime(t1)
				.toTime(t2)
				.metadata(metadata)
				.uri(Joiner.on(',').skipNulls().join(fileUriList))
//                .bundled(query.getBundled())
//                .ownFile(query.getOwnFile())
//                .uri(query.getUri())
//                .metadata(query.getMetadata())
				.locked(Boolean.FALSE)
				.userVO(user).build();
		if (null != directory && directory.equalsIgnoreCase("/")) {
			criteria.setFindInRootDirectory(true);
		}
		else if (null != directory) {
			DirectoryVO directoryVO = Optional.ofNullable(directoryRepo.getDirectoryByPermittedUser(directory, user.getTenant().getId(), user.getId()))
					.orElseThrow(() -> new DataIntegrityViolationException("source.directory.notPresent"));

			Optional.ofNullable(directoryVO.getPermission()).ifPresent(o -> {
						o.stream().filter(p -> p.getPermittedUser().equals(user.getId())).findFirst()
								.map(PermissionVO::getAction)
								.ifPresent(a -> {
									if(!a.contains("R")) throw new DataIntegrityViolationException("no.read.privilege");
								});
					});

			criteria.setDirectoryId(directoryVO.getId());

		}
		Pageable page = PageRequest.of(pageNo, pageSize);
		CatalogSpecification spec = new CatalogSpecification(criteria);
		Page<CatalogTextSearchVO> pages = catalogTextSearchRepo.findAll(spec, page);
		Long fileSize = pages.get().map(CatalogTextSearchVO::getSizeInByte).reduce(Long::sum).orElse(Long.MAX_VALUE);
		if(pages.getContent().size() == 0) {
			throw new DlsNotFoundException();
		}
		if(fileSize > zipDownloadLimit) {
			throw new DataIntegrityViolationException("too.large.zip");
		}
		return Flux.fromStream(pages.get())
				.filter(f ->  "L".equalsIgnoreCase(f.getStorage()));

	}
}
