package dls.service;

import com.diffplug.common.base.Errors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dls.bean.BundleDescriptor;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.repo.FileRepo;
import dls.vo.FileVO;
import dls.vo.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
public class FileBundlingService {


	@Value("${dls.allow.duplicate.bundle.content}")
	public static boolean allowDuplicateContent;

	@Autowired private FileService dservice;
	@Autowired private DlsServiceHelper dhelper;
	@Autowired private UserService uservice;
	@Autowired private FileRepo fRepo;

	public String uploadBundleFiles(String apiKey, String dlsKey, MultipartFile [] files, String bundleName,
									String bundleType, String descriptor, String savepoint, String comment, String directory, String[] bundleMetadata)
			throws DlsSecurityException, DlsPrivacyException, IOException, SQLException, NoSuchAlgorithmException, DlsNotFoundException {


		if(bundleName==null || bundleName.isEmpty()) {
			bundleName=""+Timestamp.from(Instant.now());
			bundleName=bundleName.replaceAll("\\s+","");
			bundleName=bundleName.replaceAll("\\:","");
		}


		final String bundleName1=bundleName;

		UserVO user = uservice.authorize(apiKey, dlsKey);


		List<BundleDescriptor> fileInfos = Errors
				.createRethrowing(e ->  new DlsValidationException("invalid.descriptor.json"))
				.get(() -> new ObjectMapper().readValue(descriptor, new TypeReference<>() {}));

		Long fileLen = Flux.fromArray(files).distinct(MultipartFile::getOriginalFilename).count().block();
		Long infoLen = Flux.fromIterable(fileInfos).distinct(BundleDescriptor::getFilename).count().block();

		if(files.length != Objects.requireNonNullElse(fileLen, Long.MAX_VALUE))
			throw new DlsValidationException("duplicate.file");

		if(fileInfos.size() != Objects.requireNonNullElse(infoLen, Long.MAX_VALUE))
			throw new DlsValidationException("duplicate.descriptor");

		if(files.length != fileInfos.size()){
			throw new DlsValidationException("File Number and File information mismatch");
		}



		List<BundleDescriptor> sortedFileDescriptor= fileInfos.stream()
				.sorted(Comparator.comparing(BundleDescriptor::getFilename).reversed())
				.collect(Collectors.toList());
		String tempHashDesc="";

		for (BundleDescriptor file : sortedFileDescriptor) {
			tempHashDesc = tempHashDesc + file.getFilename()+file.getDirectory();

			validateDirectory(apiKey, dlsKey, file.getDirectory());

		}

		log.info("Hash for Bundle Descriptor:  {}", tempHashDesc);
		String bundleJSONHash = dhelper.createBundleJSONHash(tempHashDesc);
		//if the property flag for allow duplicate content is false then 
		//check if any entry exists with the same hash , which would mean a duplicate entry
		if(!allowDuplicateContent) {
			List<FileVO> duplicateBundleFiles=fRepo.findByBundleHashAndDeletedAndUserId(bundleJSONHash, false, user.getId());
			if(!duplicateBundleFiles.isEmpty()) {
				throw new DlsValidationException("error.bundle.duplicate");
			}
			//
		}
		Stream
			.of(files)
			.forEach(file -> fileInfos
						.stream()
						.filter(f -> f.getFilename().equalsIgnoreCase(file.getOriginalFilename()))
						.findFirst()
						.ifPresent(fileInfo -> dhelper.writeToBundle(file,bundleName1,fileInfo.getDirectory())));

		//create a file with the descriptor bundle.
		dhelper.createBundleDescriptorFile(descriptor,bundleName);
		return dservice.saveAndUploadBundle(
				bundleMetadata,
				descriptor,
				user,
				bundleName,
				bundleType,
				bundleJSONHash,
				savepoint,
				directory,
				comment);



	}

	private void validateDirectory(String apiKey, String dlsKey, String directory) {
	}

}
