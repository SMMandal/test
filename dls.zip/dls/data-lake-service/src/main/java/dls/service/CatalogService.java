package dls.service;

import com.diffplug.common.base.Errors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import dls.bean.*;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.repo.*;
import dls.vo.*;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Flux;
import reactor.util.function.Tuple2;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static dls.repo.CatalogSpecification.OPERATOR_REGEX;
import static dls.service.CatalogExplorerViewService.CATALOG_TYPE_DIRECTORY;
import static dls.service.CatalogExplorerViewService.CATALOG_TYPE_FILE;
import static dls.service.FileService.ARCHIVE_TIMESTAMP_FORMAT;

@Service
@Slf4j
public class CatalogService {

	private static final String DLS_NS = "dls:";
	private static final String DIRECTORY = "directory";
	private static final String ROOT_DIR = "/";
//	private static final String FILE = "file";
	private static final String SLASH = "/";
	@Autowired
	private CatalogTextSearchRepo catalogTextSearchRepo;
	@Autowired
	private UserService uservice;
	@Autowired
	private FileMetaRepo fileMetaRepo;
	@Autowired
	private StatisticsRepo statisticsRepo;
	@Autowired
	private FileRepo fileRepo;
	@Autowired
	private DirectoryRepo directoryRepo;
	@Autowired
	private PermissionRepo permissionRepo;
	@Autowired UserRepo userRepo;
	@Autowired private CatalogRepo catalogRepo;

	@Value("${dls.catalog.default.page-size}")
	private Integer pageSize;

	private static final String FILE_SIZE_SPLIT_REGEX = "\\d+(\\.\\d{1,3})?";
	private final Pattern fileSizeSplitPattern = Pattern.compile(FILE_SIZE_SPLIT_REGEX);
	@Autowired private MetadataViewRepo metadataViewRepo;

//	@Autowired private CatalogRepo explorerViewRepo;
	/**
	 * This method returns the catalog
	 * @param apiKey
	 * @param dlsKey
	 * @param query filter conditions
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsNotFoundException
	 * @throws DlsPrivacyException
	 */
	public Catalog getCatalog(String apiKey, String dlsKey, CatalogQuery query,
							  boolean calledFromDirectoryCatalogMethod, int treeNodeLimit) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		UserVO user = uservice.authorize(apiKey, dlsKey);


		Timestamp start = Errors.suppress().getWithDefault(() -> {
			DateTime utc = query.getTime().get(0).toDateTime(DateTimeZone.UTC);
			DateTime local = utc.toDateTime(DateTimeZone.getDefault());
			log.info("UTC   {}", utc);
			log.info("Local {}", local);
			return new Timestamp(local.getMillis());
		}, null);

		Timestamp end = Errors.suppress().getWithDefault(() -> {
			DateTime utc = query.getTime().get(1).toDateTime(DateTimeZone.UTC);
			DateTime local = utc.toDateTime(DateTimeZone.getDefault());
			log.info("UTC   {}", utc);
			log.info("Local {}", local);
			return new Timestamp(local.getMillis());
		}, null);

		if (null != query.getTime()) {
			if (end == null) {
				end = start;
			}

			if (start.after(end)) {
				Timestamp t = end;
				start = end;
				end = t;
			}

			if (start.equals(end)) {
				end = Timestamp.from(end.toInstant().plusMillis(999));
			}

			log.info("start time {}", start);
			log.info("end time {}", end);
		}

		FileSearchCriteria criteria = FileSearchCriteria.builder()
				.external(query.getExternal())
				.transferred(query.getTransferred())
				.filename(query.getFilename())
				.savepoint(query.getSavepoint())
				.deleted(query.getDeleted())
				.fromTime(start)
				.toTime(end)
				.bundled(query.getBundled())
				.ownFile(query.getOwnFile())
				.uri(query.getUri())
				.metadata(validateMetadataQuery(query.getMetadata()))
				.locked(query.getLocked())
				.userVO(user).build();
		DirectoryVO directoryVO = null;
		if (null != query.getDirectory() && query.getDirectory().equalsIgnoreCase("/")) {
			criteria.setFindInRootDirectory(true);
		}
		else if (null != query.getDirectory()) {
			String d = StringUtils.trimTrailingCharacter(query.getDirectory(), '/');
			if(!d.startsWith("/")) {
				d = "/".concat(d);
			}
			query.setDirectory(d);
			directoryVO = directoryRepo.getDirectoryByPermittedUser(query.getDirectory(), user.getTenant().getId(), user.getId());

			if (null == directoryVO) {
				throw new DataIntegrityViolationException("source.directory.notPresent");
			}
		}
		if (null != directoryVO) {
			criteria.setDirectoryId(directoryVO.getId());
		}
		if (null != query.getSize()) {

			String[] tokens = query.getSize().split(FILE_SIZE_SPLIT_REGEX);
			String unit = tokens[1];

			Matcher matcher = fileSizeSplitPattern.matcher(query.getSize());

			if (matcher.find()) {
				double value = Double.parseDouble(matcher.group());
				if (unit.equalsIgnoreCase("kb")) {
					criteria.setSizeInByte((long) (value * 1024));
				} else if (unit.equalsIgnoreCase("mb")) {
					criteria.setSizeInByte((long) (value * 1024 * 1024));
				} else if (unit.equalsIgnoreCase("gb")) {
					criteria.setSizeInByte((long) (value * 1024 * 1024 * 1024));
				} else if (unit.equalsIgnoreCase("b")) {
					criteria.setSizeInByte((long) (value * 1));
				}
			}

			criteria.setSizeCheckOperator(tokens[0]);

		}

		String search = toTextSearchQuery(query.getText());

		criteria.setText(search);

		String sortBy = Optional
				.ofNullable(query.getSort())
				.map(s -> (s.equalsIgnoreCase("size")) ? "sizeInByte" : s)
				.orElse("createdOn");
		int pageNo = query.getPageNo() - 1;
		int size = (query.getPageSize() == null) ? pageSize : query.getPageSize();
		Pageable page = PageRequest.of(pageNo, size, Sort.by(sortBy));
		CatalogSpecification spec = new CatalogSpecification(criteria);

		if (calledFromDirectoryCatalogMethod ) {
			long count = catalogTextSearchRepo.count(spec) ;
			if(count > treeNodeLimit) {
				throw new DlsValidationException("Too many files [" + count + "] for a directory tree. Try using filters or increase fetchSize.");
			}
		}
		Page<CatalogTextSearchVO> pages = catalogTextSearchRepo.findAll(spec, page);
		Catalog catalog = Catalog.builder().result(Lists.newArrayList()).build();
		Flux.fromIterable(pages.getContent())
				.filter(f -> executeMetadataAndQuery(f, query.getMetadata()))
				.subscribe(f -> buildCatalog(catalog, f, user,  query.getOwnFile()));
//		pages.getContent().forEach(f -> buildCatalog(catalog, f, user,  query.getOwnFile()));

		if (catalog.getResult().isEmpty())
			throw new DlsNotFoundException();

		catalog.setCount(catalog.getResult().size());
		catalog.setPage(query.getPageNo() + " of " + pages.getTotalPages());
		return catalog;



	}

	private String validateMetadataQuery(String metadata) {
		if(null != metadata && metadata.contains("&")) {
//			if(StringUtils.countOccurrencesOf(metadata, "&") > 1) {
//				throw new DlsValidationException("The '&' operator is allowed only once in metadata query ");
//			}
			if(metadata.matches(".*,.*&.*")) {
				throw new DlsValidationException("In metadata query, all AND (&) conditions must precede the OR (,) conditions");
			}
//			if(metadata.split("&", 2)[0].split("(>=)|(<=)|(!=)|>|<").length > 1) {
//				throw new DlsValidationException("Logical operators are not allowed in '&' condition");
//			}
//			if(metadata.split("&", 2)[1].split("(>=)|(<=)|(!=)|>|<",2).length > 1) {
//				throw new DlsValidationException("Logical operators are not allowed in '&' condition");
//			}
		}
		return metadata;
	}

	private boolean executeMetadataAndQuery(CatalogTextSearchVO f, String metadata) {

		if(null == metadata || metadata.isEmpty() || !metadata.contains("&")) {
			return true;
		}
		Map<String, String> fileMetaMap = Maps.newHashMap();
		f.getMeta().stream()
				.filter(m -> !m.getName().startsWith(DLS_NS))
				.forEach(m -> fileMetaMap.put(m.getName(), m.getValue()));

		String [] andOrConds = metadata.split(",",2);

		boolean match = true;

		for(String elem : andOrConds[0].split(" *& *")) {

			if(!match) break;

			String[] kv = elem.split(OPERATOR_REGEX);

			String str1 = Errors.suppress().getWithDefault(() -> kv[0], null);
			String str2 = Errors.suppress().getWithDefault(() -> kv[1].replace("'", ""), null);

			if (kv.length > 1) {
				if(! mapHasKey(fileMetaMap, str1)) {
					match = false;
				} else {
					Pattern pattern = Pattern.compile(OPERATOR_REGEX);
					Matcher matcher = pattern.matcher(elem);
					String operator = "=";
					if (matcher.find()) {
						operator = matcher.group();
					}
					match = mapHasKeyValue(fileMetaMap, str1, str2, operator);

				}

			} else if (kv.length == 1 && ! str1.contains("'")) {
				match = mapHasKey(fileMetaMap,str1);

			} else if (kv.length == 1 && str1.contains("'")) {
				match = mapHasValue(fileMetaMap,str1);

			}
		}

		if(match) return true;
		// all OR conditions, any one should satisfy
//		boolean match = false;
		if(andOrConds.length == 1) {
			return match;
		}
		for(String elem : andOrConds[1].split(",")) {
			if(match) break;
			String[] kv = elem.split(OPERATOR_REGEX);

			String str1 = Errors.suppress().getWithDefault(() -> kv[0], null);
			String str2 = Errors.suppress().getWithDefault(() -> kv[1].replace("'", ""), null);



			if (kv.length > 1) {
				if(!mapHasKey(fileMetaMap, str1)) {
					match = false;
				}
				Pattern pattern = Pattern.compile(OPERATOR_REGEX);
				Matcher matcher = pattern.matcher(elem);
				String operator = "=";
				if (matcher.find())
				{
					operator = matcher.group().trim();
				}
				match = mapHasKeyValue(fileMetaMap, str1, str2, operator);

			} else if (kv.length == 1 && ! str1.contains("'")) {
				match = mapHasKey(fileMetaMap, str1);

			} else if (kv.length == 1 && str1.contains("'")) {
				match = mapHasValue(fileMetaMap, str1);
			}
		}
		return match;
	}

	private boolean mapHasKeyValue(Map <String,String> map, String key, String value, String operator) {

		operator = operator.trim();
		Stream<String> valueStream = map.keySet().stream()
				.filter(k -> k.matches("(?i)" + key.trim().replaceAll("\\*", ".*")))
				.map(map::get);


		if(operator.equalsIgnoreCase("=")) {
			String regex = value.replaceAll("\\*", ".*");
			return valueStream.anyMatch(v -> v.matches(regex));
		} else if(value.contains("*")) {
			throw new DlsValidationException("Wildcard is not supported with logical operator for value : " + value);
		}
		Double val = Double.parseDouble(value);
		Stream<Double> doubleStream = valueStream.filter(v ->
				Errors.suppress().getWithDefault(() -> {
					Double.parseDouble(v);
					return Boolean.TRUE;
				}, Boolean.FALSE))
				.map(Double::parseDouble);

		switch (operator.trim()) {
			case ">=" : return  doubleStream.anyMatch(d -> d >= val) ;
			case "<=" : return  doubleStream.anyMatch(d -> d <= val) ;
			case ">" : return  doubleStream.anyMatch(d -> d > val) ;
			case "<" : return  doubleStream.anyMatch(d -> d < val) ;
			case "!=" : return  doubleStream.anyMatch(d -> !d.equals(val)) ;
			default:
				throw new DlsValidationException("Invalid operator " + operator);
		}

	}

	private boolean mapHasKey(Map <String,String> map, String key) {

		if(key.contains("*")) {
			return map.keySet().stream()
					.anyMatch(k -> k.matches("(?i)" + key.trim().replaceAll("\\*", ".*")));
		} else {
			return map.keySet().stream().anyMatch (k -> k.equalsIgnoreCase(key.trim()));
		}
	}

	private boolean mapHasValue(Map <String,String> map, String value) {

		value = StringUtils.trimLeadingCharacter(value, '\'');
		value = StringUtils.trimTrailingCharacter(value, '\'');

		final String val = value;

		if(value.contains("*")) {
			return map.values().stream()
					.anyMatch(v -> v.matches(val.replaceAll("\\*", ".*")));
		} else {
			return map.containsValue(value);
		}
	}


	private void buildCatalog(Catalog catalog, CatalogTextSearchVO f, UserVO user, Boolean ownFile) {

		String dlsUser = user.getDlsUser();
		Boolean myFileFlag = (f.getExternal())? (null == f.getSharedTo() || !ArrayUtils.contains(f.getSharedTo(), dlsUser))
				:f.getFsPath().split("/")[1].equalsIgnoreCase(dlsUser);

		if(f.getMeta() != null && f.getMeta().stream().anyMatch(m -> m.getName().equalsIgnoreCase(FileService.DLS_INTERNAL))) {
			return;
		}

		boolean hidden =  user.getAdmin() ? Boolean.FALSE
				: Optional.ofNullable(f.getLock())
				.map(l -> ArrayUtils.contains(f.getLock(), 'R') &&
						! f.getMeta().stream()
								.filter(m -> m.getName().equalsIgnoreCase("dls:lockedOn"))
								.findFirst()
								.map(CatalogMetaVO::getUser)
								.map(UserVO::getId)
								.orElse(-1L).equals(user.getId())

				)
				.orElse(Boolean.FALSE);

		if(!hidden && (null == ownFile || myFileFlag.compareTo(ownFile) == 0)) {
			catalog.getResult().add(FileDetail.builder()
					.bundled(f.getBundled())
					.bundle(toBundles(f.getBundle()))
					.size(f.getSizeInByte())
					.createdOn(f.getCreatedOn())
					.deleted(f.getDeleted())
					.deletedOn(f.getDeletedOn())
					.external(f.getExternal())
//					.fileName(f.getFileName())
					.fsPath(f.getFsPath())
					.locked(f.getLock() != null ? Boolean.TRUE : null)
					.hidden(f.getLock() != null ? ArrayUtils.contains(f.getLock(), 'R') : null)
					.directory((f.getDirectory() == null) ? null : f.getDirectory().getDirectory())
//					.linksFrom()
//					.linksTo(f.getLinksTo().toString())
					.metadata(FileServiceHelper.maskPrivateMetadata(
							Strings.emptyToNull(f.getMeta().stream()
							.filter(m -> !m.getName().contains(FileService.DLS_))
//							.filter(m -> m.getQualifier() == null ||
//									Arrays.stream(m.getQualifier())
//											.anyMatch(s -> s.equalsIgnoreCase(FileController.PrivacyEnum.PUBLIC.name())) ||
//									Objects.equals(m.getUser().getId(), user.getId())
//							)
							.map(m -> m.getName().concat("=").concat(m.getValue()))
							.sorted()
							.collect(Collectors.joining(",")))
					,user))
					.savepoint(f.getSavepoint())
					.uploaded(f.getUploaded())
					.sharedTo((null == f.getSharedTo() || !myFileFlag )
							? null : Joiner.on(",").skipNulls().join(f.getSharedTo()) )
					.ownFile(myFileFlag)

					.sharedBy((!myFileFlag && null == f.getDirectory()) ? f.getUser().getDlsUser() : null)
					.build());

		}

	}


	private List<BundleDescriptor> toBundles(String bundle) {
		if(null == bundle)	{
			return null;
		}
		try {
			return new ObjectMapper().readValue(bundle, new TypeReference<>() {
			});
		} catch (IOException e) {
			return null;
		}
	}

	private String toTextSearchQuery(String text) {

		if (null == text) return null;

		return text.trim().replaceAll("[ ]*[,;:]+[ ]*", "|")
				.replaceAll("[.]\\s+", "|")
				.replaceAll("\\s+", "&")
				.replaceAll("[\\*][\\S]+", ":\\*&")
				.replaceAll("\\*", ":\\*");

	}


	/**
	 * Get the statistics of usage for the user
	 * @param apiKey
	 * @param dlsKey
	 * @param cumulative Admins are entitled to get cummulative statistics for all user
	 *                   if this flag is set to true
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public CatalogStatistics getCatalogStatistics(String apiKey, String dlsKey, boolean cumulative) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		boolean rootAdmin = (null == user.getOrgPosition()) ||
				Stream.of(user.getOrgPosition())
						.map(op -> StringUtils.trimLeadingCharacter(op, '/'))
						.map(op -> StringUtils.trimTrailingCharacter(op, '/'))
						.anyMatch(op -> !op.contains(SLASH));
		List<Long> uIds = Lists.newArrayList();
		if(cumulative && Optional.ofNullable(user.getAdmin()).orElse(Boolean.FALSE) && rootAdmin) {

			uIds.addAll(userRepo.findByTenant(user.getTenant()).stream().map(UserVO::getId).collect(Collectors.toList()));
		} else {
			uIds.add(user.getId());
		}
		return statisticsRepo.findByUserIdIn(uIds).stream()
				.map(this::toCatalogStatistics)
				.reduce(this::addUp)
				.orElseThrow(DlsNotFoundException::new);

	}

	private CatalogStatistics toCatalogStatistics(StatisticsVO vo) {
		return CatalogStatistics.builder()
				.firstuploaded(vo.getFirstuploaded())
				.lastuploaded(vo.getLastuploaded())
				.totalbundled(vo.getTotalbundled())
				.totalcount(vo.getTotalcount())
				.totaldeleted(vo.getTotaldeleted())
				.totalexternal(vo.getTotalexternal())
				.totalfailed(vo.getTotalfailed())
				.totalshared(vo.getTotalshared())
				.totalvolume(vo.getTotalvolume())
				.build();
	}

	private CatalogStatistics addUp(CatalogStatistics s1, CatalogStatistics s2) {

		return CatalogStatistics.builder()
				.totalvolume(Long.sum(s1.getTotalvolume(), s2.getTotalvolume()))
				.totalshared(Integer.sum(s1.getTotalshared(), s2.getTotalshared()))
				.totalfailed(Integer.sum(s1.getTotalfailed(), s2.getTotalfailed()))
				.totalexternal(Integer.sum(s1.getTotalexternal(), s2.getTotalexternal()))
				.totaldeleted(Integer.sum(s1.getTotaldeleted(), s2.getTotaldeleted()))
				.totalcount(Integer.sum(s1.getTotalcount(), s2.getTotalcount()))
				.totalbundled(Integer.sum(s1.getTotalbundled(), s2.getTotalbundled()))
				.lastuploaded( s1.getLastuploaded().after(s2.getLastuploaded()) ? s1.getLastuploaded() : s2.getLastuploaded())
				.firstuploaded(s1.getLastuploaded().before(s2.getLastuploaded()) ? s1.getLastuploaded() : s2.getLastuploaded())
				.build();
	}

	/**
	 * Get the list of key names for all metadata added in DLS so far by this user
	 *
	 * @param apiKey
	 * @param dlsKey
	 * @param withValue
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public List<String> getMetadataKeys(String apiKey, String dlsKey, Boolean withValue,
										char type, String matchingKey, String matchingValue) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);


		Specification<CatalogVO> spec = ExplorerViewSpecification.hasPermittedUser(user.getId());

		if(type != ' ') {
			spec = spec.and(ExplorerViewSpecification.hasType(type));
		}
		if(matchingKey != null || matchingValue != null) {

			Specification<MetadataViewVO> metaSpec = MetadataViewSpecification.hasNameValueLike(Joiner.on("=").skipNulls().join(matchingKey,
					matchingValue == null ? null : StringUtils.quote(matchingValue.trim())));

			List<Long> typeIds = metadataViewRepo.findAll(metaSpec).stream()
					.map(MetadataViewVO::getTypeId)
					.toList();

			spec = spec.and(ExplorerViewSpecification.hasTypeIdIn(typeIds));
//			spec = spec.and(ExplorerViewSpecification.hasMetadataWithNameAndValue(
//					Joiner.on("=").skipNulls().join(matchingKey,
//							matchingValue == null ? null : StringUtils.quote(matchingValue.trim()))));
		}


		List<CatalogVO> vos = catalogRepo.findAll(spec);
		if (vos.isEmpty())
			throw new DlsNotFoundException();

		List<String> data = Lists.newArrayList();

		data = Lists.newArrayList(vos.stream()
				.flatMap(vo -> Optional.ofNullable( vo.getMetadataList()).map(Collection::stream).orElse(Stream.<CatalogVO.Metadata>builder().build()))
				.filter(vo -> vo.name() != null)
				.filter(n -> !n.name().startsWith(DLS_NS))
				.filter(n -> matchingKey == null || n.name().matches("(?i)" + matchingKey.replace("*", ".*")))
				.filter(n -> matchingValue == null || n.value().matches("(?i)" + matchingValue.replace("*", ".*")))
				.map(n -> {
							if(!Optional.ofNullable(withValue).orElse(false)) {
								return n.name();
							} else {
								return n.name().concat("=").concat(
										Optional.ofNullable(
										Optional.ofNullable(n.privateTo())
												.map(pu -> { if(pu.equals(user.getId())) return n.value(); else return "***"; })
												.orElse(n.value())).orElse(""));
							}


				})

				.distinct()
				.sorted()
				.iterator())
		;


		if(data.isEmpty()) throw new DlsNotFoundException();
		return data;
	}


	/**
	 * Get the list of URIs of successfully transferred files which are not deleted
	 * @param apiKey
	 * @param dlsKey
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public List<String> getFileList(String apiKey, String dlsKey) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);

		FileSearchCriteria criteria = FileSearchCriteria.builder().deleted(Boolean.FALSE)
				.transferred(Boolean.TRUE).userVO(user).build();

		FileSpecification spec = new FileSpecification(criteria);

		List<FileVO> files = fileRepo.findAll(spec);

		if (files.isEmpty())
			throw new DlsNotFoundException();

		return Lists.newArrayList(files.stream().map(FileVO::getFsPath).iterator());
	}

	public List<Lineage> getLineage(String apiKey, String dlsKey, @NonNull String uri) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {
		UserVO user = uservice.authorize(apiKey, dlsKey);

		List<FileVO> archiveList = fileRepo.getArchiveList(user.getId(), uri.concat("%"));

		if (archiveList.isEmpty()) throw new DlsNotFoundException();

		List<Lineage> lineages = Lists.newArrayList();

		archiveList
				.forEach(a -> {
					Lineage lineage = Lineage.builder().build();
					//noinspection UnstableApiUsage
					String metaString = a.getMeta().stream()
//							.filter(m -> !m.getName().contains(FileService.DLS_))
							.map(m -> m.getName().concat("=").concat(m.getValue()))
							.sorted()
							.collect(Collectors.joining(","));
					Map<String, String> meta = Splitter.on(",")
							.withKeyValueSeparator("=")
							.split(metaString);

					lineage.setOperation(meta.getOrDefault(FileService.DLS_LINEAGE, "CREATED"));
					// TODO : add link to archive
//					if(null != a.getLinksTo()) {
//						lineage.setResultUri(a.getLinksTo().replaceFirst(FileService.DLS_ARCHIVE_TO.concat("="), ""));
//					}
					if(lineage.getOperation().equalsIgnoreCase("ARCHIVE")) {
						SimpleDateFormat dateFormat = new SimpleDateFormat(ARCHIVE_TIMESTAMP_FORMAT);
						dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
						String archiveTs = dateFormat.format(a.getCreatedOn());
						log.error(archiveTs);
						archiveList.stream()
								.map(FileVO::getFsPath)
								.filter(p -> p.endsWith("_".concat(archiveTs)))
								.findFirst()
								.ifPresent(lineage::setResultUri);

					}

					lineage.setSize(a.getSizeInByte());
					lineage.setTimeOfOperation(a.getCreatedOn());

					Map<String, String> filteredMeta = Maps.newHashMap(meta);
					filteredMeta.remove(FileService.DLS_INTERNAL);
					filteredMeta.remove(FileService.DLS_LINEAGE);
					filteredMeta.remove(FileService.DLS_RENAMED_TO);
					filteredMeta.remove(FileService.DLS_ARCHIVE_TO);
					lineage.setMetadata(Joiner.on(",").withKeyValueSeparator("=").join(filteredMeta));
					lineages.add(lineage);
					if (a.getDeleted()) {
						if (null != metaString && metaString.contains(FileService.DLS_RENAMED_TO)) {
							lineages.add(Lineage.builder().operation("RENAME")
									.renamedUri(Splitter.on(',').withKeyValueSeparator('=').split(metaString).get(FileService.DLS_RENAMED_TO))
									.timeOfOperation(a.getDeletedOn()).build());
						} else {
							lineages.add(Lineage.builder().operation("DELETE").resultUri(a.getFsPath()).timeOfOperation(a.getDeletedOn()).build());
						}
					}
				});
		lineages.sort(Comparator.comparing(Lineage::getTimeOfOperation));
		return lineages;

	}

	/**
	 * Build directory catalog
	 * @param apiKey
	 * @param dlsKey
	 * @param query
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public DirectoryCatalog getDirectoryCatalog(String apiKey, String dlsKey, CatalogQuery query, Integer fetchSize)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		if(null != query.getDirectory()) {
			String dir = StringUtils.trimTrailingCharacter(query.getDirectory(), '/');
			if (!dir.startsWith("/")) {
				dir = "/".concat(dir);
			}
			query.setDirectory(dir);
		}

		String directory = query.getDirectory();

		UserVO user = uservice.authorize(apiKey, dlsKey);
		query.setPageSize(Integer.MAX_VALUE);

		List<FileDetail> fileDetails = Lists.newArrayList();

		try {
			fileDetails = this.getCatalog(apiKey, dlsKey, query, true, fetchSize).getResult();
		} catch (DlsNotFoundException e) {
			// its Ok
		}


		if (null == directory) {
			directory = "%";
		}

		List<DirectoryVO> directoryList = directoryRepo.getDirectoryNamesByPermittedUser(directory.concat("%"),
				user.getTenant().getId(), user.getId());
		if(null == directoryList || directoryList.isEmpty()) {
			directoryList = Lists.newArrayList(DirectoryVO.builder().directory(ROOT_DIR).permission(Lists.newArrayList()).build());
		}
		Map <String,FileDetail> shared = Maps.newHashMap();

		DirectoryCatalog catalog = Flux.fromIterable(directoryList)
				.distinct()
				.map(this::sanitize)
				.sort(Comparator.comparingInt(d -> StringUtils.countOccurrencesOf(d.getDirectory(), SLASH)))
				.zipWith(Flux.fromIterable(fileDetails)
						.collectMultimap(f ->(null == f.getDirectory()) ? ROOT_DIR : f.getDirectory() , f -> {
							if(null == f.getDirectory()) {
								f.setDirectory(ROOT_DIR);
							}
							return f;
						})
						.repeat()
				)
				.map(t -> toDirectory(t, user.getId(), false, null))
				.reduce(this::merge)
				.block();
		if (null == catalog ) {
			throw new DlsNotFoundException();
		}
		List <FileDetail> sharedFiles = Lists.newArrayList(shared.values().iterator());
		if(null == catalog.getFiles()) {
			catalog.setFiles(sharedFiles);
		} else {
			catalog.getFiles().addAll(sharedFiles);
		}
		return catalog;

	}

	public DirectoryVO sanitize(DirectoryVO directory) {
		directory.setDirectory(ROOT_DIR.concat(Joiner.on('/').skipNulls().join(
				Splitter.on('/').omitEmptyStrings().split(directory.getDirectory()))));
		return directory;
	}

	private DirectoryCatalog toDirectory(Tuple2<DirectoryVO, Map<String, Collection<FileDetail>>> tuple,
										 Long userId, Boolean countOnly, Map<Long, Integer> fileCountMap) {

		DirectoryVO directoryVO = tuple.getT1();
		String path = directoryVO.getDirectory();
		Map<String, Collection<FileDetail>> fileDirectoryMap = tuple.getT2();

		DirectoryCatalog root = null;
		do {

			if(path.equalsIgnoreCase(ROOT_DIR)) {
				break;
			}
			String permittedAction = directoryVO.getPermission()
					.stream()
					.filter(p -> Lists.newArrayList(ArrayUtils.addAll(p.getAcquiredUser(), p.getPermittedUser())).contains(userId) )
					.map(PermissionVO::getAction)
					.reduce(String::concat)
					.orElse(null);
			DirectoryCatalog node = DirectoryCatalog.builder()
					.name(path.substring(path.lastIndexOf('/') + 1))
					.type(DIRECTORY)
					.createdOn(directoryVO.getCreatedOn())
					.permittedAction(permittedAction)
					.path(path).build();

			Collection<FileDetail> files = fileDirectoryMap.get(path);
			if (null != files) {
				node.setFiles((List<FileDetail>) files);
				node.setFileCount(files.size());
			}
			if(null != fileCountMap) {
				node.setFileCount(fileCountMap.get(directoryVO.getId()));
			}
			if(countOnly) {
				node.setFiles(null);
			}
			if (root != null) {
				node.setSubDirectories(Lists.newArrayList(root));
			}
			path = path.substring(0, path.lastIndexOf('/'));
			root = node;

		} while (!path.isEmpty());

		Collection<FileDetail> files = fileDirectoryMap.get(ROOT_DIR);

		return DirectoryCatalog.builder().type(DIRECTORY).path(ROOT_DIR).name(ROOT_DIR)
				.files((files != null && !countOnly) ? (List<FileDetail>) files : null)
				.fileCount((files != null) ? files.size() : null)
				.subDirectories((null == root) ? null : Lists.newArrayList(root)).build();
	}

	private DirectoryCatalog toDirectoryNameOnly(Tuple2<DirectoryVO, Map<String, Collection<FileDetail>>> tuple) {

		DirectoryVO directoryVO = tuple.getT1();
		String path = directoryVO.getDirectory();
		Map<String, Collection<FileDetail>> fileDirectoryMap = tuple.getT2();

		DirectoryCatalog root = null;
		do {

			if(path.equalsIgnoreCase(ROOT_DIR)) {
				break;
			}

			DirectoryCatalog node = DirectoryCatalog.builder()
//					.name(path.substring(path.lastIndexOf('/') + 1))
					.createdOn(directoryVO.getCreatedOn())
					.createdBy(directoryVO.getCreatedBy().getDlsUser())
					.path(path).build();

			Collection<FileDetail> files = fileDirectoryMap.get(path);
			if (null != files) {
				node.setFiles((List<FileDetail>) files);
				node.setFileCount(files.size());
			}

			if (root != null) {
				node.setSubDirectories(Lists.newArrayList(root));
			}
			path = path.substring(0, path.lastIndexOf('/'));
			root = node;

		} while (!path.isEmpty());


		return DirectoryCatalog.builder()
//				.type(DIRECTORY)
				.path(ROOT_DIR)
//				.name(ROOT_DIR)
				.subDirectories((null == root) ? null : Lists.newArrayList(root)).build();
	}


	private DirectoryCatalog merge(DirectoryCatalog catalog, DirectoryCatalog node) {

		if (null == catalog.getSubDirectories()) {
			catalog.setSubDirectories(node.getSubDirectories());
			return catalog;
		}
		if (null == node.getSubDirectories()) {
			return catalog;
		}
		List<DirectoryCatalog> subDirectories = Lists.newArrayList(catalog.getSubDirectories());
		AtomicBoolean matchedNode = new AtomicBoolean(false);
		subDirectories.forEach(d -> {
			DirectoryCatalog next = node.getSubDirectories().get(0);
			if (d.getPath().equalsIgnoreCase(next.getPath())) {
				merge(d, next);
				matchedNode.set(true);
			}
		});
		if (!matchedNode.get()) {
			catalog.getSubDirectories().add(node.getSubDirectories().get(0));
		}

		return catalog;
	}

	/**
	 * Get the tree of organizational hierarchy along with admins and users
	 * @param apiKey
	 * @param dlsKey
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public OrgPos getOrganizationTree(String apiKey, String dlsKey)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		UserVO user = uservice.authorize(apiKey, dlsKey);
		List<UserVO> vos = userRepo.findAll(Example.of(UserVO.builder().tenant(user.getTenant()).build()));
		return Flux.fromIterable(vos)
				.filter(u -> null != u.getOrgPosition())
				.flatMap(this::toUserOrgPositionMap)
				.groupBy(UserOrgPositionMap::getFullOrgPosition)
				.flatMap(Flux::collectList)
				.map(this::toOrgPos)
				.sort(Comparator.comparingInt(u -> StringUtils.countOccurrencesOf(u.getFullPosition(), SLASH)))
				.reduce(this::merge)
				.blockOptional().orElseThrow(DlsNotFoundException::new);

	}

	private OrgPos merge(OrgPos o1, OrgPos o2) {
		if(o1.getFullPosition().concat("/").concat(o2.getPosition()).equalsIgnoreCase(o2.getFullPosition())) {
			o1.getOrganization().add(o2);
		} else {
			o1.getOrganization().forEach(o -> merge(o, o2));
		}

		return o1;
	}

	private OrgPos toOrgPos (List <UserOrgPositionMap> uList) {
		return OrgPos.builder()
				.position(uList.get(0).getImmediateOrgPosition())
				.fullPosition(uList.get(0).getFullOrgPosition())
				.admins(uList.stream().filter(UserOrgPositionMap::getAdmin)
						.map(UserOrgPositionMap::getUserName).collect(Collectors.toList()))
				.users(uList.stream().filter( u -> !u.getAdmin())
						.map(UserOrgPositionMap::getUserName).collect(Collectors.toList()))
				.organization(Lists.newArrayList())
				.build();
	}

	private Flux<UserOrgPositionMap> toUserOrgPositionMap (UserVO vo) {
		return Flux.fromArray(vo.getOrgPosition())
				.map (p -> UserOrgPositionMap.builder()
						.fullOrgPosition(p)
						.immediateOrgPosition(Errors.suppress().getWithDefault(() -> p.substring(p.lastIndexOf('/')+1), p))
						.admin(vo.getAdmin())
						.userName(vo.getDlsUser())
						.build());
	}

	/**
	 *
	 * @param apiKey
	 * @param dlsKey
	 * @param startDirectory
	 * @param immediateOnly
	 * @return
	 * @throws DlsSecurityException
	 * @throws DlsPrivacyException
	 * @throws DlsNotFoundException
	 */
	public DirectoryCatalog getDirectoryCatalogCount(String apiKey, String dlsKey, String startDirectory, Boolean immediateOnly)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		if(startDirectory != null) {
			startDirectory = StringUtils.trimTrailingCharacter(startDirectory, '/');
			if(!startDirectory.startsWith("/")) {
				startDirectory = "/".concat(startDirectory);
			}
		}
//		String directory =  startDirectory == null ? "%" : startDirectory;
		UserVO user = uservice.authorize(apiKey, dlsKey);


		List<FileDetail> fileDetails = Lists.newArrayList();


		List <CatalogVO> catalogVOList;

		immediateOnly = immediateOnly != null && immediateOnly;

		if(startDirectory == null) {
			if(immediateOnly) {
				// only immediate sub-directory of root
				catalogVOList = catalogRepo.findByTypeAndParentIsNullAndPermittedUser(CATALOG_TYPE_DIRECTORY, user.getId());
			}
			else {
				// entire directory structure
				catalogVOList = catalogRepo.findByTypeAndPermittedUser(CATALOG_TYPE_DIRECTORY, user.getId());
			}
		} else {
			if(immediateOnly) {
				// only immediate sub-directory of a directory
				catalogVOList = catalogRepo.findByTypeAndParentAndPermittedUser(CATALOG_TYPE_DIRECTORY, startDirectory, user.getId());
			}
			else {
				// entire directory structure below a directory
				catalogVOList = catalogRepo.findByTypeAndParentLikeAndPermittedUser(CATALOG_TYPE_DIRECTORY, startDirectory, startDirectory.concat("/%"), user.getId());
			}
		}
		/*int count = Optional.ofNullable(startDirectory)
				.map(d ->  StringUtils.countOccurrencesOf(d,"/"))
				.orElse(0) ;

		if(immediateOnly) {
			catalogVOList = catalogVOList.stream()
					.filter(d -> StringUtils.countOccurrencesOf(d.getPath(),"/") <= count + 1)
					.collect(Collectors.toList());
		}*/
		if(catalogVOList == null || catalogVOList.isEmpty()) throw new DlsNotFoundException();

		Map<Long, Integer> fileCount = Flux.fromIterable(catalogVOList)
				.collectMap(CatalogVO::getId, CatalogVO::getFileCount).block();
		DirectoryCatalog catalog = Flux.fromIterable(catalogVOList)
				.map(c -> DirectoryVO.builder()
						.id(c.getId())
						.directory(c.getPath())
						.createdOn(c.getCreatedOn())
						.permission(List.of(PermissionVO.builder().action("RWD").permittedUser(user.getId()).build()))
						.build())
				.distinct()
				.map(this::sanitize)
				.sort(Comparator.comparingInt(d -> StringUtils.countOccurrencesOf(d.getDirectory(), SLASH)))
				.zipWith(Flux.fromIterable(fileDetails)
						.collectMultimap(f -> (null == f.getDirectory()) ? ROOT_DIR : f.getDirectory(), f -> {
							if (null == f.getDirectory()) {
								f.setDirectory(ROOT_DIR);
							}
							return f;
						})
						.repeat()
				)
				.map(t -> toDirectory(t, user.getId(), true, fileCount))
				.reduce(this::merge)
				.block();

		if(startDirectory != null) {
			while (!Objects.equals(catalog.getPath(), startDirectory)) {
				if(null != catalog.getSubDirectories()) {
					for (DirectoryCatalog c : catalog.getSubDirectories()) {
						catalog = c;
						if (Objects.equals(catalog.getPath(), startDirectory)) break;
					}
				}
			}
		} else if(catalog != null){

			catalog.setFileCount(catalogRepo.countByTypeAndParentIsNullAndPermittedUser(CATALOG_TYPE_FILE, user.getId()));
		}
		return catalog;
	}



	@Builder
	@Data
	private static class UserOrgPositionMap {

		private String userName;
		private Boolean admin;
		private String fullOrgPosition;
		private String immediateOrgPosition;


	}
}
