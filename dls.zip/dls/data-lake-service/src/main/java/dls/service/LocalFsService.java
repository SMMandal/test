package dls.service;

import com.google.common.base.Joiner;
import dls.exception.DlsValidationException;
import dls.repo.FileRepo;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.FileSystemUtils;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Mono;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Objects;
import java.util.stream.Stream;

import static java.nio.file.Files.*;

@Slf4j

@Service
public class LocalFsService
		implements IFileManagementService {
	
	@Autowired private FileRepo fileRepo;		

	@Value("${local.fs.failsafe.path}") 
	private String failsafeFilePath;


	@Value("${dls.enable.hdfs}")
	private Boolean enableHDFS;

	

	public void write(@NonNull MultipartFile multipart, final String fsPath, final Long fileId) {
		Mono.fromSupplier(() -> {		
						
			try {
				String userRoot = fsPath.substring(0,fsPath.lastIndexOf('/'));
				String baseDir = failsafeFilePath.concat("/" + userRoot + "/" /*+ fileId*/);
				File file = new File(baseDir.concat("/").concat(Objects.requireNonNull(multipart.getOriginalFilename())));
				File fileDir = new File(baseDir);
				
				if (!file.exists()) {					
					if(fileDir.mkdirs()) {
						log.debug("Storage directory is created");
					} 
			    }		
				
				multipart.transferTo(file);

				if(enableHDFS) throw new DlsValidationException("Hadoop has been wrongly enabled but no infrastructure is provided");
				return true;
				
			} catch (Exception e) {
				log.error("Fatal exception in storing uploaded file {} in DLS local. {}",fsPath, e.getMessage());
				return false;
			}

			
		})
		.subscribe(status -> fileRepo.findById(fileId).ifPresent(o -> {
			if(!enableHDFS) {
				o.setStorage("L");
				o.setUploaded(true);
			} else {
				o.setStorage("H");
				o.setUploaded(status);
			}
			fileRepo.saveAndFlush(o);
		}));
		
	}



	@Override
	public void delete( boolean recursive, String fsPath) {

		try {
			Path path = Paths.get(failsafeFilePath.concat("/" + fsPath));

			FileSystemUtils.deleteRecursively(path);
//			Path parentPath = path.getParent();
			// commented the below code due to issue in AFS for directory delete
			/*while (!Files.newDirectoryStream(parentPath).iterator().hasNext()) {
				FileSystemUtils.deleteRecursively(parentPath);
				parentPath = parentPath.getParent();
			}*/
		} catch (IOException e) {
			log.error("Error deleting file from local {}", e.getMessage());
		}


	}


	@Override

	public void renameDirectory(@NonNull String srcDir, @NonNull String destDir) throws IOException {

		log.info("from {} to {}", srcDir, destDir);
		final Path srcPath = Paths.get(failsafeFilePath.concat("/").concat(srcDir));
		final Path destPath = Paths.get(failsafeFilePath.concat("/").concat(destDir));

		if(!exists(destPath.getParent())) {
			createDirectories(destPath.getParent());
		}


		if(Files.notExists(srcPath)) {
			log.error("Error in directory move for {} to {}", srcDir, destDir);
			return;
		}

		move(srcPath, destPath);
		try(Stream<Path> list = list(srcPath.getParent())) {
			if(list.count() ==0) {
				Files.deleteIfExists(srcPath.getParent());
			}
		}

	}
	@Override
	public boolean archive(String fsPath, String createdOn) {

		String path = failsafeFilePath.concat("/"+fsPath);
		return new File(path).renameTo(new File(path.concat("_" + createdOn)));
	}
	@Override
	public void writeBundle(File bundleFile, String fsPath, Long fileId) {
		Mono.fromSupplier(() -> {

			try {
				Path destination = Paths.get(Joiner.on('/').join(failsafeFilePath, fsPath));
				if(Files.notExists(destination.getParent())) {
					Files.createDirectories(destination.getParent());
				}
				Files.move(bundleFile.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);
				log.info("Uploaded to NFS");
				return true;

			} catch (IOException e) {
				log.error("Fatal exception in storing uploaded file {} in DLS local. {}",fsPath, e.getMessage());
				return false;
			}

		})
				.subscribe(status -> fileRepo.findById(fileId).ifPresent(o -> {
					o.setUploaded(status);
					fileRepo.saveAndFlush(o);
					log.info("Status of bundle file upload updated in database");
				}));
	}

	@Override
	public void append(@NonNull String fsPath, @NonNull MultipartFile multipartFile) {

	}
}
