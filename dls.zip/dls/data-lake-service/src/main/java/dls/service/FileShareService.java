package dls.service;

import com.google.common.collect.Maps;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.repo.FileRepo;
import dls.repo.FileShareRepo;
import dls.repo.UserRepo;
import dls.vo.FileShareVO;
import dls.vo.FileVO;
import dls.vo.UserVO;
import lombok.NonNull;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class FileShareService {

	@Autowired private UserService uservice;
	@Autowired private FileShareRepo fsRepo;
	@Autowired private FileRepo fileRepo;
	@Autowired private DlsServiceHelper dhelper;
	@Autowired private UserRepo userRepo;
//	@Autowired private DirectoryService directoryService;
	
	public void createShare(String apiKey, String dlsKey, String dlsUser, String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {
		
		UserVO user = uservice.authorize(apiKey, dlsKey);
		
		if(user.getDlsUser().compareToIgnoreCase(dlsUser) == 0)
			throw new DataIntegrityViolationException("useless.share");
		
		FileVO file = dhelper.validateFile(user, fileURI);
		if(file.getDirectory() != null) {
			throw new DataIntegrityViolationException("invalid.directory.share");
		}
		UserVO grantee = Optional.ofNullable(userRepo.findByTenantAndDlsUser(user.getTenant(), dlsUser))
				.orElseThrow(() -> new DataIntegrityViolationException("invalid.dlsUser"));
		fsRepo.saveAndFlush(FileShareVO.builder().file(file).sharedOn(Timestamp.from(Instant.now())).user(grantee).build());
		file.setSharedTo(ArrayUtils.add(file.getSharedTo(), grantee.getDlsUser()));
		fileRepo.save(file);

		// create a read-only share to directory
//		if(null != file.getDirectory()) {
//			directoryService.createPermission(
//					Lists.newArrayList(Directory.builder()
//							.directory(file.getDirectory().getDirectory())
//							.permissions(Lists.newArrayList(Permission.builder().action("R").users().build()))
//							.build()),
//					apiKey, dlsKey);
//		}
	}

	public Map<String, List<String>> getShare(String apiKey, String dlsKey, String dlsUser,  Boolean showTime)
			throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {
		
		UserVO user = uservice.authorize(apiKey, dlsKey);
		
		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");
		FileShareVO share = FileShareVO.builder().build();
		FileVO fileVO = FileVO.builder().user(user).deleted(false).build();
		share.setFile(fileVO);
		if(null != dlsUser) {			
			share.setUser(Optional.ofNullable(userRepo.findByTenantAndDlsUser(user.getTenant(), dlsUser)).orElseThrow(DlsNotFoundException::new));
		}
		List <FileShareVO> shares = fsRepo.findAll(Example.of(share, matcher));
		if(shares.isEmpty())
			throw new DlsNotFoundException();
		Map<String, List<String>> sharemap = Maps.newTreeMap();

		Flux.fromIterable(shares)
				.groupBy(s -> s.getUser().getDlsUser(),
						s -> (showTime && null != s.getSharedOn().toString())
						? s.getFile().getFsPath().concat(" at ")
								.concat(new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss z")
										.format(s.getSharedOn()))
						: s.getFile().getFsPath())

				.subscribe(f -> f.buffer().subscribe(v -> sharemap.put(f.key(), v)));

//		shares.forEach(sh -> {
//			String du = sh.getUser().getDlsUser();
//
//			List <String> paths = Optional.ofNullable(sharemap.get(du)).orElseGet(Lists::newArrayList);
//			paths.add(sh.getFile().getFsPath());
//			sharemap.put(du, paths);
//		});
		return sharemap;
	}

	@Transactional("transactionManager")
	public void deleteShare(String apiKey, String dlsKey, @NonNull String dlsUser, @NonNull String fileURI)
			throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {
		
		UserVO user = uservice.authorize(apiKey, dlsKey);
		UserVO grantee = Optional.ofNullable(userRepo.findByTenantAndDlsUser(user.getTenant(), dlsUser))
				.orElseThrow(() -> new DataIntegrityViolationException("invalid.dlsUser"));

		FileVO file = dhelper.validateFile(user, fileURI);
//		FileShareVO vo = FileShareVO.builder().user(grantee).file(file).build();
//		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues().withIgnorePaths("id");
//		List <FileShareVO> results = fsRepo.findAll(Example.of(vo, matcher));
		List <FileShareVO> results = fsRepo.findByUserIdAndFileId(grantee.getId(), file.getId());
		if( results.isEmpty()) {
			throw new DlsNotFoundException();
		}
		fsRepo.deleteAll(results);
		Optional.ofNullable(file.getSharedTo())
				.ifPresent(users -> {
					String[] us = ArrayUtils.removeElement(users, dlsUser);
					file.setSharedTo((us.length > 0) ? us : null);
					fileRepo.save(file);
				});
	}

}
