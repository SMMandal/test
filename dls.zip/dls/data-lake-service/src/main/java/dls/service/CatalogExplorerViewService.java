package dls.service;

import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import dls.bean.CatalogExploreQuery;
import dls.bean.ExploreCatalog;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.repo.*;
import dls.vo.CatalogVO;
import dls.vo.MetadataViewVO;
import dls.vo.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.DataException;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static dls.bean.CatalogExploreQuery.Parser.toMetadataList;
import static dls.bean.CatalogExploreQuery.PropertyNames.*;
import static dls.repo.MetadataViewSpecification.METADATA_VALUE_PATTERN;
import static java.util.stream.Collectors.groupingBy;

@Service
@Slf4j
public class CatalogExplorerViewService {

    public static final char CATALOG_TYPE_FILE = 'F';
    public static final char CATALOG_TYPE_DIRECTORY = 'D';
    @Autowired
    private CatalogRepo repo;
    @Autowired
    private MetadataViewRepo metaRepo;
    @Autowired private UserService uservice;
    @Autowired private UserRepo userRepo;

    @Autowired private CatalogTableMetaQueryHelper catalogTableMetaQueryHelper;

    @Value("${dls.catalog.default.page-size}")
    private int defaultPageSize;


    public ExploreCatalog getCatalogExplorer(String apiKey, String dlsKey, CatalogExploreQuery query)
            throws DlsSecurityException, DlsNotFoundException,
            DlsPrivacyException, DlsValidationException  {

        UserVO user = uservice.authorize(apiKey, dlsKey);

        Pageable page = buildPaginationAndSortQuery(query);

//        List <String> metaList = toMetadataList(query.getMetadata());

        List<String> and = query.getAnd() == null ? Lists.newArrayList() : query.getAnd() ;

        Specification<CatalogVO>  specification =
                buildSpecOnList(query.getName(), ExplorerViewSpecification::hasNameLike, null, and.contains(name_));

        specification = buildSpecOnList(query.getPath(), ExplorerViewSpecification::hasPathLike, specification, and.contains(path_));

        specification = buildSpecOnList(query.getParent(), ExplorerViewSpecification::hasParentLike, specification, and.contains(parent_));

        specification = buildSpecOnList(query.getSavepoint(), ExplorerViewSpecification::hasSavepointLike, specification, and.contains(parent_));

        specification = prepareCreatedBySpecification(user.getTenant().getId(), query.getUser(), specification, and.contains(user_));

        specification = prepareSizeSpecification(query.getSize(), specification, and.contains(size_));

        specification = prepareFileCountSpecification(query.getFileCount(), specification, and.contains(fileCount_));

        specification = prepareTemporalSpecification(query.getTime(), specification, and.contains(time_));

        specification = prepareNameRegexSpecification(query.getNameRegex(), specification, and.contains(nameRegex_));

        specification = prepareMetadataSpecification(query.getMetadata(), specification, and.contains(metadata_));

        specification = prepareFetchSpecification(query.getFetch(), specification);

        specification = preparePermittedUserSpecification(user.getId(), specification);

        specification = prepareTransferSuccessSpecification(true, specification);

        try {
            Page<CatalogVO> data = repo.findAll(specification, page);

            return toExplorerCatalog(data, page, user);
        } catch (DataIntegrityViolationException e) {
            if(e.getCause() instanceof DataException) {
                throw new DlsValidationException(((DataException)e.getCause()).getCause().getLocalizedMessage());
            }
            throw new DlsNotFoundException();
        } catch (Exception e) {
            e.printStackTrace();
            throw new DlsNotFoundException();
        }
    }



    private ExploreCatalog toExplorerCatalog(Page<CatalogVO> data, Pageable page, UserVO user) throws DlsNotFoundException {

        if(data.isEmpty()) throw new DlsNotFoundException();

        List <ExploreCatalog.Record> files = Lists.newArrayList();
        List <ExploreCatalog.Record> directories = Lists.newArrayList();

        data.stream()
                .map(e -> toExploreCatalogRecord(e, user))
                .forEach(r -> {
                    if (r.type().equalsIgnoreCase(String.valueOf(CATALOG_TYPE_FILE))) {
                        files.add(r);
                    } else {
                        directories.add(r);
                    }
                });

        return new ExploreCatalog(page.getPageNumber() + 1,
                data.getTotalPages(),
                data.stream().count(), directories, files);
    }


    /**
     * search by metadata
     * @param metadata
     * @param previousSpec
     * @param asAnd
     * @return
     */
    private Specification<CatalogVO> prepareMetadataSpecification(String metadata,
                                                                  Specification<CatalogVO> previousSpec,
                                                                  Boolean asAnd) {

       List <Long> ids = Optional.ofNullable(metadata)
               .map(catalogTableMetaQueryHelper::findByMetadata)
               .map(Stream::toList)
               .orElse( new ArrayList<>());
        /*List<String> metaAndCondList = metaList.stream()
                .filter(m -> m.contains("&"))
                .collect(Collectors.toList());

        List<Long> ids = getTypeIdsByMetadataAndCond(metaAndCondList);
        ids.addAll(getTypeIdsByMetadataOrCond(metaList.stream()
                .filter(m -> !m.contains("&"))
                .toList()));*/
//        if(ids == null) ids = new ArrayList<>();
        if(ids.isEmpty() && metadata != null) {

            ids = new ArrayList<>();
            ids.add(Long.MAX_VALUE);
        }
        return prepareTypeIdSpecification(ids, previousSpec, asAnd);




    }
//    private Specification<CatalogVO> prepareMetadataSpecification(List<String> metaList,
//                                                                  Specification<CatalogVO> previousSpec,
//                                                                  Boolean asAnd) {
//
//        List<String> metaAndCondList = metaList.stream()
//                .filter(m -> m.contains("&"))
//                .collect(Collectors.toList());
//
//        List<Long> ids = getTypeIdsByMetadataAndCond(metaAndCondList);
//        ids.addAll(getTypeIdsByMetadataOrCond(metaList.stream()
//                .filter(m -> !m.contains("&"))
//                .toList()));
//
//        if(ids.isEmpty() && !metaList.isEmpty())
//            ids.add(Long.MAX_VALUE);
//        return prepareTypeIdSpecification(ids, previousSpec, asAnd);
//
//
//    }

    private Specification<CatalogVO> preparePermittedUserSpecification(Long userId,
                                                                       Specification<CatalogVO> previousSpec) {
        return Optional.ofNullable(userId)
                .map(ExplorerViewSpecification::hasPermittedUser)
                .map(tis ->
                        Optional.ofNullable(previousSpec)
                                .map(ps -> ps.and(tis))
                                .orElse(tis))
                .orElse(previousSpec);
    }

    private Specification<CatalogVO> prepareTransferSuccessSpecification(Boolean uploaded,
                                                                         Specification<CatalogVO> previousSpec) {
        return Optional.ofNullable(uploaded)
                .map(ExplorerViewSpecification::hasUploaded)
                .map(tis ->
                        Optional.ofNullable(previousSpec)
                                .map(ps -> ps.and(tis))
                                .orElse(tis))
                .orElse(previousSpec);
    }


    private Specification<CatalogVO> prepareNameRegexSpecification(String nameRegex,
                                                                   Specification<CatalogVO> previousSpec,
                                                                   Boolean asAnd) {

        try {
            return Optional.ofNullable(nameRegex)
                    .map(r -> "^" + r + "$")
//                    .map(repo::getIdOfMatchingNameRegex)
                    .map(ExplorerViewSpecification::hasNameRegex)
                    .map(nrs ->
                            Optional.ofNullable(previousSpec)
                                    .map(ps -> asAnd ? ps.and(nrs) : ps.or(nrs))
                                    .orElse(nrs)
                    )
//                    .map(ids -> prepareTypeIdSpecification(ids, previousSpec, asAnd))
                    .orElse(previousSpec);
        } catch (DataIntegrityViolationException e) {
            log.error(e.getMessage());
            throw new DlsValidationException("Invalid nameRegex - " + nameRegex);
        }
    }

    private Specification<CatalogVO> prepareTypeIdSpecification(List<Long> ids,
                                                                Specification<CatalogVO> previousSpec,
                                                                Boolean asAnd) {

        ids = ids.isEmpty() ? null : ids;

        return Optional.ofNullable(ids)
                .map(ExplorerViewSpecification::hasTypeIdIn)
                .map(tis ->
                        Optional.ofNullable(previousSpec)
                                .map(ps -> asAnd ? ps.and(tis) : ps.or(tis))
                                .orElse(tis))
                .orElse(previousSpec);
    }

    private Specification<CatalogVO> prepareFetchSpecification(String fetch, Specification<CatalogVO> previousSpec) {

        return Optional.ofNullable( switch (Strings.nullToEmpty(fetch))
                {
                    case "directoryOnly" -> CATALOG_TYPE_DIRECTORY;
                    case "fileOnly" -> CATALOG_TYPE_FILE;
                    default -> null;
                } )
                .map(ExplorerViewSpecification::hasType)
                .map(fs ->
                        Optional.ofNullable(previousSpec)
                                .map(ps -> ps.and(fs))
                                .orElse(fs))
                .orElse(previousSpec);
    }

    private Pageable buildPaginationAndSortQuery(CatalogExploreQuery query) {

        return PageRequest.of(
                Optional.ofNullable(query.getPageNo()).map(p -> --p).orElse(0),
                Optional.ofNullable(query.getPageSize()).orElse(defaultPageSize),
                Optional.ofNullable(query.getSort())
                        .map(sortBy -> buildSortQuery(query.getFetch(),
                                switch (Strings.nullToEmpty( query.getOrder())) {
                                    case "desc" -> Sort.by(Sort.Order.desc(sortBy).ignoreCase()) ;
                                    default -> Sort.by(Sort.Order.asc(sortBy).ignoreCase());
                                }))
                        .orElse(buildSortQuery(query.getFetch(), Sort.unsorted())));
    }

    private Sort buildSortQuery(String fetch, Sort sortBy) {

        return switch (Strings.nullToEmpty(fetch)) {
            case "fileFirst" -> Sort.by("type").descending().and(sortBy);
            case "directoryFirst" -> Sort.by("type").ascending().and(sortBy);
            default -> sortBy;
        };
    }

    private List<Long> getTypeIdsByMetadataOrCond(List<String> metaList) {

        if(metaList.isEmpty()) return Lists.newArrayList();

        Specification<MetadataViewVO> specification = metaList.stream()
                .flatMap(m -> Arrays.stream(m.split(" *, *")))
                .map(MetadataViewSpecification::hasNameValueLike)
                .reduce(Specification::or)
                .get();
        return metaRepo.findAll(specification)
                .stream()
                .map(MetadataViewVO::getTypeId)
                .toList();

    }
    private List<Long> getTypeIdsByMetadataAndCond(List<String> metaList) {

        if(metaList.isEmpty()) return Lists.newArrayList();

        Specification<MetadataViewVO> specification = metaList.stream()
                .flatMap(m -> Arrays.stream(m.split(" *& *")))
                .map(MetadataViewSpecification::hasNameValueLike)
                .reduce(Specification::or)
                .get();

        Splitter splitter = Splitter
                .onPattern(" *& *")
                .trimResults()
                .omitEmptyStrings();


        List<MetadataViewVO> query = metaList.stream().flatMap(splitter::splitToStream)
                .map(String::toLowerCase)
                .map(String::trim)
                .map(s -> {
                    var split = s.split(" *= *");
                    String name = split.length > 1 || !split[0].matches(METADATA_VALUE_PATTERN) ? split[0] : null;
                    String value = split.length > 1 && split[1].matches(METADATA_VALUE_PATTERN) ? split[1]
                            : split[0].matches(METADATA_VALUE_PATTERN) ? split[0] : null;
                    return MetadataViewVO.builder().name(name).value(value).build();
                }).toList();

        List<Long> typeIds = metaRepo.findAll(specification)
                .stream()
                .map(MetadataViewVO::getTypeId)
                .toList();

        List<MetadataViewVO> metadataVOs = metaRepo.findByTypeIdIn(typeIds);
        Map<Long, List<MetadataViewVO>> data = metadataVOs.stream()
                .collect(groupingBy(MetadataViewVO::getTypeId));

        List <Long> matching = Lists.newArrayList();

        data.forEach((id, l) -> {
            boolean matched = query.stream().allMatch(q ->
                l.stream()
                        .anyMatch(d -> compareMetadata(q,d))
            );
            if(matched) matching.add(id);
        });
        return matching;
    }

    private boolean compareMetadata(MetadataViewVO query, MetadataViewVO data) {

        return Optional.ofNullable(query.getName()).map(n -> data.getName().matches("(?i)" + n.replace("*",".*"))).orElse(true) &&
                Optional.ofNullable(query.getValue())
                        .map(v -> v.replace("'",""))
                        .map(v -> data.getValue().matches("(?i)" + v.replace("*",".*"))).orElse(true);
    }



    private Specification<CatalogVO> prepareSizeSpecification(String size,
                                                              Specification<CatalogVO> previousSpec,
                                                              Boolean asAnd) {
        return Optional.ofNullable(size)
                .map(ExplorerViewSpecification::hasSize)
                .map(ss -> Optional.ofNullable(previousSpec)
                        .map(ps ->  asAnd ? ps.and(ss) : ps.or(ss))
                        .orElse(ss))
                .orElse(previousSpec);

    }

    private Specification<CatalogVO> prepareFileCountSpecification(String fileCount,
                                                                   Specification<CatalogVO> previousSpec,
                                                                   Boolean asAnd) {
        return Optional.ofNullable(fileCount)
                .map(ExplorerViewSpecification::hasFileCount)
                .map(ss -> Optional.ofNullable(previousSpec)
                        .map(ps ->  asAnd ? ps.and(ss) : ps.or(ss))
                        .orElse(ss))
                .orElse(previousSpec);
    }

    private Specification<CatalogVO> prepareTemporalSpecification(List<DateTime> temporalQuery,
                                                                  Specification<CatalogVO> previousSpec,
                                                                  Boolean asAnd) {
        return Optional.ofNullable(temporalQuery)

                .map(dates ->
                        switch (dates.size()) {
                            case 1 -> {
                                Timestamp start, end;
                                start = Timestamp.from(dates.get(0).toDate().toInstant());
                                end = Timestamp.from(dates.get(0).toDate().toInstant().plus(999999L, ChronoUnit.MICROS));
                                yield ExplorerViewSpecification.hasCreatedOnBetween(start,end);
                            }
//                                    ExplorerViewSpecification.hasCreatedOn(Timestamp.from(dates.get(0).toDate().toInstant()));
                            case 2 -> {
                                Timestamp start, end;
                                if(dates.get(0).isAfter(dates.get(1))) {
                                    start = Timestamp.from(dates.get(1).toDate().toInstant());
                                    end =Timestamp.from(dates.get(0).toDate().toInstant().plus(999999L, ChronoUnit.MICROS));
                                } else {
                                    start = Timestamp.from(dates.get(0).toDate().toInstant());
                                    end =Timestamp.from(dates.get(1).toDate().toInstant().plus(999999L, ChronoUnit.MICROS));
                                }
                                yield ExplorerViewSpecification.hasCreatedOnBetween(start,end);
                            }
                            default -> throw new DlsValidationException("Only two timestamps are allowed");
                        })
                .map(ts -> Optional
                        .ofNullable(previousSpec)
                        .map(ps -> asAnd ? ps.and(ts) : ps.or(ts))
                        .orElse(ts))
                .orElse(previousSpec);
    }

    private Specification<CatalogVO> prepareCreatedBySpecification(final Long tenantId,
                                                                   List<String> usernames,
                                                                   Specification<CatalogVO> previousSpec,
                                                                   Boolean asAnd) {
//        if(null != usernames && usernames.isEmpty()) usernames = null;

        return Optional.ofNullable(usernames)
                .flatMap(list -> list.stream().distinct()
//                        .map(user -> userRepo.getDlsUserByName(tenantId, user))
//                        .filter(Objects::nonNull)
                        .map(ExplorerViewSpecification::hasCreatedBy)
                        .reduce(Specification::or)
                )
                .map(s -> Optional
                        .ofNullable(previousSpec)
                        .map(ps -> asAnd ? ps.and(s) : ps.or(s))
                        .orElse(s)
                )
                .orElse(previousSpec);
    }

    private Specification<CatalogVO> buildSpecOnList(List<String> list,
                                                     java.util.function.Function<String, Specification<CatalogVO>> repoFunction,
                                                     Specification<CatalogVO> previousSpec,
                                                     Boolean asAnd) {
        if(null != list && list.isEmpty()) list = null;
        return Optional.ofNullable(list)
                .flatMap(l -> l.stream()
                        .map(repoFunction)
                        .reduce(Specification::or))
                .map(s -> Optional
                        .ofNullable(previousSpec)
                        .map(ps -> asAnd ? ps.and(s) : ps.or(s))
                        .orElse(s)
                )
                .orElse(previousSpec);
    }

    private ExploreCatalog.Record toExploreCatalogRecord(CatalogVO vo, UserVO user) {

        List< ExploreCatalog.Metadata > metadata = Optional.ofNullable(vo.getMetadataList())
                .map(list ->
            list.stream()
                    .filter(m -> null != m.name())
                    .map(m -> {
                var privacy = m.privateTo() != null ? "private" : null;
                var value = m.privateTo() != null && !m.privateTo().equals(user.getId()) ? "***" : m.value();
                String createdBy = Optional.ofNullable(m.createdBy())
                        .map( userRepo::getDlsUserById)
                        .orElse(null);
                return new ExploreCatalog.Metadata(m.name(), value, privacy, createdBy);

            }).collect(Collectors.toList())
        ).orElse(null);

//        String createdBy = Optional.ofNullable(vo.getCreatedBy())
//                .map( userRepo::getDlsUserById)
//                .orElse(null);

        return new ExploreCatalog.Record(
                vo.getType()+"",
                vo.getName(),
                vo.getPath(),
                vo.getParent(),
                vo.getSize() ,
                vo.getFileCount() ,
                vo.getSubdirCount(),
                vo.getCreatedOn(),
                vo.getCreatedBy(),
                metadata
        );
    }

}
