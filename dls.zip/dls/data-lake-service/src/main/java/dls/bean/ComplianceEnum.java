package dls.bean;

public enum ComplianceEnum {
    NONE,
    FAIR;
}
