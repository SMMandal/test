package dls.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@JsonInclude(Include.NON_NULL)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public @Data class FileDetail {

	private String savepoint;
	@JsonProperty("file-uri")
	private String fsPath;
	@JsonProperty("created-on")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy HH:mm:ss z")
	private Date createdOn;
	@JsonProperty("external-to-dls")
	private Boolean external;
	@JsonProperty("size-bytes")
	private Long size;
	@JsonProperty("transfer-success")
	private Boolean uploaded;
	@JsonProperty("deleted")
	private Boolean deleted;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy HH:mm:ss z")
	@JsonProperty("deleted-on")
	private Date deletedOn;
	@JsonProperty("meta-data")
	private String metadata;
	@JsonProperty("links-to")
	private String linksTo;
	@JsonProperty("links-from")
	private String linksFrom;
	@JsonProperty("shared-to")
	private String sharedTo;
	@JsonProperty("shared-by")
	private String sharedBy;
	@JsonProperty("shared-on")
	private String sharedOn;
	@JsonProperty("own-file")
	private Boolean ownFile;
	private String directory;
	private List <String> qualifier;
	private Boolean locked;
	private Boolean hidden;
	private String type;
	private Boolean bundled;
	private List<BundleDescriptor> bundle;


}
