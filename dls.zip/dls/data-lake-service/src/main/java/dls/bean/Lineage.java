package dls.bean;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Lineage {

    @JsonProperty("archive-uri")
    private String resultUri;
    @JsonProperty("renamed-uri")
    private String renamedUri;
    private String operation;
    @JsonProperty("time")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy HH:mm:ss z")
    private Date timeOfOperation;
    @JsonProperty("size")
    private Long size;
    @JsonProperty("meta-data")
    private String metadata;
}
