package dls.bean;

public enum DlsAction {
    VIEW,
    ADD,
    DOWNLOAD,
    DELETE,
    COPY,
    VERSION,
    MOVE,
    CHANGE_PERMISSION,
    EDIT_META_RULE,
    UPDATE_METADATA;

}
