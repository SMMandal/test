package dls.bean;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Schema(description="Create Comment while uploading file or later")
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public @Data @Builder class OrgPos {

	private String position;
	@JsonIgnore
	private String fullPosition;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<String> users;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<String> admins;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<OrgPos> organization;

}
