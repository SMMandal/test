package dls.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Pattern;

import static dls.bean.CatalogQuery.URI_QUERY_REGEX;

@Schema
@AllArgsConstructor
@NoArgsConstructor
@Builder
public @Data class Link {

//	@ApiModelProperty(example="savepoint/data.csv")
//	@Pattern(regexp="\\w+", message="{link.invalid.filepath}")
	@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
	@JsonProperty("lhs-file-uri")
	private String lhsFile;
	
//	@ApiModelProperty(example="generated_by")
	@Schema(example = "is_generated_by")
	@Pattern(regexp="\\w+", message="{link.invalid.relation}")
	private String relation;
	
//	@ApiModelProperty(example="savepoint/program.scala")
//	@Pattern(regexp="\\w+", message="{link.invalid.filepath}")
	@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
	@JsonProperty("rhs-file-uri")
	private String rhsFile;

	@Override
	public String toString() {
		return lhsFile + " " + relation + " " + rhsFile;
	}
}
