package dls.bean;

import lombok.Data;

@Data
public class Metadata {
	
	private String value;
	private String key;

}
