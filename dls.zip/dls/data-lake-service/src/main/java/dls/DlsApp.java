package dls;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Arrays;

@SpringBootApplication
@EnableAsync
//@EnableCircuitBreaker
@EnableScheduling
@PropertySource("classpath:ValidationMessages.properties")
@EnableAspectJAutoProxy
@EnableCaching
public class DlsApp implements WebMvcConfigurer /*WebFluxConfigurer*/ {
	
	public static void main(String[] args) {

		
		new SpringApplicationBuilder(DlsApp.class).properties("spring.config.name:dls").build().run(args);
		
	}

	@Value("${dls.swagger-host}") private String host;
//	@Value("${protocol}") private String protocol;
	@Value("${server.servlet.context-path}") private String context;
	@Value("${dls.buildNo}") private String buildNo;
	@Value("#{'${dls.swagger.paths}'.split(',')}")

	@Bean
	public OpenAPI dlsApi() {

		Components components = new Components().addSecuritySchemes("x-api-key",
				new SecurityScheme().type(SecurityScheme.Type.APIKEY)
						.in(SecurityScheme.In.HEADER).name("x-api-key"))
				.addSecuritySchemes("x-dls-key",
						new SecurityScheme().type(SecurityScheme.Type.APIKEY)
								.in(SecurityScheme.In.HEADER).name("x-dls-key"));
		Server server = new Server();
		server.url(host.concat(context));
//		server.description("DLS");
		return new OpenAPI()
//				.openapi("3.0.3")
				.addServersItem(server)
				.components(components)
				.info(apiInfo())
				.addSecurityItem(
						new SecurityRequirement().addList("x-api-key", Arrays.asList("read", "write")))
				.addSecurityItem(
						new SecurityRequirement().addList("x-dls-key", Arrays.asList("read", "write")));
	}


	private Info apiInfo() {
		return new Info().title("Data Lake Service").version("Build# ".concat(buildNo));
//				.description("<br>Data Lake Service (DLS) provides set of REST API which "
//				+ "allows to dump files in TCUP, along with set of user defined meta-data describing the file. "
//				+ "There will be API to search the files using these meta-data and finally download the files. "
//				+ "It is possible to mention relationship among files and state of current processing stage.")
//				.termsOfService("TCS Connected Universe Platform, Copyright © 2020 Tata Consultancy Services Limited. All rights reserved.");
	}
	
	private @Value("{endpoints.cors.allowed-headers}") String allowHeaders;
	private @Value("{endpoints.cors.allowed-methoStringds}") String allowMethods;
	private @Value("{endpoints.cors.allowed-origins}") String allowOrigins;
	private @Value("{endpoints.cors.exposed-headers}") String exposedHeaders;
	
	
	@Override
    public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
	        .allowedOrigins(allowOrigins)
	        .allowedMethods(allowMethods)
	        .allowedHeaders(allowHeaders)
	        .exposedHeaders(exposedHeaders);
    }
	
	
	@Bean
	public ResourceBundleMessageSource messageSource() {
		
		ResourceBundleMessageSource source = new ResourceBundleMessageSource();
		source.setBasenames("classpath:ValidationMessages"); 
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}


//	@Bean
//	GroupedOpenApi dlsApis() {
//		return GroupedOpenApi.builder().group("DLS Tasks").pathsToExclude("/**datapoint/**", "/**/admin/**").build();
//	}
//
//	@Bean
//	GroupedOpenApi fairApis() {
//		return GroupedOpenApi.builder().group("Data Point Tasks").pathsToMatch("/**/datapoint/**").build();
//	}
//
//	@Bean
//	GroupedOpenApi adminApis() {
//		return GroupedOpenApi.builder().group("TCUP Admin Tasks").pathsToMatch("/**/admin/**").build();
//	}



}
