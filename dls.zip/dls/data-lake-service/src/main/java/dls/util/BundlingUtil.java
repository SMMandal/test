package dls.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.kamranzafar.jtar.TarOutputStream;
import org.springframework.util.FileSystemUtils;

import java.io.*;
import java.nio.file.Files;
import java.util.Optional;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
@Slf4j
public class BundlingUtil {

	public File createBundle(String baseDir,String bundleName,String compressionType) throws IOException {
		switch (Optional.ofNullable(compressionType).orElse("ZIP")) {
		case "ZIP":
			log.info("Creating ZIP bundle");
			return createZip(baseDir,bundleName);
		case "TAR":
			log.info("Creating TAR bundle");
			return createTar(baseDir,bundleName);

		case "TAR-GZ":
			log.info("Creating TAR.GZ bundle");
			return createTarGZ(baseDir,bundleName);

		default:
			log.info("Compression Format not supported");
			break;
		}


		return null;

	}


	public void deleteTempDirectory(File tempPath) {
		log.info("deleting temp bundle path {}", tempPath.getAbsolutePath());
		try {
			FileSystemUtils.deleteRecursively(tempPath.toPath());
		} catch (IOException e) {
			log.error("Error deleting the temp bundle path {}, reason is {}", tempPath.getAbsolutePath(), e.getMessage());
		}
//		FileSystemUtils.deleteRecursively(tempPath);
//		return true;

	}


	private static File createZip(String baseDir,String bundleName) throws IOException {
		FileOutputStream fos = new FileOutputStream(baseDir+"/"+bundleName+".zip"); 
		ZipOutputStream zipOut = new ZipOutputStream(fos); 
		File fileToZip = new File(baseDir+"/"+bundleName);	
		zipFile(fileToZip, fileToZip.getName(), zipOut); zipOut.close(); fos.close();
		File zipFile=new File(baseDir+"/"+bundleName+".zip");
		log.info("Zipped Details: {}",zipFile.getAbsolutePath());
		log.info("Name: {}", zipFile.getName());
		if(zipFile.exists()) {
			log.info("{} Kb", zipFile.length()/1024);
			return zipFile;
		}else {
			return null;
		}
	}

	public static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {

		if (fileToZip.isHidden()) {
			return;
		}
		if (fileToZip.isDirectory()) {
			if (fileName.endsWith("/")) {
				zipOut.putNextEntry(new ZipEntry(fileName));
				zipOut.closeEntry();
			} else {
				zipOut.putNextEntry(new ZipEntry(fileName + "/"));
				zipOut.closeEntry();
			}
			File[] children = fileToZip.listFiles();
			for (File childFile : children) {
				zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
			}
			return;
		}
		FileInputStream fis = new FileInputStream(fileToZip);
		ZipEntry zipEntry = new ZipEntry(fileName);
		zipOut.putNextEntry(zipEntry);
		byte[] bytes = new byte[1024];
		int length;
		while ((length = fis.read(bytes)) >= 0) {
			zipOut.write(bytes, 0, length);
		}
		fis.close();
	}

	private File createTar(String baseDir, String bundleName) throws IOException {
		TarArchiveOutputStream tarOs = null;

		FileOutputStream fos = new FileOutputStream(baseDir+"/"+bundleName.concat(".tar"));
		TarOutputStream tos = new TarOutputStream(new BufferedOutputStream(fos));
		tarOs = new TarArchiveOutputStream(tos);
		addFilesToTar(baseDir+"/"+bundleName, "", tarOs);     		
		tarOs.close();
		File tarFile=new File(baseDir+"/"+bundleName+".tar");
		if(tarFile.exists())
			return tarFile;		
		return null;


	}

	public void addFilesToTar(String filePath, String parent, TarArchiveOutputStream tarArchive) throws IOException {
		File file = new File(filePath);
		// Create entry name relative to parent file path 
		String entryName = parent + file.getName();
		// add tar ArchiveEntry
		tarArchive.putArchiveEntry(new TarArchiveEntry(file, entryName));
		if(file.isFile()){
			FileInputStream fis = new FileInputStream(file);
			BufferedInputStream bis = new BufferedInputStream(fis);
			// Write file content to archive
			IOUtils.copy(bis, tarArchive);
			tarArchive.closeArchiveEntry();
			bis.close();
		}else if(file.isDirectory()){
			// no need to copy any content since it is
			// a directory, just close the outputstream
			tarArchive.closeArchiveEntry();
			// for files in the directories
			for(File f : file.listFiles()){        
				// recursively call the method for all the subdirectories
				addFilesToTar(f.getAbsolutePath(), entryName+File.separator, tarArchive);
			}
		}          
	}

	//***********************************************************************************************************//

	private File createTarGZ(String baseDir, String bundleName) throws IOException {
		TarArchiveOutputStream tarOs = null;

		FileOutputStream fos = new FileOutputStream(baseDir+"/"+bundleName.concat(".tar.gz"));
		GZIPOutputStream tos = new GZIPOutputStream(new BufferedOutputStream(fos));
		tarOs = new TarArchiveOutputStream(tos);
		addFilesToTar(baseDir+"/"+bundleName, "", tarOs);   
		tarOs.close();
		File tarFile=new File(baseDir+"/"+bundleName+".tar.gz");
		if(tarFile.exists())
			return tarFile;		
		return null;

	}

}
