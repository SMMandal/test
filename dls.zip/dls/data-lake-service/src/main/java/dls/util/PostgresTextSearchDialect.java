package dls.util;

import org.hibernate.boot.model.FunctionContributions;
import org.hibernate.dialect.PostgreSQLDialect;
import org.hibernate.type.BasicTypeRegistry;
import org.hibernate.type.StandardBasicTypes;

public class PostgresTextSearchDialect extends PostgreSQLDialect {


	public PostgresTextSearchDialect() {
//        registerFunction("fts", new PostgresTextSearchFunction());
//        registerFunction("arr_search", new PostgresArraySearchFunction());
//        registerFunction("ts_rank", new StandardSQLFunction("ts_rank", DoubleType.INSTANCE));
//        registerFunction("to_tsquery", new StandardSQLFunction("to_tsquery", ObjectType.INSTANCE));
//        registerFunction("string_agg", new SQLFunctionTemplate( StandardBasicTypes.STRING, "string_agg(?1, ?2)"));
	}

	@Override
	public void initializeFunctionRegistry(FunctionContributions functionContributions) {

		super.initializeFunctionRegistry(functionContributions);
		BasicTypeRegistry basicTypeRegistry = functionContributions.getTypeConfiguration().getBasicTypeRegistry();

		functionContributions.getFunctionRegistry().registerPattern(
				"arr_search",
				"?1 = ANY(shared_to)",
				basicTypeRegistry.resolve( StandardBasicTypes.BOOLEAN ));

		functionContributions.getFunctionRegistry().registerPattern(
				"ANY",
				"ANY(?1)",
				basicTypeRegistry.resolve( StandardBasicTypes.BOOLEAN ));


		functionContributions.getFunctionRegistry().registerPattern(
				"fts",
				"document @@ to_tsquery(?1)",
				basicTypeRegistry.resolve( StandardBasicTypes.BOOLEAN ));
	}
}
