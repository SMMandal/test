package dls.util;

import dls.bean.AuditEvent;
import dls.bean.Directory;
import dls.repo.AuditRepo;
import dls.repo.DirectoryRepo;
import dls.vo.AuditVO;
import dls.vo.DirectoryVO;
import dls.vo.FileVO;
import dls.vo.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

@Aspect
@Component
@Slf4j
@ConditionalOnProperty(value="dls.enable.audit", havingValue = "true", matchIfMissing = true)
public class AuditAspect {


    @Autowired private AuditRepo auditRepo;

//    @AfterReturning("execution(* dls.web.*.get*(..))")
//    public void accessEvent(JoinPoint joinPoint) {
//        log.error("Created: {} {}" , joinPoint.getSignature(), joinPoint.getArgs());
////        saveAudit("directory", vo.getId(), vo.getUser());
//    }
//
//
//
//    @AfterReturning("execution(* dls.repo.DirectoryRepo.save(..)) && args(vo)")
//    public void saveDirectory(JoinPoint joinPoint, DirectoryVO vo) {
//        log.error("Created: {} {}" , joinPoint.getSignature(), joinPoint.getArgs());
//        saveAudit("directory", vo.getId(), vo.getCreatedBy(), true);
//    }
//
    @AfterReturning("execution(* dls.repo.FileRepo.saveAndFlush(..)) && args(vo)")
    public void saveFile(JoinPoint joinPoint, FileVO vo) {
        AuditEvent ev = AuditEvent.CREATED;
        if(vo.getDeleted()) {
            ev = AuditEvent.DELETED;
        }

        log.info("Created: {} {}" , joinPoint.getSignature(), joinPoint.getArgs());
        saveAudit("file", vo.getId(), vo.getUser(), true, ev);
    }

//    @AfterReturning("execution(* dls.service.DirectoryService.createDirectory(..)) && args(apiKey, dlsKey,directories)")
//    public void saveDirectory(JoinPoint joinPoint, String apiKey, String dlsKey, List<Directory> directories) {
//        AuditEvent ev = AuditEvent.CREATED;
//        log.info("Created: {} {}" , joinPoint.getSignature(), joinPoint.getArgs());
//
//        saveAudit("directory", vo.getId(), vo.getCreatedBy(), true, ev);
//    }




//
//    @AfterReturning("execution(* dls.repo.LinkRepo.save(..)) && args(vo)")
//    public void saveFile(JoinPoint joinPoint, LinkVO vo) {
//        log.error("Created: {} {}" , joinPoint.getSignature(), joinPoint.getArgs());
//        saveAudit("link", vo.getId(), vo.getUser(), true);
//    }




    private void saveAudit(String entity, Long entityId, UserVO userVO, Boolean success, AuditEvent event) {
        auditRepo.save(AuditVO.builder()
                .event(event.name())
                .entity(entity)
                .entityId(entityId)
                .success(success)
                .eventTime(Timestamp.from(Instant.now()))
                .user(userVO)
                .build());
    }


}


