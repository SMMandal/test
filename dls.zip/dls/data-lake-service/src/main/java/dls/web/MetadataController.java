package dls.web;

import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.repo.DirectoryMetaRepo;
import dls.repo.FileMetaRepo;
import dls.service.MetadataService;
import dls.vo.FileMetaVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.Pattern;
import java.util.*;

import static dls.bean.CatalogQuery.URI_QUERY_REGEX;

@RestController
@RequestMapping("/metadata")
@Tag(description="Manage file, directory metadata", name="Metadata")
public class MetadataController {

    @Autowired private MetadataService metadataService;

    @Operation(summary = "Add, update or delete file and/or directory metadata", description = """
            The <code>metadata</code> list in the request JSON can be used to completely overwrite an existing set of
            metadata for one or more <code>files</code> or <code>directories</code>. <br>
            This would effectively add or update metadata. <br>
            If metadata list is sent empty, it would remove all existing metadata of the file/directory from DLS.<p>
            Unlike other API, all characters are allowed in metadata value in this API.
            For <code>"</code> and <code>\\\\</code> characters, an escape character <code>\\\\</code> has to be prepended.
            """)
    @PutMapping
    public ResponseEntity<Map<String, String>> insertBulkMetadata(
            @Parameter(hidden = true)
            @RequestHeader(value="x-api-key", required=false)  String apiKey,
            @Parameter(hidden = true)
            @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
            @Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
            @RequestBody List<MetadataService.MetadataPayload> payload) throws DlsSecurityException, DlsPrivacyException {

        return ResponseEntity.of(Optional.of( metadataService.insertBulkMetadata(apiKey, dlsKey, payload)));
    }
}


