package dls.web;

import com.google.common.collect.Maps;
import dls.bean.Tenant;
import dls.exception.*;
import dls.service.UserService;
import dls.vo.TenantVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.util.Map;

import static dls.util.BeanValidationConstraint.*;

@RestController
@Tag(description="Various administrative tasks for platform admins", name="Administration")
@Validated
class AdminController {

	@Autowired
    private UserService uservice;
	

	
	@Operation( summary="Get DLS admin key of the tenant")
	@GetMapping(value="/admin/user")
	public ResponseEntity <String> getDlsAdminKey(
			@Parameter(description="Admin Key",hidden = true)
	@RequestHeader(value="x-api-key", required=false) String apiKey,
	@RequestParam(value="tenant_api_key") String tenantAPIKey) throws DlsPrivacyException, DlsSecurityException, DlsNotFoundException {
		
		if(!uservice.authenticate(apiKey).getAdmin()) {
			throw new DlsPrivacyException();
		}
		return ResponseEntity.status(HttpStatus.OK).body(uservice.getDlsAdminKey(tenantAPIKey)) ;
	}

	@Operation( summary="Geet maximum storage limit for this tenant")
	@GetMapping(value="/admin/storage")
	public ResponseEntity <Map<String,Long>> getStorage(
			@Parameter(description="Admin Key",hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="Enter the tcup tenant name")
			@RequestParam(value="tenant") String tenant) throws DlsPrivacyException, DlsSecurityException, DlsNotFoundException {

		if(!uservice.authenticate(apiKey).getAdmin()) {
			throw new DlsPrivacyException();
		}
		return ResponseEntity.status(HttpStatus.OK).body(uservice.getStorage(tenant)) ;
	}

	@Operation( summary="Set maximum storage limit for this tenant")
	@PutMapping(value="/admin/storage")
	public ResponseEntity <String> setStorage(
			@Parameter(description="Admin Key",hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="Enter the tcup tenant name")
			@RequestParam(value="tenant") String tenant,
			@RequestParam(value="storage-limit") Long storageLimit) throws DlsPrivacyException, DlsSecurityException, DlsNotFoundException {

		if(!uservice.authenticate(apiKey).getAdmin()) {
			throw new DlsPrivacyException();
		}
		return ResponseEntity.status(HttpStatus.RESET_CONTENT).body(uservice.setStorage(tenant, storageLimit)) ;
	}



	@Operation( summary="Register new tenant")
	@PostMapping(value="/admin/user")
	
	public ResponseEntity<String> createNewTenant(
			@Parameter(description="Admin Key",hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@RequestBody @Valid  Tenant tenant,
			BindingResult err) throws DlsValidationException, DlsSecurityException, DlsPrivacyException {
		
		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}
		if(null == tenant.getTcupUser() && null == tenant.getDlsAdminUser()) {
			throw new DlsValidationException("user.blank.tcupuser.dlsadmin");
		}
		if(null == tenant.getTcupUser()) {
			tenant.setTcupUser(tenant.getDlsAdminUser());
		}

		if(!uservice.authenticate(apiKey).getAdmin()) {
			throw new DlsPrivacyException();
		}
		
		return ResponseEntity.status(HttpStatus.CREATED).body(uservice.provision(tenant)) ;
	}

	@Operation( summary="Register new tenant")
	@PutMapping(value="/admin/user/organization")

	public ResponseEntity<String> updateOrganization(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@RequestParam String tenant,
			@Length(min = ORGANIZATION_LEN_MIN, max = ORGANIZATION_LEN_MAX, message = "{invalid.organization.length}")
			@Pattern(regexp = ORGANIZATION_REGEX, message = "{invalid.organization}")
			@RequestParam(required = false) String organization) throws DlsValidationException, DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		TenantVO tenantVO = uservice.authenticate(apiKey);
		if(!tenantVO.getAdmin()) {
			throw new DlsPrivacyException();
		}
		uservice.updateOrganization(tenant, organization);
		return ResponseEntity.status(HttpStatus.RESET_CONTENT).body(GlobalExceptionHandler.UPDATED) ;
	}
	

	
	
	@Operation( summary="Delete tenant")
	@DeleteMapping(value="/admin/user/{username}")
	
	public ResponseEntity<String> deleteTenant(
			@Parameter(description="Admin Key",hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@PathVariable() String username) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		uservice.deleteTenant(apiKey, username);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(GlobalExceptionHandler.DELETED) ;
	}

	@Operation( summary="Get DLS storage detail", hidden = false)
	@GetMapping(value="/admin/storage/type")

	public ResponseEntity<Map<String,Object>> getStorageType(
			@Parameter(description="Admin Key",hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey) throws DlsSecurityException, DlsPrivacyException {

		if(!uservice.authenticate(apiKey).getAdmin()) {
			throw new DlsPrivacyException();
		}
		Map <String, Object> map = Maps.newHashMap();
		map.put("type", hdfsEnabled ? "HDFS" : "NFS");
		map.put("value", hdfsEnabled ? hdfsPath : nfsPath);
		return ResponseEntity.status(HttpStatus.OK).body(map) ;
	}

	@Value("${dls.enable.hdfs}") private boolean hdfsEnabled;
	@Value("${local.fs.failsafe.path}") private String nfsPath;
	@Value("${spring.hadoop.fsUri}") private String hdfsPath;
}
