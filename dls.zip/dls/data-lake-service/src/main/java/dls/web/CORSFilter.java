package dls.web;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class CORSFilter implements Filter {

	@Value("${endpoints.cors.exposed-headers}") private String exposedHeaders;
	@Value("${endpoints.cors.allowed-origins}") private String allowOrigin;
	@Value("${endpoints.cors.allowed-methods}") private String allowMethods;
	@Value("${endpoints.cors.allowed-headers}") private String allowHeader;

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) res;
        response.setHeader("Access-Control-Allow-Origin", allowOrigin);
        response.setHeader("Access-Control-Allow-Methods", allowMethods);
        response.setHeader("Access-Control-Allow-Headers", allowHeader);
        response.setHeader("Access-Control-Expose-Headers", exposedHeaders);
        chain.doFilter(req, res);
    }


}