package dls.web;

import dls.bean.DlsResponse;
import dls.bean.Link;
import dls.exception.*;
import dls.service.FileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

import static dls.bean.CatalogQuery.URI_QUERY_REGEX;

@RestController
@Tag(description="Relate files to each other", name="Link")
@Validated
public class LinkController {

	public static final String RELATION_NAME_PATTERN = "([a-zA-Z_]){2,50}";
	@Autowired private FileService dservice;
	
	@Operation( summary = "Relate two files",
			description = "Provide a relation name and file path. File path consists of savepoint/file.ext"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	
	@PostMapping("/link/{relation:.+}")
	public ResponseEntity <String> relate(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(value="lhs-file-uri") @Pattern(regexp=".*", message="{link.invalid.filepath}") String lhsFile,
			@PathVariable() @Pattern(regexp= RELATION_NAME_PATTERN, message="{link.invalid.relation}") String relation,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(value="rhs-file-uri") @Pattern(regexp=".*", message="{link.invalid.filepath}") String rhsFile) throws DlsSecurityException, DlsNotFoundException, DlsValidationException, DlsPrivacyException {

		dservice.relate(apiKey, dlsKey, lhsFile, relation, rhsFile);
		return ResponseEntity.status(HttpStatus.CREATED).body(GlobalExceptionHandler.LINKED);
	}

	@Operation( summary = "Relate multiple files",
			description = "Create relations between multiple files in a single API call"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)

	@PostMapping("/links")
	public ResponseEntity <List<DlsResponse>> relateMultiple(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestBody @Size(min = 1, message = "{no.record.in.array}")  List< @Valid Link> links) throws DlsSecurityException, DlsValidationException, DlsPrivacyException {

		return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(dservice.relateMultiple(apiKey, dlsKey, links));
	}

	@Operation( summary="")
	@GetMapping("/link")
	public ResponseEntity<String> getLinks(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(value="lhs-file-uri", required=false) @Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}") String lhsFile,
			@RequestParam(required=false) /*@Pattern(regexp= RELATION_NAME_PATTERN, message="{link.invalid.relation}") */String relation,
			@RequestParam(value="rhs-file-uri", required=false) @Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}") String rhsFile) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {
		
		return ResponseEntity.ok(dservice.findLinks(apiKey, dlsKey, lhsFile, relation, rhsFile));
		
	}
	
	@Operation( summary="")
	@DeleteMapping("/link")
	public ResponseEntity<String> deleteLinks(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(value="lhs-file-uri") @Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}") String lhsFile,
			@RequestParam() @Pattern(regexp= RELATION_NAME_PATTERN, message="{link.invalid.relation}") String relation,
			@RequestParam(value="rhs-file-uri") @Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}") String rhsFile) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {

		dservice.deleteLinks(apiKey, dlsKey, lhsFile, relation, rhsFile);
		return ResponseEntity.ok(GlobalExceptionHandler.DELETED);
		
	}
	
	
	
}
