package dls.web;

import dls.bean.ComplianceEnum;
import dls.bean.DlsResponse;
import dls.bean.MetaSchema;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.service.MetaDataSchemaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.util.List;
import java.util.Map;

import static dls.exception.GlobalExceptionHandler.CREATED;
import static dls.util.BeanValidationConstraint.URL_REGEX;


@RestController
@Tag(description="Create,update and delete metadata", name="Schema")
@Validated
class MetaSchemaController {

	@Autowired private MetaDataSchemaService mservice;

	@Operation(
			summary="Define a schema for all other metadata of files and directories",
			description = "If metadata schema is created, all other API which deals with metadata must conform to this set of metadata."
			/*produces=MediaType.TEXT_PLAIN_VALUE,*/ /*consumes = MediaType.APPLICATION_JSON_VALUE*/)
	@PostMapping("/schema")
	public ResponseEntity <List<DlsResponse>>createSchema(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestBody @Valid  MetaSchema schema, BindingResult err) throws DlsSecurityException, DlsPrivacyException {

		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}
		return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(mservice.createMetaDataSchema(schema, apiKey, dlsKey));

	}

	

	@Operation( summary = "Deletes a meta-data from schema",
	description = "A specific metadata is removed from enforcement, if it is already not in use"/*, produces=MediaType.TEXT_PLAIN_VALUE*/)

	@DeleteMapping("/schema/metadata/{name}") public ResponseEntity<String> deleteSchema(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@PathVariable(required = false ,name ="name") String name)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		mservice.deleteMetaData( apiKey, dlsKey, name);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("DELETED");

	}

	@Operation( summary = "Completely removes metadata schema, hence disable schema enforcement",
			description = "All metadata in schema are removed irrespective of whether they are in use"/*, produces=MediaType.TEXT_PLAIN_VALUE*/)

	@DeleteMapping("/schema") public ResponseEntity<String> deleteSchema(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey)
			throws DlsSecurityException, DlsPrivacyException {

		mservice.deleteSchema(apiKey, dlsKey);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("DELETED");

	}
	

	@Operation(summary="Get meta-data details",
	description = "Optionally provide the filter fields to fetch all the matching meta-data details"/*,
	produces=MediaType.TEXT_PLAIN_VALUE*/)

	@GetMapping("/schema") public ResponseEntity<MetaSchema> getSchema(

			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@RequestParam(required = false ,name ="names") String name,
			@RequestParam(required = false ,name ="type") MetaSchema.MetadataType type)
			throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		return ResponseEntity.status(HttpStatus.OK)
				.body(mservice.listMetaDataSchema(apiKey,dlsKey, name, type));

	}


	
	/*@Operation(
			summary="Create meta-data  details",
			description = "Creates meta-data details based on the provided list of metadata details",
			produces=MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/schema/relation")
	public ResponseEntity <String>createRelation(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@RequestBody List<Relation> relationList) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {

		mservice.createRelation(relationList, apiKey, dlsKey);

		return ResponseEntity.status(HttpStatus.CREATED).body(null);

	}*/


	@Operation(
			summary="Register ontology prefixes and vocabulary IRI",
			description = "To use custom vocabulary in FAIR, definition of prefixes need to be registered here")
	@PostMapping("/schema/ontology")
	public ResponseEntity <String> createDefinition(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Pattern(regexp = "\\w*", message = "Prefix can only contain word characters")
			@Length(max = 10, message = "Prefix can not be more than 10 characters")
			@RequestParam String prefix,
			@Pattern(regexp = "\\w*(://).*", message = "Link should be in IRI format")
			@Length(max = 255, message = "Maximum 255 characters are allowed")
			@RequestParam String vocabularyLink) throws DlsSecurityException, DlsPrivacyException {

		mservice.registerOntology(apiKey, dlsKey, prefix, vocabularyLink);
		return ResponseEntity.status(HttpStatus.CREATED).body(CREATED);

	}

	@Operation(
			summary="Fetch ontology prefixes and vocabulary IRI",
			description = "To use custom vocabulary in FAIR, definition of prefixes need to be pre-registered")
	@GetMapping("/schema/ontology")
	public ResponseEntity <Map<String, String>> getDefinition(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		return ResponseEntity.status(HttpStatus.OK).body(mservice.getOntology(apiKey, dlsKey));

	}

	@Operation(
			summary="Delete ontology prefixes and vocabulary IRI",
			description = "To use custom vocabulary in FAIR, definition of prefixes need to be pre-registered")
	@DeleteMapping("/schema/ontology/{prefix}")
	public ResponseEntity <String> deleteDefinition(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@PathVariable("prefix") String prefix) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		mservice.deleteOntology(apiKey, dlsKey, prefix);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("");

	}
}
