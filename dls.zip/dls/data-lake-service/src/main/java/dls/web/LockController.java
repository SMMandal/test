package dls.web;

import dls.exception.*;
import dls.service.FileLockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Tag(description="Lock or unlock a file or directory", name="Lock")
@Validated
public class LockController {

	@Autowired private FileLockService fileLockService;
	
	@Operation( summary = "Lock file",
			description = "Lock a file in DLS from other users to modify")
	
	@PostMapping(value = "/lock", consumes = "plain/text")
	public ResponseEntity <String> lock(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(description="URI of the file to be locked", schema = @Schema(type = "string"))
			@RequestParam(value="file-uri") String file,
			@Parameter(description="Whether file is to be hidden", schema = @Schema(type = "boolean"))
			@RequestParam(value="hide", required = false) boolean hide,
			@Parameter(description="Reason for locking this file", schema = @Schema(type = "string"))
			@Length(max = 255, message = "{max.comment.length}")
			@RequestBody(required = false) String reason) throws DlsSecurityException, DlsNotFoundException, DlsValidationException, DlsPrivacyException {

		fileLockService.lock(apiKey, dlsKey, file, hide, reason);
		return ResponseEntity.status(HttpStatus.CREATED).body(GlobalExceptionHandler.LOCKED);
	}

	@Operation( summary = "Hide/show a locked file",
			description = "Once a file is locked, hide or show it to other users")
	@PutMapping(value = "/lock")
	public ResponseEntity <String> hide(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(description="URI of the file to be locked", schema = @Schema(type = "string"))
			@RequestParam(value="file-uri") String file,
			@Parameter(description="Whether file is to be hidden", schema = @Schema(type = "boolean"))
			@RequestParam(value="hide", required = true) boolean hide) throws DlsSecurityException, DlsNotFoundException, DlsValidationException, DlsPrivacyException {

		fileLockService.updateLock(apiKey, dlsKey, file, hide);
		return ResponseEntity.status(HttpStatus.RESET_CONTENT).build();
	}


	@Operation( summary = "Unlock file",
			description = "Unlock a file which was already locked earlier by you. Note : admin can unlock any locked file.")

	@DeleteMapping("/lock")
	public ResponseEntity <String> unlock(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(value="file-uri") String file) throws DlsSecurityException, DlsNotFoundException, DlsValidationException, DlsPrivacyException {

		fileLockService.unlock(apiKey, dlsKey, file);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(GlobalExceptionHandler.UNLOCKED);
	}

	@Operation( summary = "Get lock/unlock status of the file",
			description = "Find the lock or unlock status of the file by users")

	@GetMapping("/lock")
	public ResponseEntity <Map<String, String>> getLockStatus(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(value="file-uri") String file) throws DlsSecurityException, DlsNotFoundException, DlsValidationException, DlsPrivacyException {


		return ResponseEntity.status(HttpStatus.OK)
				.body(fileLockService.getLockStatus(apiKey, dlsKey, file));
	}

}
