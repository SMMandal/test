package dls.web;

import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.GlobalExceptionHandler;
import dls.service.FileShareService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.Pattern;
import java.util.List;
import java.util.Map;

import static dls.bean.CatalogQuery.URI_QUERY_REGEX;

@RestController
@Validated
@Tag(description="Share files with other DLS users", name="Share")
class ShareController {


	@Autowired
	private FileShareService fsservice;

	@Operation( summary = "Share files with other DLS users", /*produces=MediaType.TEXT_PLAIN_VALUE, response=String.class,*/
			description = "Files owned by you can be shared to other DLS users who can download the file. "
					+ "If a file has been shared to you, it can not be shared to other DLS users."
					+ "Files containing linked files are also safe to share as linked files can not be "
					+ "downloaded by the DLS users you have shared the files with." )
	
	@ApiResponses(value = {
	        @ApiResponse(responseCode = "201", description = "File is shared successfully"),
	        @ApiResponse(responseCode = "401", description = "Invalid API key"),
	        @ApiResponse(responseCode = "403", description = "Invalid DLS key"),
	        @ApiResponse(responseCode = "404", description = "Invalid file URI or you are not file owner"),
	        @ApiResponse(responseCode = "409", description = "DLS username is not available"),
	 })
	
	@PostMapping("/share/{dls-user}")
	public ResponseEntity<String> createShare(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@PathVariable("dls-user") String dlsUser,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam("file-uri") String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {
		
		fsservice.createShare(apiKey, dlsKey, dlsUser, fileURI);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(GlobalExceptionHandler.SHARED);
	}
	
	@Operation( summary="Get all the shared files")
	@GetMapping("/share")
	public ResponseEntity <Map<String, List<String>>> getAllShare(@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(value="dls-user", required=false) String dlsUser,
			@RequestParam(value="show-time", required = false, defaultValue="false") Boolean showTime) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {
		
		Map<String, List<String>> shares = fsservice.getShare(apiKey, dlsKey, dlsUser, showTime);
		
		return ResponseEntity.status(HttpStatus.OK).body(shares);
	}
	
	@Operation( summary="Remove a file share")
	@ApiResponses(value = {
	        @ApiResponse(responseCode = "200", description = "File share is deleted successfully"),
	        @ApiResponse(responseCode = "204", description = "Deprecated status code"),
	        @ApiResponse(responseCode = "401", description = "Invalid API key"),
	        @ApiResponse(responseCode = "403", description = "Invalid DLS key"),
	        @ApiResponse(responseCode = "404", description = "No file share is available to delete"),
	        @ApiResponse(responseCode = "409", description = "DLS username is not available"),
	 })
		
	@DeleteMapping("/share/{dls-user}")
	public ResponseEntity<String> deleteShare(@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@PathVariable("dls-user") String dlsUser,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri") String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {
		
		fsservice.deleteShare(apiKey, dlsKey, dlsUser, fileURI);
		return ResponseEntity.status(HttpStatus.OK).contentType(MediaType.TEXT_PLAIN).body(GlobalExceptionHandler.DELETED);
	}
	
	
	
	
}
