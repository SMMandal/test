package dls.web;

import dls.bean.Directory;
import dls.bean.DlsResponse;
import dls.bean.MetadataRule;
import dls.bean.Permission;
import dls.exception.*;
import dls.service.DirectoryService;
import dls.service.DlsServiceHelper;
import dls.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.UniqueElements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

import static dls.bean.CatalogQuery.META_QUERY_REGEX;
import static dls.util.BeanValidationConstraint.ENFORCEMENT_REGEX;


@RestController
@Tag(description="Create , Update and delete Directory ,their directory-meta rules and assign permission to directory", name="Directory")
@Slf4j
@Validated
class DirectoryController {

	@Autowired private DirectoryService directoryService;
	@Autowired private DlsServiceHelper hservice;
	@Autowired private UserService uservice;
	@Autowired private DlsServiceHelper dlsServiceHelper;


	@Operation(
			summary="Creates directory and assign permissions to the directory for users or group",
			description = "Creates directory and assign permissions to the directory for users or group"/*,
			produces=MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE*/)
	@PostMapping("/directory")
	public ResponseEntity <List<DlsResponse>> createNewDirectory(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestBody
			@UniqueElements(message = "{duplicate.records}")
			@Size(min = 1, message = "{no.record.in.array}")  List<@Valid Directory> directory,
			BindingResult err) throws DlsSecurityException, DlsPrivacyException {

		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}

		return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(directoryService.createDirectory(apiKey, dlsKey, directory));

	}
	
	@Operation(
			summary="Assign permissions to the directory for users",
			description = "Assign permissions to users for the directory. Following table describes how permission can be set :" +
					"<table><thead><tr><th></th><th><code>R</code></th><th><code>W</code></th><th><code>D</code></th></tr></thead>" +
					"<tbody><tr><td><code>action</code></td><td>Download files from this directory.</td><td>Upload file(s) to this directory.</td><td>Delete file(s) of this directory.</td></tr>" +
					"<tr><td><code>directory-action</code></td><td>Read content of sub-directories.</td><td>Create sub-directories, permission, rules.</td><td>Delete sub-directories</td></tr>" +
					"</tbody></table>" )
	@PutMapping("/directory/permission")
	public ResponseEntity <List<DlsResponse>>updatePermission(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam String directory,
			@RequestBody @Size(min = 1, message = "{no.record.in.array}")
			@UniqueElements(message = "{duplicate.records}")
					List<@Valid Permission> permissions
//			,
//			BindingResult err
	) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

//		if(err.hasErrors()) {
//			throw new DlsValidationException(err.getAllErrors());
//		}
		return ResponseEntity.status(HttpStatus.MULTI_STATUS)
				.body(directoryService.updatePermission(apiKey, dlsKey, directory, permissions));

	}
	

	
	
	@Operation(
			summary="Get the details of directory along with permission",
			description = "Use a specific directory name to get the detail. " +
					"This will return result if the user has read <code>[R]</cod> permission on the directory." +
					"Admin can search without providing any specific directory name."/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	@GetMapping("/directory")

	public ResponseEntity<List<Directory>> getDirectory(

			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)
			String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)
			String dlsKey,

			@RequestParam(required = false) String directory,
//			@Pattern(regexp= META_QUERY_REGEX, message="{query.invalid.metadata}")
			@RequestParam(required = false) String metadata)  throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {


//		if(null != metadata && !metadata.matches("^((\\w+=('[\\s\\w.*:\\-\\+\\/]+'))|(\\w+)|('[\\s\\w.*:\\-\\+\\/]+'))$")) {
		if(null != metadata && !metadata.matches(META_QUERY_REGEX)) {
			throw new DlsValidationException("query.invalid.metadata");
		}
		return ResponseEntity.status(HttpStatus.OK).body(directoryService.getDirectory(apiKey, dlsKey, directory, metadata));

	}
	
	@Operation(
			summary ="Deletes permissions attached with a directory",
	  		description = "Deletes permissions attached with a directory"/*,
	  	produces=MediaType.TEXT_PLAIN_VALUE*/)
	  
	  @DeleteMapping("/directory/permission") public ResponseEntity<String> deleteDirectoryPermission(
	  
	  @Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)
	   String apiKey,
	  @Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)
	   String dlsKey,
	  
	  @RequestParam(required = false, name ="directory") String directory,
	  @RequestParam(required = false, name ="user") String permittedUser)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException
	  {
	  	if(null == directory && null == permittedUser) {
	  		throw new DlsValidationException("delete.permission.invalid.input");
		}
		  directoryService.deleteDirectoryPermission(apiKey, dlsKey, directory, permittedUser);
	  	return ResponseEntity.status(HttpStatus.NO_CONTENT)
				.body("DELETED");
	  }
	
	
	@Operation(
			summary="Deletes Directory or all leaf directories including the directory provided",
	  		description = "Deletes Directory or all leaf directories including the directory provided"/*,
	  		produces=MediaType.TEXT_PLAIN_VALUE*/)
	  
	  @DeleteMapping("/directory") public ResponseEntity<String> deleteDirectory(
	  @Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)
	   String apiKey,
	  @Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)
	   String dlsKey,
	  @RequestParam String directory)
			throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException  {

	  	return ResponseEntity.status(HttpStatus.NO_CONTENT)
			  .body(directoryService.deleteDirectory(apiKey, dlsKey, directory ));
	  
	  }
	
	@Operation(
			summary="Creates directory meta-rules",
			description = "A list of meta-rules are created for the selected directory"/*,
			produces=MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE*/)
	@PutMapping("/directory/rule")
	public ResponseEntity <List<DlsResponse>>updateDirectoryMetaRule(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(name="directory") String directory,
			@RequestBody(required = false) @Size(min = 1, message = "{no.record.in.array}")
			@UniqueElements(message = "{duplicate.records}")
					List<@Valid MetadataRule> rule,
			@Parameter(schema = @Schema(type = "string", allowableValues = {"STRICT", "STANDARD"}))
			@RequestParam(name="enforcement", required = false, defaultValue="STRICT")
			@Pattern(regexp = ENFORCEMENT_REGEX, message = "{invalid.enforcement}") String enforcement,
			BindingResult err) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}

		if(null == enforcement && null == rule) {
			throw new DlsValidationException("update.rule.invalid.input");
		}
		return ResponseEntity.status(HttpStatus.MULTI_STATUS)
				.body(directoryService.updateDirectoryRule(apiKey, dlsKey, directory, rule, enforcement));

	}

	
	@Operation(
			summary="Deletes directory meta-rules",
			description = "Deletes meta-rules for the provided directory, Optionally meta-rule can also be provided"/*,
			produces=MediaType.TEXT_PLAIN_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE*/)

	@DeleteMapping("/directory/rule")
	public ResponseEntity<String> deleteDirectoryMetaRule(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@RequestParam(name ="directory") String directory,
			@RequestParam(required = false ,name ="metadata-name") String name
			/*,BindingResult err*/)
			throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

//		if(err.hasErrors()) {
//			throw new DlsValidationException(err.getAllErrors());
//		}
		directoryService.deleteDirectoryRule(apiKey, dlsKey, directory, name);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("DELETED");

	}




	@Operation(
			summary="Attach custom metadata with directory",
			description = "Add new metadata or update value of existing metadata value")
	@PutMapping("/directory/metadata")
	public ResponseEntity <String>updateDirectoryMetadata(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(name="directory") String directory,
			@RequestBody String [] metadata) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		directoryService.updateDirectoryMetadata(apiKey, dlsKey, directory, metadata);
		return ResponseEntity.status(HttpStatus.RESET_CONTENT)
				.body(GlobalExceptionHandler.UPDATED);

	}


	@Operation(
			summary="Delete a directory metadata")
	@DeleteMapping("/directory/metadata")
	public ResponseEntity <String>deleteDirectoryMetadata(
			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(name="directory") String directory,
			@RequestParam String name) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		directoryService.deleteDirectoryMetadata(apiKey, dlsKey, directory, name);
		return ResponseEntity.status(HttpStatus.NO_CONTENT)
				.body(GlobalExceptionHandler.DELETED);

	}






}
