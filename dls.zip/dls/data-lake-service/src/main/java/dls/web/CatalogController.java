package dls.web;

import com.fasterxml.jackson.core.JsonProcessingException;
import dls.bean.*;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.service.CatalogService;
import dls.service.FileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import java.util.List;

import static dls.service.CatalogExplorerViewService.CATALOG_TYPE_FILE;
import static io.swagger.v3.oas.annotations.enums.ParameterIn.QUERY;

@RestController
@Tag(description="Search files, browse through file catalogs", name="Catalog")
class CatalogController {

	@Autowired private CatalogService cservice;

	@Autowired private FileService dservice;
	
	@Operation(summary = "Search files and meta-data", description = "Enter any text to search files and meta-data"/*, produces=MediaType.APPLICATION_JSON_VALUE*/)
	
	
	@Parameters({

		@Parameter(name="metadata", description="Use following patterns to construct metadata query: <ul><li>Search for metadata key as <code>K</code></li><li>Search for metadata value as <code>'V'</code></li><li>Search specific metadata as <code>K='V'</code></li><li>Search multiple metadata keys matching any of them as <code>K1, K2</code></li><li>Search multiple metadata values matching any of them as <code>'V1', 'V2'</code></li><li>Search multiple specific metadata matching any of them as <code>K1='V1', K2='V2'</code></li><li>Search multiple metadata keys matching all of them as <code>K1 & K2</code></li><li>Search multiple metadata values matching all of them as <code>'V1' & 'V2'</code></li><li>Search multiple specific metadata matching all of them as <code>K1='V1' & K2='V2'</code></li><li>Search with complex combination <code>K1='V1' & 'V2', K3 </code></li><li>Note <code>cond1 & cond2 , cond3</code> is evaluated as <code>(cond1 AND cond2) OR cond3</code></li><li>Use wildcard for metadata key or value using <code>K*, '*V'</code></li><li>Use logical operators on numeric and timestamp value as <code>K>'100'</code></li><li>Following logical operators are allowed <code>></code>, <code><</code>, <code>>=</code>, <code><=</code>, <code>=</code>, <code>!=</code></li></ul>", in = QUERY, schema=@Schema(type = "string")),

		@Parameter(name="text", description="free text search", in = QUERY, schema=@Schema(type = "string")),
    
		@Parameter(name="time", description="02-May-2018 00:48:02 +00:00", in = QUERY, schema=@Schema(type = "string")),
    
		@Parameter(name="size", description=">1KB", in = QUERY, schema=@Schema(type = "string")),
	
		@Parameter(name="external", in = QUERY,  schema=@Schema(type = "boolean")),
		
		@Parameter(name="transferred", in = QUERY, schema=@Schema(type = "boolean")),
		
		@Parameter(name="deleted", in = QUERY, schema=@Schema(type = "boolean")),

		@Parameter(name="bundled", in = QUERY, schema=@Schema(type = "boolean")),
		
		@Parameter(name="ownFile", in = QUERY, schema=@Schema(type = "boolean")),

		@Parameter(name="locked",  in = QUERY, schema=@Schema(type = "boolean")),

		@Parameter(name="uri", in = QUERY, schema=@Schema(type = "string")),
		
		@Parameter(name="filename", in = QUERY, schema=@Schema(type = "string")),
		
		@Parameter(name="savepoint",  in = QUERY, schema=@Schema(type = "string")),

		@Parameter(name="directory",  in = QUERY, schema=@Schema(type = "string")),

		@Parameter(name="sort", in = QUERY,
				schema = @Schema(type = "string", allowableValues = {"createdOn", "fileName", "size"})),
		
		@Parameter(name="pageNo", in = QUERY, schema=@Schema(type = "integer")),

		@Parameter(name="pageSize", in = QUERY, schema=@Schema(type = "integer"))
	})
	@GetMapping("/catalog")
	public ResponseEntity <Catalog> discover(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(hidden = true) @Valid CatalogQuery query, final BindingResult bindingResult
			) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {
		

		if(bindingResult.hasErrors()) {
			throw new DlsValidationException(bindingResult.getAllErrors());
		}
		return ResponseEntity.ok().body(cservice.getCatalog(apiKey, dlsKey, query, false, Integer.MAX_VALUE));
		
	}

	@Operation(deprecated = true,
			summary="Get Directory-wise Catalog", description = "Optionally enter a directory"/*,
			produces=MediaType.APPLICATION_JSON_VALUE*/)

	@Parameters({

			@Parameter(name="metadata", description="Use following patterns to construct metadata query: <ul><li>Search for metadata key as <code>K</code></li><li>Search for metadata value as <code>'V'</code></li><li>Search specific metadata as <code>K='V'</code></li><li>Search multiple metadata keys matching any of them as <code>K1, K2</code></li><li>Search multiple metadata values matching any of them as <code>'V1', 'V2'</code></li><li>Search multiple specific metadata matching any of them as <code>K1='V1', K2='V2'</code></li><li>Search multiple metadata keys matching all of them as <code>K1 & K2</code></li><li>Search multiple metadata values matching all of them as <code>'V1' & 'V2'</code></li><li>Search multiple specific metadata matching all of them as <code>K1='V1' & K2='V2'</code></li><li>Search with complex combination <code>K1='V1' & 'V2', K3 </code></li><li>Note <code>cond1 & cond2 , cond3</code> is evaluated as <code>(cond1 AND cond2) OR cond3</code></li><li>Use wildcard for metadata key or value using <code>K*, '*V'</code></li><li>Use logical operators on numeric and timestamp value as <code>K>'100'</code></li><li>Following logical operators are allowed <code>></code>, <code><</code>, <code>>=</code>, <code><=</code>, <code>=</code>, <code>!=</code></li></ul>", in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="text", description="free text search", in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="time", description="02-May-2018 00:48:02 +00:00", in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="size", description="<code>>1KB</code>", in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="external", in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="transferred", in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="deleted", in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="bundled", in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="ownFile", in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="locked",  in = QUERY, schema=@Schema(type = "boolean")),

			@Parameter(name="uri", /*description="File URI",*/ in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="filename", /*description="File name",*/ in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="savepoint", /*description="Savepoint",*/ in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="directory", /*description="Directory", */in = QUERY, schema=@Schema(type = "string")),

			@Parameter(name="fetchSize", description="Fetch size must be more than number of nodes in directory tree. Default is 100. " +
					"Warning! Increasing fetch size will increase response delay.", in = QUERY, schema=@Schema(type = "integer"))

			/*@Parameter(name="sort", value="Sort by",
					allowableValues="createdOn,fileName,size"),

			@Parameter(name="pageNo")*/


	})
	@GetMapping("/catalog/directory")
	public ResponseEntity <DirectoryCatalog> getDirectoryCatalog(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(hidden = true) @Valid CatalogQuery query,
			@RequestParam(required = false) Integer fetchSize,
			final BindingResult bindingResult) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException, JsonProcessingException {

		if(bindingResult.hasErrors()) {
			throw new DlsValidationException(bindingResult.getAllErrors());
		}
		if(fetchSize == null) fetchSize = 100;
		return ResponseEntity.ok().body(cservice.getDirectoryCatalog(apiKey, dlsKey, query, fetchSize));

	}


	@GetMapping("/catalog/file-count")
	public ResponseEntity <DirectoryCatalog> getDirectoryTreeCatalog(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(description = "Mention the directory name to fetch it's sub-directories only. The tree starts from this directory.")
			@RequestParam(required = false, value = "directory") String startDirectory,
			@Parameter(description = "Fetch only immediate subdirectory")
			@RequestParam(required = false) Boolean immediateOnly) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException, JsonProcessingException {


		return  ResponseEntity.ok().body( cservice.getDirectoryCatalogCount(apiKey, dlsKey, startDirectory, immediateOnly) );

	}

	@Operation( summary = "Get all relation names",
			description = "Get all relation names available in DLS, across all tenants"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	
	@GetMapping("/relation")
	public ResponseEntity <String> getAllRelationNames(@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {
		
		return ResponseEntity.ok(dservice.getAllRelationNames(apiKey, dlsKey));
	}
	
	
	@Operation( summary = "Get statistics about the DLS user account",
			description = "Get total file count, total volume of data etc"/*,
			produces=MediaType.APPLICATION_JSON_VALUE*/)
	@GetMapping("/statistics")
	public ResponseEntity <CatalogStatistics> getStats(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(name="cumulative", schema = @Schema(type = "boolean"), description = "For admin to see cumulative statistics for all users")
			@RequestParam(required = false) boolean cumulative) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {
		

		return ResponseEntity.ok().body(cservice.getCatalogStatistics(apiKey, dlsKey, cumulative));
		
	}
	
	@Operation( summary = "Get all metadata key names",
			description = "All metadata key names used during file upload till now"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	@GetMapping("/keylist")
	public ResponseEntity <List <String>> getMetadataKeys(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(required = false) Boolean withValue,
			@RequestParam(required = false) boolean includeDirectory,
			@RequestParam(required = false) String name,
			@RequestParam(required = false) String value
			) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {
		


		return ResponseEntity.ok().body(cservice.getMetadataKeys(apiKey, dlsKey, withValue,
				includeDirectory ? ' ' : CATALOG_TYPE_FILE, name, value));
		
	}
	
	@Operation(
			summary="Get file URI as a list",
			description = "This API returns a list of file URI which are not deleted and transferred successfully"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	@GetMapping("/filelist")
	public ResponseEntity <List<String>> getFileList(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {
		

		return ResponseEntity.ok().body(cservice.getFileList(apiKey, dlsKey));	
		
	}


	@Operation(
			summary="Get the details various operation performed on a file",
			description = "Returns the chronological list of operations performed on a file"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	@GetMapping("/lineage")
	public ResponseEntity <List<Lineage>> getLineage(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@RequestParam("file-uri") String uri) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {


		return ResponseEntity.ok().body(cservice.getLineage(apiKey, dlsKey, uri));

	}


	@Operation(
			summary="Get the details organization hierarchy for the tenant",
			description = "Returns the list of organization positions and the admin and user list for each of them"/*,
			produces=MediaType.TEXT_PLAIN_VALUE*/)
	@GetMapping("/organization")
	public ResponseEntity <OrgPos> getOrganizationTree(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {


		return ResponseEntity.ok().body(cservice.getOrganizationTree(apiKey, dlsKey));

	}


}
