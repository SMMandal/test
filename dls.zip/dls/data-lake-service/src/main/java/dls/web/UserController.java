package dls.web;

import dls.bean.DlsResponse;
import dls.bean.User;
import dls.exception.*;
import dls.service.UserService;
import dls.vo.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.UniqueElements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Map;

import static dls.util.BeanValidationConstraint.*;

@RestController
@Tag(description="Create DLS users and keys", name="User")
@Validated
class UserController {

	@Autowired
    private UserService uservice;
	
	@Operation( summary = "Get users"/*,
			produces=MediaType.TEXT_PLAIN_VALUE,
			response=String.class*/)
	
	@GetMapping("/user")
	public ResponseEntity<List <User>> getUsers(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestParam(name="name", required=false) String dlsuser) throws DlsNotFoundException, DlsSecurityException, DlsPrivacyException {
		
		UserVO userVO = uservice.authorize(apiKey, dlsKey);
		
		if(!userVO.getAdmin()) {
			throw new DlsPrivacyException();
		}
		List <User> users = uservice.getUser(uservice.authenticate(apiKey), dlsuser);
		return ResponseEntity.ok().body(users);
	}
	
	@Operation( summary = "Get user names"/*,
			produces=MediaType.TEXT_PLAIN_VALUE,
			response=String.class*/)
	
	@GetMapping("/user/names")
	public ResponseEntity<List <String>> getAllUserNames(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey) throws DlsNotFoundException, DlsSecurityException {
		
		
		List <String> users = uservice.getAllUserNames(uservice.authenticate(apiKey));
		return ResponseEntity.ok().body(users);
	}

	@Operation( summary="Create new DLS user(s)")
	@PostMapping(value="/user")
	
	public ResponseEntity<List<DlsResponse>> register(

			@Parameter(hidden = true, description="API Key of tenant")
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="DLS Admin user", hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestBody @Size(min = 1, message = "{no.record.in.array}")
					@UniqueElements(message = "{duplicate.records}")
					List <@Length(max = USERNAME_LEN, message = "{invalid.user.length}")
					@Pattern(regexp = USERNAME_REGEX, message = "{invalid.username}") String > users,
			BindingResult err) throws DlsValidationException, DlsSecurityException, DlsPrivacyException {
		
		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}
		UserVO userVO = uservice.authorize(apiKey, dlsKey);
		
		if(!userVO.getAdmin()) {
			throw new DlsPrivacyException();
		}
		
		return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(uservice.register(userVO.getTenant(), users)) ;
	}
	
	@Operation( summary="Create new DLS user with key")
	@PostMapping(value="/user/key")
	
	public ResponseEntity<List<DlsResponse>> registerWithKey(
			@Parameter(description="API Key of tenant", hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="DLS Admin user", hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestBody @Size(min = 1, message = "{no.record.in.array}")
			@UniqueElements(message = "{duplicate.records}")
					List <@Valid User> users,
			BindingResult err) throws DlsValidationException, DlsSecurityException, DlsPrivacyException {
		
		if(err.hasErrors()) {
			throw new DlsValidationException(err.getAllErrors());
		}
		UserVO userVO = uservice.authorize(apiKey, dlsKey);
		
		if(!userVO.getAdmin()) {
			throw new DlsPrivacyException();
		}

		return ResponseEntity.status(HttpStatus.MULTI_STATUS).body(uservice.registerWithKey(userVO.getTenant(), users)) ;
	}

	@Operation( summary="Update user role")
	@PutMapping(value="/user/role")

	public ResponseEntity<String> updateUserRole(
			@Parameter(description="API Key of tenant", hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="DLS Admin user", hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestParam("user-name") String userName,
			@RequestParam boolean admin,
			@RequestParam(name="organization-position", required = false)
			@Length(min = ORGANIZATION_LEN_MIN, max = ORGPOS_LEN, message = "{invalid.orgpos.length}")
			@Pattern(regexp = ORGPOS_REGEX, message = "{invalid.orgpos}")
					String organizationPosition) throws DlsValidationException, DlsSecurityException,
			DlsPrivacyException, DlsNotFoundException {

		UserVO userVO = uservice.authorize(apiKey, dlsKey);

		if(null == userVO.getAdmin() || !userVO.getAdmin()) {
			throw new DlsPrivacyException();
		}
		uservice.updateUserRole(userVO, userName, organizationPosition, admin);
		return ResponseEntity.status(HttpStatus.RESET_CONTENT).body(GlobalExceptionHandler.UPDATED) ;
	}



	@Operation( summary="Delete user role")
	@DeleteMapping(value="/user/role")

	public ResponseEntity<String> deleteUserRole(
			@Parameter(description="API Key of tenant", hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="DLS Admin user", hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestParam("user-name") String userName) throws DlsValidationException, DlsSecurityException,
			DlsPrivacyException {

		UserVO userVO = uservice.authorize(apiKey, dlsKey);

		if(null == userVO.getAdmin() || !userVO.getAdmin()) {
			throw new DlsPrivacyException();
		}
		uservice.deleteUserRole(userVO, userName);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(GlobalExceptionHandler.DELETED) ;
	}



	@Operation( summary="Get user role")
	@GetMapping(value="/user/role")

	public ResponseEntity<List<Map <String, String>>> getUserRole(
			@Parameter(description="API Key of tenant", hidden = true)
			@RequestHeader(value="x-api-key", required=false) String apiKey,
			@Parameter(description="DLS Admin user", hidden = true)
			@RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@RequestParam(value="user-name", required=false) String userName) throws DlsValidationException, DlsSecurityException,
			DlsPrivacyException, DlsNotFoundException {

		return ResponseEntity.status(HttpStatus.OK).body(uservice.getUserRole(apiKey, dlsKey, userName)) ;
	}

	@Operation( summary="Delete user")
	@DeleteMapping(value="/user/{username}")
	
	public ResponseEntity<String> deleteUser(
			 @Parameter(description="API Key of tenant", hidden = true)
			 @RequestHeader(value="x-api-key", required=false) String apiKey,
		 @Parameter(description="DLS Admin user", hidden = true)
			 @RequestHeader(value="x-dls-key", required=false) String dlsKey,
			@PathVariable() String username) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		uservice.deleteUser(apiKey, dlsKey, username);
		return ResponseEntity.status(HttpStatus.OK).body(GlobalExceptionHandler.DELETED) ;
	}

	
}
