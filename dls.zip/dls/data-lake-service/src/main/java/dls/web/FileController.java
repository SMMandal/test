package dls.web;

import com.google.common.base.Joiner;
import dls.bean.Comment;
import dls.bean.DlsFileStatus;
import dls.bean.DlsResponse;
import dls.bean.FileDescriptor;
import dls.exception.*;
import dls.service.DlsServiceHelper;
import dls.service.FileBundlingService;
import dls.service.FileService;
import dls.service.UserService;
import dls.vo.CatalogTextSearchVO;
import dls.vo.DirectoryVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Length;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.util.StreamUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;
import org.springframework.web.servlet.view.RedirectView;
import reactor.core.publisher.Flux;


import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.Pattern;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static dls.bean.CatalogQuery.META_QUERY_REGEX;
import static dls.bean.CatalogQuery.URI_QUERY_REGEX;
import static dls.exception.GlobalExceptionHandler.CREATED;
import static dls.util.BeanValidationConstraint.*;

@Slf4j
@RestController
@Validated
@Tag(description="Upload & download files", name="File")
public class FileController {


	@Autowired private FileService dservice;
	@Autowired private DlsServiceHelper dhelper;
	@Autowired private Environment ev;
	@Autowired private UserService uservice;
	@Autowired private FileBundlingService fbService;


	@Operation( summary = "Download file from DLS")


	@GetMapping("/file")
	public RedirectView download(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(value="file-uri") String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsBlobException {

		String fsPath = dservice.getFilePath(apiKey, dlsKey, fileURI);


//		fsPath = URLEncoder.encode(fsPath, StandardCharsets.UTF_8);
		return new RedirectView(fsPath);

	}
	@Operation( summary = "Download file from DLS staging location")

	@GetMapping("/file/temp")
	public void downloadFromStage(@Parameter(hidden = true)
				  @RequestHeader(value="x-api-key", required=false)  String apiKey,
			  @Parameter(hidden = true)
				  @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			  @RequestParam(value="file-uri") String fileURI,
								  HttpServletResponse response) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		File file = dservice.download(apiKey, dlsKey, fileURI);
		if(!file.exists()) {
			throw new DataIntegrityViolationException("file.not.exist.in.temp");
		}
		try {
			response.setContentType(URLConnection.guessContentTypeFromName(file.getName()));
			response.setContentLength((int) file.length());
		} catch (Exception e) {e.printStackTrace();}

		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\""+file.getName() + "\"");
		try
		{
			Files.copy(file.toPath(), response.getOutputStream());
			response.getOutputStream().flush();
		}
		catch (IOException ex) {
//			ex.printStackTrace();
			log.error(ex.getMessage() + " : " + fileURI);
			response.setHeader(HttpHeaders.CONTENT_DISPOSITION, null);
			throw new DataIntegrityViolationException("file.not.exist.in.temp");
		}
	}




	@Operation(summary = "Update file metadata"/*,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE*/)


	@PutMapping(value="/file/metadata" /*, consumes = "text/plain"*/)

	public ResponseEntity<String> updateMetadata(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri")  String fileUri,
//			@RequestParam(name="privacy", required = false)  PrivacyEnum privacy,
			@RequestBody String [] metadata) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		dservice.updateMetadata(apiKey, dlsKey, fileUri, metadata);
		return ResponseEntity.status(HttpStatus.RESET_CONTENT)
				.body(GlobalExceptionHandler.UPDATED) ;

	}


	@Operation(summary = "Update file savepoint",
			description = "Renaming the savepoint of a file will also automatically rename savepoint of all the file's archive as well")
	@PutMapping(value="/file/savepoint")

	public ResponseEntity<String> updateSavepoint(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri")  String fileUri,
			@Parameter(description="New savepoint name. Enter blank to remove existing savepoint.")
			@Length(max= SAVEPOINT_LEN, message="{too.long.savepoint}")
			@Pattern(regexp= SAVEPOINT_REGEX, message="{invalid.savepoint.format}")
			@RequestParam(required = false) String savepoint) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {


		return ResponseEntity.status(HttpStatus.OK)
				.body(dservice.updateSavepoint(apiKey, dlsKey, fileUri, savepoint)) ;

	}


	@Operation( summary = "Upload file to DLS", /*produces=MediaType.TEXT_PLAIN_VALUE,*/
			description="\n\rA file is uniquely identified in DLS by file name (along with extension) and savepoint name. "
					+ "\n\rWhile uploading a new file, provide a unique name for the file."
					+ " For new files, savepoint is optional."
					+ " If same file is being uploaded with updated content, provide a different savepoint name.\n\r"
					+ " Provide any arbitrary comma-separated key value pair for describing the metadata about file."
					+ "\n\rDLS determines following metadata inherently ~ file name, content type, file size, created on and creator dls key"
					+ "\n\rVarious combination of request parameter will allow various strategy in DLS to take, for example"
					+ "\n\r\t 1. Provide filename, savepoint, file and metadata will upload a file to directory /savepoint/file.name and write metadata"
					+ "\n\r\t 2. Provide filename, file and metadata will upload to /file.name and write metadata"
					+ "\n\r\t 3. Provide filename and file will only upload file and associate to any existing metadata"
					+ "\n\r\t 4. Provide filename and metadata will only write metadata in DB")

	@ApiResponses(value = {
			@ApiResponse(responseCode = "201", description = "External file uploaded/metadata updated"),
			@ApiResponse(responseCode = "202", description = "File uploaded request accepted"),
			@ApiResponse(responseCode = "401", description = "Invalid API key"),
			@ApiResponse(responseCode = "403", description = "Invalid DLS key"),
	})

	@PostMapping(value="/file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
//	@Parameters({
//			@Parameter(name="metadata", description="metadata"/*, allowMultiple=true, paramType="form"*/)
//			//		@Parameter(name="overwrite")
//	})
	public ResponseEntity<String> upload(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(description="Uploaded filename to be unique")
			@RequestPart(required=false) MultipartFile file,
			@Parameter(description="File name", required=true)
			@RequestParam
			@Length(max= FILENAME_LEN, message="{too.long.filename}")
			@Pattern(regexp=FILENAME_REGEX, message="{invalid.filename.format}")
			String filename,
			@Parameter(description="Savepoint name")
			@RequestParam(required=false) @Length(max= SAVEPOINT_LEN, message="{too.long.savepoint}")
			@Pattern(regexp= SAVEPOINT_REGEX, message="{invalid.savepoint.format}") String savepoint,
			@Parameter(description="Source directory")
			@RequestParam(required=false)
//			@Length(max= DIRECTORY_LEN, message="{too.long.directory}")
			@Pattern(regexp= DIRECTORY_REGEX, message="{invalid.directory.format}") String directory,
			@Parameter(description="Comma-separated KV pair")
			/*@RequestParam(required=false, name = "metadata")*/ String [] metadata,
			@Parameter(description="Comment")
			@RequestPart(required=false) @Length(max= 255, message="{too.long.comment}") String comment,
			@Parameter(description="Overwrite, Append or Archive. Default Restrict",
					schema = @Schema(type = "string", allowableValues = {"APPEND", "ARCHIVE", "OVERWRITE"}))
			@RequestParam(required=false, defaultValue="RESTRICT") FileDescriptor.UploadMode mode)

			throws IOException, DlsSecurityException, DlsNotFoundException, DlsPrivacyException {


//		String [] metadata = Optional.ofNullable(meta).map(m -> m.toArray(new String[0])).orElse(null);
		if(null == file) {

			if(filename.contains(URL_REGEX)) {
				if(null != directory) {
					throw new DlsValidationException("outofband.directory.impossible");
				}
				dservice.uploadOutOfBand(apiKey, dlsKey, filename, savepoint, metadata);
				return ResponseEntity.status(HttpStatus.CREATED).body("external") ;
			}
			dservice.update(apiKey, dlsKey, filename, savepoint, directory, metadata);
			return ResponseEntity.status(HttpStatus.CREATED)
					.body(GlobalExceptionHandler.UPDATED) ;
		} else {

			return ResponseEntity.status(HttpStatus.ACCEPTED)
					.body(dservice.upload(apiKey, dlsKey, filename, savepoint, file, mode, directory, metadata, comment)) ;

		}
	}

	@Operation(summary = "Update file directory",
			description = "Move file from one directory to another")
	@PutMapping(value="/file/directory")

	public ResponseEntity<String> updateFileDirectory(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri")  String fileUri,
			@Parameter(description="New directory path")
			@Length(max = DIRECTORY_LEN, message = "{too.long.directory}")
			@Pattern(regexp= DIRECTORY_REGEX, message="{invalid.directory.regex}")
			@RequestParam(required = false) String directory) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {


		return ResponseEntity.status(HttpStatus.OK)
				.body(dservice.updateFileDirectory(apiKey, dlsKey, fileUri, directory)) ;

	}

	@Operation( summary="Delete a file")
	@DeleteMapping("/file")
	public ResponseEntity <String> deleteFile(HttpServletResponse response,
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(value="file-uri") String fileURI,
			@RequestParam(required = false) boolean forced) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		dservice.delete(apiKey, dlsKey, fileURI, forced);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(GlobalExceptionHandler.DELETED);

	}

	@Operation(
			summary="Upload multiple files to DLS",
			/*produces= MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.MULTIPART_FORM_DATA_VALUE,

			response=String.class,*/
			description = "Upload multiple files along with the file descriptor\n" +
					"Following is a sample file descriptor JSON : \n" +
					"[{\n" +
					"\t\"filename\": \"\",\n" +
					"\t\"savepoint\": \"\",\n" +
					"\t\"mode\": \"\",\n" +
					"\t\"directory\": \"\",\n" +
					"\t\"comment\": \"\"\n" +
					"\t\"metadata\": [\"K=V\"]\n" +
					"}]"
	)


	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "External File uploaded / metadata updated"),
			@ApiResponse(responseCode = "202", description = "File upload request accepted"),
			@ApiResponse(responseCode = "401", description = "Invalid API key"),
			@ApiResponse(responseCode = "403", description = "Invalid DLS key"),})

	@PostMapping(value="/files", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

	public ResponseEntity<List<DlsResponse>> uploadMultiple(

			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required = false)
			@Pattern(regexp = "\\S*", message = "{invalid.apikey.format}") String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required = false)
			@Pattern(regexp = "\\S*", message = "{invalid.dlskey.format}") String dlsKey,

			@RequestPart(name = "descriptor") @NonNull String descriptor,
			@Parameter(name = "file",/* allowMultiple = true, */required = true)
			@RequestPart(name = "file") @NonNull MultipartFile ... files) throws DlsSecurityException, DlsPrivacyException {

		return ResponseEntity.status(HttpStatus.MULTI_STATUS)
					.body(dservice.uploadMultipleFiles(apiKey, dlsKey, files, descriptor)) ;
			
	}



	@Operation(
			summary="Upload multiple files and create a bundle in DLS",
			/*produces= MediaType.APPLICATION_JSON_VALUE,
			consumes = MediaType.MULTIPART_FORM_DATA_VALUE,

			response=String.class,*/
			description = "Upload multiple files along with the file descriptor to create a compressed aggregate file as bundle \n" +
					"Following is a sample JSON for bundle descriptor\n" +
					"\n" +
					"[{\n" +
					"\t\"filename\": \"\",\n" +
					"\t\"directory\": \"\",\n" +
					"\t\"comment\": \"\",\n" +
					"\t\"metadata\": [\"K=V\"]\n" +
					"}]"
	)


	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Upload files to create a bundle"),
			@ApiResponse(responseCode = "202", description = "File upload request accepted"),
			@ApiResponse(responseCode = "401", description = "Invalid API key"),
			@ApiResponse(responseCode = "403", description = "Invalid DLS key"),})

	@PostMapping(value="/files/bundle", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

	public ResponseEntity<String> uploadBundle(

			@Parameter(hidden = true) @RequestHeader(value="x-api-key", required = false)
			@Pattern(regexp = "\\S*", message = "{invalid.apikey.format}") String apiKey,
			@Parameter(hidden = true) @RequestHeader(value="x-dls-key", required = false)
			@Pattern(regexp = "\\S*", message = "{invalid.dlskey.format}") String dlsKey,
			@Length(max = DIRECTORY_LEN, message = "{too.long.directory}")
			@Pattern(regexp= DIRECTORY_REGEX, message="{invalid.directory.regex}")
			@RequestParam(required = false) String directory,
			@RequestParam(required = false ,name = "name") String bundleName,
			@Parameter(name = "type", description="compression type",
					schema = @Schema(type = "string", allowableValues = {"ZIP", "TAR", "TAR-GZ"}))
			@RequestParam(required = false ,name = "type") String bundleType,
			@Parameter(description="Savepoint name")
			@RequestParam(required=false) @Length(max= SAVEPOINT_LEN, message="{too.long.savepoint}")
			@Pattern(regexp= SAVEPOINT_REGEX, message="{invalid.savepoint.format}") String savepoint,
			@Parameter(description="Comma-separated KV pair")
			@RequestParam(required=false) String[] metadata,
			@Parameter(description="Comment")
			@RequestPart(required=false) @Length(max= 255, message="{too.long.comment}") String comment,
			@RequestPart(name = "descriptor") @NonNull String descriptor,
			@Parameter(name = "file", /*allowMultiple = true,*/ required = true)
			@RequestPart(name = "file") @NonNull MultipartFile ... files

	)
			throws DlsSecurityException, DlsPrivacyException, IOException, SQLException, NoSuchAlgorithmException, DlsNotFoundException {


		log.info("Bundle Upload request received");
		ResponseEntity<String> ret=ResponseEntity.status(HttpStatus.ACCEPTED)
				.body(fbService.uploadBundleFiles(apiKey, dlsKey, files, bundleName, bundleType, descriptor, savepoint, comment, directory, metadata));
		log.info("Bundle Upload request processed");

		return ret;


	}

	@Operation(summary = "Get file status", hidden = true,
			description = "Get file status")
	@GetMapping(value="/file/status/{file-name}")

	public ResponseEntity<String> getFileStatus(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@PathVariable(name = "file-name")  String fileName,
			@RequestParam(required = false)  String savepoint,
			@RequestParam(required = false)  String directory) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {

		return ResponseEntity.status(HttpStatus.OK)
				.body(dservice.getFileStatus(apiKey, dlsKey, fileName, directory, savepoint));

	}

	@Operation(summary = "Update file status", hidden = true,
			description = "Update file status, e.g - uploaded, uploading, locked, unlocked, important, upload-paused, upload-resumed")
	@PutMapping(value="/file/status")

	public ResponseEntity<String> updateFileStatus(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@RequestParam(name="file-uri")  String fileUri,
			@Parameter(description="Select correct file status to update", schema = @Schema(implementation = DlsFileStatus.UploadStatus.class))
			@RequestParam(required = false) String status) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {

		dservice.updateFileStatus(apiKey, dlsKey, fileUri, DlsFileStatus.UploadStatus.valueOf(status));
		return ResponseEntity.status(HttpStatus.RESET_CONTENT).build();

	}
	
	@Operation(summary = "Update file comment",
			description = "Update file comment")
	@PutMapping(value="/file/comment", consumes = "text/plain")

	public ResponseEntity<String> updateFileComment(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri")  String fileUri,
//			@ApiParam(value="Comment", required=true)
			@RequestBody @Length(max= 255, message="{too.long.comment}") String comment) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {


		return ResponseEntity.status(HttpStatus.RESET_CONTENT)
				.body(dservice.updateFileComment(apiKey, dlsKey, fileUri, comment));

	}
	
	
	@Operation( summary="Delete file comment")
	@DeleteMapping("/file/comment")
	
	public ResponseEntity<String> deleteFileComment(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,

			@Parameter(description="File URI", required=true)
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(name="file-uri")  String fileUri) throws DlsSecurityException, DlsValidationException, DlsNotFoundException, DlsPrivacyException, IOException {

		return ResponseEntity.status(HttpStatus.RESET_CONTENT)
				.body(dservice.deleteFileComment(apiKey, dlsKey, fileUri));

	}
	
	
	@Operation( summary = "View comments for a particular file")


	@GetMapping("/file/comment")
	public ResponseEntity<List <Comment>> getFileComment(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Pattern(regexp= URI_QUERY_REGEX, message="{query.invalid.uri}")
			@RequestParam(value="file-uri", required = false) String fileURI) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException {

		List<Comment> comments = dservice.getFileComment(apiKey, dlsKey, fileURI);
		return ResponseEntity.ok().body(comments);


	}



	@Operation( summary = "Upload file to DLS", hidden = true)
	@PostMapping(value="/file/resumable", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)

	public ResponseEntity<String> uploadResumable(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@Parameter(description="File name (without whitespaces)", required=true)
			@RequestParam
			@Length(max= FILENAME_LEN, message="{too.long.filename}")
			@Pattern(regexp=FILENAME_REGEX, message="{invalid.filename.format}") String filename,
			@Parameter(description="Savepoint name")
			@RequestParam(required=false) @Length(max= SAVEPOINT_LEN, message="{too.long.savepoint}")
			@Pattern(regexp= SAVEPOINT_REGEX, message="{invalid.savepoint.format}") String savepoint,
			@Parameter(description="Source directory")
			@RequestParam(required=false) @Length(max= DIRECTORY_LEN, message="{too.long.directory}")
			@Pattern(regexp= DIRECTORY_REGEX, message="{invalid.directory.format}") String directory,
			@Parameter(description="Comma-separated KV pair") String [] metadata,
			@Parameter(description="Comment")
			@RequestPart(required=false) @Length(max= 255, message="{too.long.comment}") String comment,
			@RequestParam(required = true) Long sizeInBytes)

			throws IOException, DlsSecurityException, DlsNotFoundException, DlsPrivacyException {
		return ResponseEntity.status(HttpStatus.CREATED)
					.body(dservice.uploadResumable(apiKey, dlsKey, filename, savepoint, directory, metadata, comment, sizeInBytes)) ;

	}

	public static final String DATE_TIME_FORMAT = "dd-MMM-yyyy HH:mm:ss";
	public static final String DATE_TIMEZONE_FORMAT = "dd-MMM-yyyy HH:mm:ss z";
	public static final String CONTENT_DISPOSITION = "Content-Disposition";
	@Value("${local.fs.failsafe.path}") private String stagingDirectory;
	@Value("${dls.catalog.default.page-size}") private Integer pageSize;
	@Operation( summary = "Download multiple files as ZIP", hidden = false)
	@GetMapping(value = "/files")
	public ResponseEntity<StreamingResponseBody> downloadAll(
			@Parameter(hidden = true)
			@RequestHeader(value="x-api-key", required=false)  String apiKey,
			@Parameter(hidden = true)
			@RequestHeader(value="x-dls-key", required=false)  String dlsKey,
			@RequestParam(required = false) String directory,
			@RequestParam(required = false)
			@DateTimeFormat(pattern=DATE_TIME_FORMAT, fallbackPatterns = {DATE_TIMEZONE_FORMAT})
					DateTime from,
			@RequestParam(required = false)
			@DateTimeFormat(pattern=DATE_TIME_FORMAT, fallbackPatterns = {DATE_TIMEZONE_FORMAT})
					DateTime to,
			@Pattern(regexp= META_QUERY_REGEX, message="{query.invalid.metadata}")
			@RequestParam(value ="metadata", required = false) String metadata,
			@RequestParam(value ="filename", required = false) String filename,
			@RequestParam(value ="fileUri", required = false) List<String> fileUriList,
			@RequestParam(value ="fileCount", required = false) Integer fileCount,
			@RequestParam(value ="pageNo", required = false) Integer pageNo) throws DlsSecurityException, DlsPrivacyException, DlsNotFoundException {

		Flux<CatalogTextSearchVO> fileList = dservice.findZipEntries(apiKey, dlsKey, directory, from, to, metadata, filename, fileUriList,
				Optional.ofNullable(pageNo).orElse(1) - 1, Optional.ofNullable(fileCount).orElse(pageSize));

		return ResponseEntity
				.ok()
				.header("Content-Type", "application/zip")
				.header(CONTENT_DISPOSITION, "attachment;filename=download.zip")

				.body(out -> {

					ZipOutputStream zos = new ZipOutputStream(out);
					fileList
							.subscribe(f -> {
								String fsPath = stagingDirectory.concat("/").concat(f.getFsPath());
								String pathInsideZip = Joiner.on('/').skipNulls().join(Optional.ofNullable(f.getDirectory())
												.map(DirectoryVO::getDirectory)
												.orElse(null),
										f.getSavepoint(), f.getFileName());
								File file = new File(fsPath);
								try {
									ZipEntry zipEntry = new ZipEntry(pathInsideZip);
									zipEntry.setSize(file.length());
									zipEntry.setLastModifiedTime(FileTime.from(f.getCreatedOn().toInstant()));
									zos.putNextEntry(zipEntry);
									FileInputStream fis = new FileInputStream(fsPath);
									StreamUtils.copy(fis, zos);
									zos.closeEntry();
									fis.close();
								} catch (IOException e) {
									log.error("{} can not added in Zip. {}", fsPath, e.getMessage());
								}
							});
					zos.finish();
					zos.close();

				});
	}

	public enum PrivacyEnum { PUBLIC, PRIVATE }
}


