package dls.web;

import dls.bean.*;
import dls.exception.DlsNotFoundException;
import dls.exception.DlsPrivacyException;
import dls.exception.DlsSecurityException;
import dls.exception.DlsValidationException;
import dls.service.CatalogExplorerViewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

import static io.swagger.v3.oas.annotations.enums.ParameterIn.QUERY;

@RestController
@Tag(name="Catalog")
public class CatalogExplorerViewController {

    @Autowired private CatalogExplorerViewService service;

    @Operation(summary = "Search files, directories, browse through file catalogs",
            description = "Enter any text to search files and meta-data"/*, produces=MediaType.APPLICATION_JSON_VALUE*/)


    @Parameters({
            @Parameter(name="name", in = QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            @Parameter(name="path", in = QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            @Parameter(name="parent",  in = QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            @Parameter(name="savepoint",  in = QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            @Parameter(name="user", description="TCUP username who created the file or directory", in = QUERY,
                    array = @ArraySchema(schema = @Schema(type = "string"))),
            @Parameter(name="size", description="<code>>1KB</code>", in = QUERY, schema=@Schema(type = "string")),
            @Parameter(name="fileCount", description="Find directories which have count of immediate files <code>=0</code>", in = QUERY, schema=@Schema(type = "string")),
            @Parameter(name="time", description="File or directory creation timestamp", in = QUERY,
                    array = @ArraySchema(schema = @Schema(type = "string", example = "02-May-2023 00:48:02 +00:00"),maxItems = 2)),
            @Parameter(name="nameRegex", description = "Regular expression for file or directory name, e.g name without extension - <code>[^.]*</code>",
                    in = QUERY, schema = @Schema(type = "string")),
            @Parameter(name="metadata", schema = @Schema(type = "string"),
                    description= """
                            
                            """, in = QUERY),
            @Parameter(name="and", in = QUERY,
                    array = @ArraySchema(schema = @Schema(type = "string",
                            allowableValues = {"name", "path", "parent", "savepoint", "user", "size", "fileCount", "time", "nameRegex","metadata"}))),

            @Parameter(name="sort", in = QUERY,
                    schema = @Schema(type = "string", allowableValues = {"createdOn", "name", "size", "createdBy"})),
            @Parameter(name="order", in = QUERY,
                    schema = @Schema(type = "string", allowableValues = {"asc", "desc"})),
            @Parameter(name="fetch", in = QUERY,
                    schema = @Schema(type = "string", allowableValues = {"directoryOnly", "fileOnly", "directoryFirst", "fileFirst"})),
            @Parameter(name="pageNo", in = QUERY, schema=@Schema(type = "integer")),
            @Parameter(name="pageSize", in = QUERY, schema=@Schema(type = "integer"))
    })
    @GetMapping("/catalog/explorer")
    public ResponseEntity<ExploreCatalog> explore(
            @Parameter(hidden = true)
            @RequestHeader(value="x-api-key", required=false)  String apiKey,
            @Parameter(hidden = true)
            @RequestHeader(value="x-dls-key", required=false)  String dlsKey,
            @Parameter(hidden = true) @Valid CatalogExploreQuery query, final BindingResult bindingResult
    ) throws DlsSecurityException, DlsNotFoundException, DlsPrivacyException, DlsValidationException {


        if(bindingResult.hasErrors()) {
            throw new DlsValidationException(bindingResult.getAllErrors());
        }


        return ResponseEntity.ok().body(service.getCatalogExplorer(apiKey, dlsKey, query));

    }

}
