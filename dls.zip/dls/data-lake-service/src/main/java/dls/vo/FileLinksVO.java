package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@AllArgsConstructor

public @Data @Entity(name="file_links") @Builder class FileLinksVO {
	@Id
	@Column(name = "file_id")
	private Long fileId;
	private String linksTo;
}
