package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.Date;
@Data
@NoArgsConstructor
@AllArgsConstructor

@Entity(name="statistics") public class StatisticsVO {

	private @Id Long userId;
	private Long totalvolume;
	private Integer totalcount;
	private Integer totalshared;
	private Integer totalfailed;
	private Integer totalexternal;
	private Integer totaldeleted;
	private Integer totalbundled;
	private Date lastuploaded; 
	private Date firstuploaded;
}
