package dls.repo;

import dls.vo.StatisticsVO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatisticsRepo extends JpaRepository<StatisticsVO, Long> {


    List<StatisticsVO> findByUserIdIn(List<Long> uIds);
}
