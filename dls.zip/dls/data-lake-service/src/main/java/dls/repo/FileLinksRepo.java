package dls.repo;

import dls.vo.FileLinksVO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FileLinksRepo extends JpaRepository<FileLinksVO, Long> {

}
