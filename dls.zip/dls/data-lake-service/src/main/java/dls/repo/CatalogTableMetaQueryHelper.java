package dls.repo;

import com.google.common.base.Joiner;
import dls.exception.DlsValidationException;
import dls.vo.CatalogVO;
import org.springframework.stereotype.Component;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.validation.constraints.NotNull;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class CatalogTableMetaQueryHelper {
    @PersistenceContext
    private EntityManager entityManager;
    public Stream<Long> findByMetadata(@NotNull String metadata) {

        Map<String, Object> valueMap = new HashMap<>();
        List<String> onlyValueSearch = new ArrayList<>();

        String predicate = prepareMetadataQuery(metadata, valueMap, onlyValueSearch);
        String valuePredicate = "";
        if(!onlyValueSearch.isEmpty()) {
            valuePredicate = ", jsonb_path_query(metadata, 'strict $.* ? (" + Joiner.on(" || ").join(onlyValueSearch) + ")')";
        }

        String qString = "SELECT * " + valuePredicate + " FROM catalog " + predicate;

        System.out.println(qString);

        Query query = entityManager.createNativeQuery( qString, CatalogVO.class);

        valueMap.forEach(query::setParameter);

        return Optional.ofNullable( query.getResultList())
                .map(List::stream)
                .map(s -> s.map(c -> ((CatalogVO)c).getId()))
                .orElse(Stream.of( Long.MAX_VALUE));
    }

    public static void main(String[] args) {
        String metadata = "key<='val1' & key2 , key > '333'";
//        String metadata = "key='val1' & key2 , 'val3' & key = 'val3'";
        Map<String, Object> valueMap = new HashMap<>();
        List<String> onlyValueSearch = new ArrayList<>();

        metadata = new CatalogTableMetaQueryHelper(). prepareMetadataQuery(metadata, valueMap, onlyValueSearch);
        System.out.println(metadata);
        System.out.println(valueMap);

    }

    private String prepareMetadataQuery(@NotNull String metadata, Map<String, Object> valueMap, List <String> onlyValueSearch) {

        AtomicInteger i = new AtomicInteger(1);

        metadata = Stream.of(metadata.split(","))
                .map(String::trim)
                .map(s -> Stream.of( s.split("&") )
                        .map(String::trim)
                        .map(s1 -> {
                            // in K='V' format
                            if(s1.matches("\\w+ *(>=|<=|>|<|!=|=) *'.*'")) {
                                String [] tokens = s1.split(" *(>=|<=|>|<|!=|=) *");
                                String operator =  s1.split("'")[0].replaceFirst("\\w+","");
                                String val = "val" + i.getAndIncrement();

                                Object literal = tokens[1].replace("'","");
                                try {
                                    valueMap.put(val, Double.parseDouble(literal.toString()));
                                    return "CAST(metadata->>'" + tokens[0].trim() + "' AS decimal) " + operator + " :" + val;

                                } catch (NumberFormatException e) {

                                    if(!operator.equals("=")) {
                                        throw new DlsValidationException("Non-numeric value " + tokens[1] + " can not have comparison operator " + operator);
                                    }
                                    if(tokens[1].contains("*")) {
                                        literal = tokens[1].replace("'","").replace('*','%');
                                        operator = " LIKE ";
                                    }
                                    valueMap.put(val, literal);
                                }

                                return "metadata->>'" + tokens[0].trim() + "' " + operator + " :" + val;
                            }
                            // in K format
                            else if (s1.matches("\\w+")) {
                                return " (metadata -> '" + s1 + "') IS NOT NULL" ;
                            }
                            // in 'V' format
                            else if(s1.matches("'.*'")) {

                                onlyValueSearch.add("@ like_regex " + s1.trim().replace("'", "\""));
                                return null;
                            }
                            else {
                                return s1;
                            }
                        }).filter(Objects::nonNull)
                        .collect(Collectors.joining(" AND ")))
                .filter(m -> !m.isEmpty())
                .collect(Collectors.joining(" OR "));

        if(!metadata.isEmpty()) {
           metadata = "WHERE " + metadata;
        }
        return metadata;

    }

}
