# Data Lake Service
> `version 12.0 API Guide`
> 
> `DOCUMENT VERSION 2.1 01-03-2021` 



## 1. Introduction

### 1.1. What is Data Lake Service?
Data Lake Service (DLS) is a set of REST end-points to store and retrieve files and associated metadata in a multi-tenant cloud environment. It provides a set of API for file metadata management. Data Lake can be utilized to store and retrive various kinds of files like data files, program files, log files, binary files, analytics output files, device firmware packages etc. Depending upon the use cases the clients of DLS can be data scientists, edge applications or other TCUP services as well. DLS also provides number of file catalouging API to find files based on various filter conditions.



### 1.2. Concepts of DLS

DLS primarily provides APIs for four different categories of tasks. They are to as below -

1. **File management** - It includes file upload, overwrite, append, archive, download and delete.
2. **Cataloging** - This allows to search files, file lineage, metadata, organization, directory hierarchy and statistics of usage. File search has a wide range of filter parameters to provide flexibility to the users.
3. **Access control** - This includes tenant and user management, file sharing, directory based permissions management, setting up organizational positions and storage limit control.
4. **Metadata management** - It includes metadata governance by defining metadata schema and directory rule. It also helps to associate metadata with files. Linking two files 

Following are some more detail about the basic concepts in DLS -

**Catalog**

Catalog is a read-only view of the user's account in DLS in various perspective. User can get a list of files based on various filter parameters like file name, extension, upload time, size, metadata etc. This is called a file catalog. It shows detail about the file including it's download URI. Another variant of file catalog is directory catalog, where the content of file catalog is displayed in a virtual directory hierarchy.  In another scenario, user can fetch the lineage data of a particular file. **`Lineage`** is a brief history of operations on a specific file. There are few  other APIs which simply provides the list of file URIs in DLS or the list of metadata keys existing in DLS or list of relation names used in DLS.

**File**

DLS can store any type of file and is completely agnostics of the file content. For a particular DLS user, the file must be uniquely named before storing in DLS. There is a limit on the maximum size of the file that can be uploaded in DLS; by default, it is 5GB. The limit can be increased or decreased by changing DLS configuration. Files can be physically deleted from storage but DLS keeps the file related information in database. Each file successfully uploaded in DLS, will have a unique `file-uri`. 

In the following conditions though, files with same name can be added in DLS by a particular DLS user -

- files having same name but having different `savepoint`
- files of same name with different directories
- duplicate file uploaded in DLS with either `APPEND`, `ARCHIVE` or `OVERWRITE` mode 
- file is deleted and uploaded once again with same name

**Out-of-band File**

Files stored in external locations, can also be registered in DLS as `out-of-band` files. Instead of file-name, these files are identified by a fully qualified URL pointing to the external location. To register an out-of-band file, only the file URL is to be sent to the DLS file upload API. Although, out-of-band files are stored/retrieved externally by the clients, DLS can still maintain file catalog and other operation on the file. 


> **Important Note**! 
>
> The `out-of-band` file URL has to be absolutely unique in the context of DLS. This means that the same `out-of-band` URL can not be used by any two users from same or different tenants. This ensures that same external file is never referenced simultaneously.



Following list of DLS operations are allowed/restricted for out-of-band files -

| Operations Allowed                                           | Operations Not Possible                     |
| ------------------------------------------------------------ | ------------------------------------------- |
| 1. upload (register) in DLS with metadata, savepoint, directory | 1.  upload duplicate URL in any scenario    |
| 2. fetch detail in catalog                                   | 2. download using DLS download API          |
| 3. share to other DLS users                                  | 3. overwrite, append, archive using DLS     |
| 4. link to another internal and out-of-band file             | 4. registration of external file operations |
| 5. mark deleted in DLS                                       | 5. delete file from storage using DLS       |
| 6. update savepoint, metadata, comment, directory            |                                             |

**Metadata**

Meta-data is a key value pair that is used to describe related information about a file. By default, metadata key and value is added in ad-hoc manner by the user. When ad-hoc metadata is added for a file, the datatype of the metadata value is always assumed to be text. Sometimes, metadata can also be mentioned for the directory, which is used as directory rule.

**Metadata Schema**

Metadata schema can be defined by DLS admin to disallow users to add ad-hoc metadata. Metadata schema is tenant specific and when it is defined, all users of the tenant becomes `schematic` to follow the metadata schema. By default, all tenants are non-schematic. There could also be some tenants where metadata schema is defined but still the admin allows users to add ad-hoc metadata. 

**Directory**

Directory can be independently registered in DLS by DLS admins. One or more files may be associated with a directory.  Directory is an optional concept in DLS and it may not be at all required for a specific use case. It may be noted that files are not actually stored in DLS managed storages as per the directories mentioned. Directory provides a virutal hierarchy of files visible to users. The update directory API for files may be used to virtually move (cut-paste) a file from one directory to other. DLS provides directory based catalog API to render directory hierarchy and associated files. Directory can be deleted provided there is no file associated with it.

**Directory Permission**

Access control permissions given on the directory are meant for files associated with it. Directories may have sub-directories. Permission has to be explicitly mentioned for each directory depth. It would not be automatically inherited from parent or child directories.

**Directory Rule**

Directory may also be used to set up meta-data rule for the files. When directory-based metadata rule is set, it allows admins to ensure that DLS users are providing mandatory set of metadata while uploading files associated with the directory. 

**Link**

Link is a special metadata of file, which is used to record relation between two existing files of DLS. Link can be created and fetched in various use cases where the two files may be a program file and data file pair, an input and output file pair, the raw file and processed file pair, even two split files of main file and so on. Same relation name can be used in multiple links as well as two files can have more than one relation names. Link helps the user to generate an unbounded graph of files and relation names, e.g -

```mermaid
graph LR
A(Payrol.java) -->|needs| B(data.csv)
A -->|generates|C(Payslip.pdf)
B -->|has|D(header.csv)
C-->|sentBy|E(emailer.java)
   

```

**Users**

Below diagram shows the users and roles in DLS. Entities like TCUP admin, TCUP tenant and TCUP user are required to be individually provisioned in DLS for proper working. TCUP Admin is mapped as an admin in DLS which has privileges to invoke administrative APIs. Provisioning TCUP tenant in DLS will automatically provision a tenant-level DLS admin user called `dlsadmin`.  All other TCUP users would be directly mapped to users in DLS. In case, organization structure is enforced in DLS, TCUP users can further be provisioned either as Organization Admin or Organization Users at various levels of organization position.

```mermaid
graph TB
A((User)) -->B[TCUP Admin]
A-->C[TCUP Tenant]
A-->D[TCUP User]
B-->E(Admin)
C-->F('dlsadmin')
D-->G(Admin)
D-->H(User)
G-->R((Org))
H-->R

```

**Storage Options in DLS**

Following table briefly describes the various storage options available in DLS.

| Storage Type                      | Category | Use Case Examples                             |
| --------------------------------- | -------- | --------------------------------------------- |
| Hadoop (TCUP managed HDFS)        | Internal | In-premises or private cloud DLS installation |
| DLS Local File System (NFS mount) | Internal | Cost-effective alternative of HDFS storage    |
| Azure HDInsight / AWS EMR         | Internal | Large installations                           |
| Azure Blob Store / AWS S3         | External | Cost effective alternative of managed Hadoop  |
| Client's Local File System        | External | Large files having restriction in movements   |





### 1.3. Notes on DLS Access Control

**Basic Access Control**

In DLS, files are logically isolated for each users of a tenant. This means, files uploaded by one user of DLS, are not accessible by others.  There is, however, a file share API using which user can enable others to  read (download) his file. In Data Lake Service, there is absolutely no way to access files from users of different tenants. In this basic access control, the uploader of the file, is considered the owner and can perform operations like download, overwrite, archive, delete, share etc on the file. The single default administrator named `dlsadmin` does not have any special privilege to access other users' files unless explicitly shared by those users.

**Directory-based Access Control**

In some scenaio, users of same tenant may require to work on a common set of files. The concept of `directory` helps to achive that. A directory is not just a metadata of a file, but it also serves as an access control measure for all the files attached to the directory. So, directory can also be considered as project or workspace where multiple users have various levels of access. When an "administrator"  define a directory and allows various users (off course from same tenant only) to access (read, write or delete) files from the directory, it becomes a way to allow multiple users to work on a common set of files. If a user has read (`R`) access on a directory, it can only download files from the directory. Whereas, having write (`W`) access will allow the user to upload new files to be associated with that directory. Delete (`D`) would allow user to delete a file. It may be noted that irrespective of whoever uploads the file, administrator can grant or revoke `R`, `W` and `D` access from users. In contrast to basic access control, only administrator is the "owner" of the directory as well as of all files associated with that directory. So, by default, he can perform all operations on the file.  One directory can have many users and one user can have access to many directories. Only administrator has access to create, modify or delete directory and permissions.  Once a file is under directory-based access control, it can not shared to other users as per the regular `share` API. An existing file in DLS can be moved from basic access control to directory-based access control and vice versa.

**Organizational Access Control**

In some scenario, users can be part of an existing organization structure.  So the administrators and users come from various position of the organization. The above two access control models are not sufficient in that case because the users are part of an organization which has various hierarchical positions with varying roles. Here tenant is not a human who tries to access DLS API rather tenant is a logical group of many users. The organization may also have more than one tenantship in DLS. Each organization have at least  one or more named (not the de facto `dlsadmin` as above) administrators mapped to DLS admins. These admins are top level admins of the organization. They have full access to all files uploaded in DLS by all other admins and users hierarchically below in the organization. Now, based on the organizational structure there can be other admins lower down the organizational hierarchy. These admins and users can be created and marked with their `organization_position` accordingly. While a user is given permission on a directory, all admins hierarchically above him would inherit full access on the directory as well. This behavior can be overwritten by creating specific permission for the admin on that directory. It is to be noted that access privilege can be granted by higher level admins only. This organizational access control extends the directory-based access control but provides additional visibility to the admins about the directories, files and permissions in the organization. This helps the file management more administrator driven and aligned to organization's existing hierarchy.

**Which access control model to be used when?**

Basic access control model is the default model which is to be used when there is no or only occassional read-only of sharing of files among various users of DLS. 

Directory-based access control allows easy sharing of files as well creation of workspace or project models. 

Organizational access control is more advanced options when there are requirement of administrative visibility to the files of various users of an organization.


```mermaid
graph LR
A(Organization) -->|1:n| B[Tenant]
B --> |1:n| C[admin]
B --> |1:n| D[User]
C --> |n:n| E(org_pos)
D --> |n:n| E
    
```

## 2. API

Following section describes various APIs of DLS. These are categorized as 

  - Catalog APIs, 
  - Metadata Schema Management APIs, 
  - File Management APIs, 
  - Directory Management APIs, 
  - File Linking and Sharing APIs 
  - User and Role Management API. 

> The administrative APIs are meant for internal users of DLS and TCUP service depelopers.

### 2.1. Common Headers and Response Codes

For all API calls, the HTTP request header called `x-api-key` must be sent by clients with a correct public key of the TCUP tenant or user. Following table is an approximate summary of HTTP response codes along with their probable cause of occurances in DLS :

| HTTP Code | Reason                                                       |
| --------- | ------------------------------------------------------------ |
| 200       | Success of any GET call, e.g - data found in Get Catalog API |
| 201       | Success of any POST call with one or more entities in request, e.g - Create User |
| 202       | Success of POST call which is not immediately complete, e.g - Upload File |
| 204       | Success of DELETE call with one or more entities             |
| 205       | Success of UPDATE call with one or more entities             |
| 207       | Response of call with multiple entities in request having individual response code |
| 400       | Error due to invalid input JSON or URL parameters            |
| 401       | Error due to invalid API Key : Unauthentic                   |
| 403       | Error due to unauthorized call to any API or passing invalid DLS key |
| 404       | Error due to data not found in GET calls                     |
| 409       | Error due to inconsistent data in backend or data integriety error |

> The `HTTP 409` may be thrown by DLS in various inconsistent situations like duplicate data, already existing data etc. For this reason, `HTTP 409`, in most scenario, will also contain a message in HTTP response body.



**Response Message**

The GET calls will return a JSON payload in HTTP response. In some scenario, the GET call returns array of text in the response whenever the response is not a in form of complex object. The POST/PUT calls will contain a simple text message when there was single entity in request. It will return a JSON whenever there are more than one entities in request.



### 2.2. Input Validation

The JSON payload sent in request body of POST or PUT calls are validated by DLS before processing further. Any error in validation, would return `HTTP 400` as a whole, even if one or many record of the JSON array are correct. 

***Response JSON Structure of Input Valisation Errors (HTTP 400) returned on POST and PUT***

Following JSON response is returned along with `HTTP 400` status code, in cases where there is input validation errors on the request JSON payload.

```
[
  {
    "key": "<offending key name of the JSON>",
    "value": "<offending value as mentioned in JSON>",
    "code" : 201,
    "message": "<detail error message>"
  }
]
```

** Only message is mandatory in above JSON.*



**Constraints of Input Validation**

- Missing mandatory attributes of JSON
- Length and pattern of the attribute value
- Duplicate records in array
- Extra attribute is ignored

> In case, the input JSON is not parsable or the attribute value does not conform to intended data type,  `HTTP 400` with message `Invalid input format` is returned.

## 3. Data Lake Catalog

Data Lake Catalog is the index of all uploaded files. A catalog contain name of each file, file meta-data, linked files, shared files and file transfer status.

### 3.1. Get and Filter DLS Catalog
A catalog is a data set which lists the available files in data lake and the unique path to access the files. Each DLS user have their own catalog and can view its own uploaded files in catalog. DLS user can not view other DLS users' catalog unless a file has been shared to.

The API to get the catalog details is as below -

```
GET https://[domain]/dls/catalog
```



**Filter Parameters**

|Parameter Name  |Description  |
|--|--|
| text | Search files using free-text search. This search is done on file name, savepoint name, metadata name and value. |
| time | A time or time-range in this format `dd-MMM-yyyy HH:mm:ss Z`  |
| size | Filter files based on file size, e.g `>5.2KB` or `=1.7MB` |
| external | By default all files are fetched. A boolean value `true` filters only external files and `false` fetches only files uploaded to DLS  |
| transferred | To list all files which has failed to be uploaded set the value to `false`.  |
| bundled | To fetch the bundles only, add `bundled=true`. By default, both files and bundles are returned. The catalog response JSON also contains the `bundle` descriptor attribute. |
| deleted | Set `true` to show deleted files. By default, only undeleted files are shown.|
| savepoint | Search files by savepoint names. It supports wildcard character `*`. |
| ownFile | Filters and shows files which has been shared to the user by other DLS users by setting this parameter `false` |
| metadata | List of comma-separated metadata in form of `K='V'`. It also accepts key name `K` or value `'V'` separately. E.g `K1='V1',K2='V2',K3,V4` |
| uri | Full URI or part of it |
| directory | Search files by their source directory location. `/` will search for files under root directory only. |
| filename | Search by filename. Wild-card is supported. |
| sort | Allowed values are `createdOn`, `fileName`, `size` |
| pageNo | By default 500 files are fetched. To fetch 501 to 1000 files mention `pageNo` value as 2 and so on|
| locked | Default is `false`. To filter only locked files, set value to `true`. |

>  **Wild-card Support for Query**
>
> As of TCUP release 11, wild-card is supported in save-point, metadata keys, metadata values and file URI search parameters. For example, metadata can be searched as `version='1.*'`. Savepoint can be searched as `/home/user/Documents/*`. 



**JSON response :**

	{
	  "count": 1,
	  "pageNumber": 1,
	  "result": [
	    {
	     "bundle": [
	        {
	          "directory": "string",
	          "filename": "string",
	          "metadata": [
	            "string"
	          ],
	          "size-bytes": 0
	        }
	      ],
	      "bundled": true,
	      "created-on": "dd-MMM-yyyy HH:mm:ss z",
	      "deleted": false,	      
	      "deleted-on": "dd-MMM-yyyy HH:mm:ss z",
	      "external-to-dls": false,
	      "file-uri": "[file-uri]",     
	      "meta-data": "comma-separated KV pair",
	      "own-file": true,
	      "shared-to": "[comma-separated DLS users]",
	      "shared-by": "if not own-file, owner of the file",
	      "savepoint": "savepoint_name",
	      "size-bytes": 1024,
	      "transfer-success": true,
	      "locked": true,
	      "hidden": true
	    }
	  ]
	}

>***Notes*** : 
>Timezone as shown in `created-on` time is `UTC`.
>Size of the uploaded files as shown in `size-bytes` is the storage occupied in server.

| JSON Key | Description |
| -------- | ----------- |
| bundled | Wheather it is a file or bundle, `true` means it is a bundle |
| bundle | If a bundle, the descriptor JSON |
|created-on | Date of file upload in dd-MMM-yyyy HH:mm:ss z format|
|deleted-on | Date of file deletion in dd-MMM-yyyy HH:mm:ss z format, if it was deleted|
|deleted | `True`, if the file has been deleted |
|external-to-dls | `True`, if the file is stored outside DLS |
|file-uri |Unique file URI, use it to download |
|~~links-from~~ |`deprecated` Relation to other files, in form of `relation-name=file_URI`|
|~~links-to~~ |`deprecated` Relation to other files, in form of `relation-name=file_URI`|
|meta-data |comma-separated KV pair|
|own-file |Boolean flag to determine whether file is uploaded by user or shared by others|
|shared-to | Comma-separated list of DLS user names to whom this file has been shared to |
|shared-by | If it is not `own-file`, the name of the user who shared the file |
|size-bytes |Size of the uploaded file in bytes |
|savepoint | Save-point name|
|transfer-success |`False`, if the file was successfully uploaded to DLS but could not be stored on Distributed File System and is not available for download. |
|locked |`True`, if the file is locked. |
|hidden |`True`, if the file is hidden to other users. |

> If there is no file in catalog, `HTTP 404` status code is returned
> 



***Catalog Text Search Examples***
The text search option of Catalog is applicable on all meta-data keys, values, user names, file names and savepoint names available in DLS.
Text search is currently not applicable on file relationship names or file content.

 - use `,` or `|` to search either one of given criteria
 - use `!` as NOT operator 
 - wrap a text with `" "` to find exact match
 - white space will be treated as AND operator

> To find all CSV files, use `text=.csv` 
> To find all files other than CSV, use `text=!.csv`
> To find all CSV and PDF files, use `text=.csv,.pdf`

*Text search query parameters are **not** case-sensitive*



### 3.2. Get and Filter DLS Catalog with Directory Hierarchy

This API returns list of files which are sorted hierarchically as per the source directory structure. The response contains similar data as the above "get catalog" API but the response JSON is optimized for UI to render directory and files structure. In contrast to the above "get catalog" API, in case where directory contains no file, simple directory hierarchy is returned instead of `HTTP 404`. If there is no source directory mentioned during file upload, those files are shown under root directory named `/`.

There are various filter conditions that can be mentioned as URL parameters. To fetch all records, call this below API - 

```
GET https://[domain]/dls/catalog/directory
```

The response JSON is a hierarchy of directories and files in following format -

```
{
  "created-on": "dd-MMM-yyyy HH:mm:ss z",
  "directories": [
    ...
  ],
  "files": [
    {
      ...
      "type": "file"
    }
  ],
  "name": "string",
  "path": "string",
  "permitted-action": "string",
  "type": "directory"
}
```

The above directory JSON is hierarchical in the sense that it constructively repeats inside the attribute `directories` whenever a directory has a sub-directory and so on. The attribute `files` would contain all files which have same source directory. Below are the description of other attributes -


| JSON Key | Description |
| -------- | ----------- |
| created-on | Wheather it is a file or bundle |
| name | Name of the directory |
| path | Full path of the directory |
| permitted-action | Read (`R`), write (`W`) or delete (`D`) actions |
| type | Either `directory` or `file` |



The URL parameters that can be passed as filter condition are almost same as above "get catalog" API. Only  `pageNo` and `sort` parameters do not work with this API.



### 3.3. Get File Lineage

File lineage is all the operations on a specific file over a period of time. A file can be created, overwritten, appended with additional data, archived to another file or finally be deleted. Lineage shows all these details.

```
GET https://[domain]/dls/lineage?file-uri=[fileUri]
```

The response is a chronological list of operations along with file's size and metadata. In case of archive, the archive URI is also returned.

```
[{
    "operation": "ARCHIVE",
    "archive-uri": "something",
    "time": "08-Aug-2019 07:54:40 UTC",
    "size": 146,
    "meta-data": "ver=O2"
}]
```



### 3.4. Get All Ad-hoc Relation Names in DLS

Irrespective of tenants, all relation names created in DLS by all users, is listed using the following API -

```
GET https://[domain]/dls/relation
```

It returns newline separated text values (NSV).

In case there is no relation name created in DLS, `HTTP 404` is returned.

 

### 3.5. Get the List of Key Names

This API lists all the names used as metadata keys by the DLS user. It returns a list of text specific to the DLS user.

```
GET https://[domain]/dls/keylist
```

**Response** : Code 200
_Payload :_
`[ "metadata_key_name"]`



### 3.6. Get the List of File URIs

This API lists the file URIs for all files which are not deleted and successfully transfered to backend storage. It returns a list of text specific to the DLS user.

```
GET https://[domain]/dls/filelist
```

**Response** : Code 200
_Payload :_
`[ "list/of/file/uri"]`



### 3.7. Get Organization Hierarchy

If the organization is set for the tenant and the respective users are having their organizational positions set, this API will list down the complete organizational tree along with the admins and users at different organizational positions.

```
GET https://[domain]/dls/organization
```

**Response** : Code 200
_Payload :_

```
{
  "position": "tcs",
  "admins": [
    "admin1"
  ],
  "organization": [
    {
      "position": "kolkata",
      "users": [
        "user1"
      ],
      "admins": [
        "admin2"
      ]
    }
  ]
}
```

> The above JSON can be read as follows - 
>
> *"In `tcs` organization, the `admin1` is the organization-level admin. There is a `tcs/kolkata` position which has an admin named `admin2` and user named `user1`"*

In the above JSON, `organization`  may **recursively** appear inside `organization`  along with other attributes like `position` (organization-position name), `users` and `admins` (respective to that organization-position). 

`users` and `admins` are lists which may not have values in some cases.



### 3.8. Get DLS Statistics

This API returns statics of DLS user's account in terms of various parameters.

```
GET https://[domain]/dls/statistics
```

**Response**: Code 200
_Payload:_

```
{
  "first-uploaded": "dd-MMM-yyyy HH:mm:ss z",
  "last-uploaded": "dd-MMM-yyyy HH:mm:ss z",
  "total-bundled": 0,
  "total-count": 0,
  "total-deleted": 0,
  "total-external": 0,
  "total-failed": 0,
  "total-shared": 0,
  "total-volume": "string"
}
```

**Description of JSON**

| Field Name | Description |
| ---------- | ----------- |
| total-volume | Total volume of files stored in DLS for that user |
| total-count | Total number of files uploaded (including deleted files) |
| total-shared | Total number of files shared by other DLS users |
| total-failed | Total number of files which were not successfully uploaded  |
| total-external | Total number of external files |
| total-deleted | Total number of files deleted |
| total-bundled | Total bundles uploaded |
| last-uploaded | Timestamp of the most recent file uploaded |
| first-uploaded | Timestamp of first uploaded file |



## 4. Metadata Schema

From TCUP R11, DLS supports defining metadata schema. Schema can be managed by **administrators** like the tenant admin or any other admins. Once metadata schema is defined, all metadata added in DLS by other users during either file upload process or directory rule creation process, must adhere to the metadata schema. Metadata schema is tenant-speciffic. 

### 4.1. Create Metadata Schema

Metadata schema contains two parts. First one if a tenant speciffic `config` which is applicable for all metadata definition. Second part is a set of `metadata`, which provides a list of valid metadata to be used by user. Either the `config` or `metadata` or both can be added during metadata creation.

```
POST https://[domain]/dls/schema
```

The payload JSON looks like -

```
{
  "config": {
    "allow-adhoc": true,
    "max-key-len": 30,
    "max-value-len": 50,    
    "max-metadata-per-file": 20
  },
  "metadata": [
    {
      "description": "expected network bandwidth while uploading a file",
      "name": "bandwidth",
      "type": "TEXT"
    }
  ]
}
```



If the above JSON is valid and accepted by DLS for processing, a response JSON in following format can be expected along with a HTTP status code `207` (i.e multi-status).

```
[
  {
    "key": "config",
    "messages": [
      "updated"
    ],
    "code": 205
  },
  {
    "key": "name",
    "value": "bandwidth",
    "messages": [
      "created"
    ],
    "code": 201
  }
]
```

The error codes mentioned in the JSON signifies `205` - config updated, `201` - new metadata created, 409 - duplicate metadata name.

> **Important Note:** In the above example, the schema JSON has both `config` and `metadata` array. In other cases, if only `config` or `metadata` needs to be added, either of them can be present in JSON. Even only a few attributes of `config` can also be present, e.g - it may contain only `allow-adhoc`.

If the JSON is not valid a HTTP `400` is sent with proper messages like -

```
- Metadata name can not be blank
- Metadata type can not be blank
- "max-metadata-per-file" value should be between 0 and 255
- "max-key-len" value should be between 0 and 255
- "max-value-len" value should be between 0 and 255
- Metadata name can not be more than 255 characters long
```


Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

   **Notes:**       

      1.  ‘dls-user’ is the username of TCUP user
      2.  ‘dls-key’ is the TCUP user’s private API key
      3.  Only TEXT/NUMERIC type is supported



### 4.2. Get Schema


Get the details of schema, optionally provide the filter fields to fetch all the matching meta-data details

```
GET https://[domain]/dls/schema?names=[names]&type=[type]
```

The response is the details of metadata schema shown below. If there is no schema available, `HTTP 404` is returned. Even if there is no matching metadata as per the query parameter `name` and/or `type`, only the `config` part of the below response is returned.

```
{
  "metadata": [
    {
      "name": "",
      "type": "",
      "description": ""
    }
  ],
  "config": {
    "max-metadata-per-file": 10,
    "max-key-len": 10,
    "max-value-len": 10,
    "allow-adhoc": true
  }
}
```

### 4.3. Delete A Metadata from Schema

Using this API, a specific metadata can be removed from the set of metadata schema.

```
DELETE https://[domain]/dls/schema/metadata/{name}
```

Here `name` in the URL path is the key name of the metadata that is to be deleted. On successful deletion, the above API will return `HTTP 204` response. If meta data name is not found, then `HTTP 404` is returned. `HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.

> If the metadata is already in use as part of already uploaded file, the deletion from schema would not cause any effect on the already uploaded file. Files uploaded after the deletion, would only be impacted.



### 4.4. Delete Schema

This API completely removes metadata schema and disable schema enforcement for the tenant and all users of the tenant. This makes the tenancy `non-schematic`.

```
DELETE https://[domain]/dls/schema
```

Calling the above API will return `HTTP 204` response. If Schema config is not set or already deleted, `HTTP 409` is returned. `HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.



### 4.5. Create Ontology Prefix

The metadata used for Data Point APIs must be from public ontology. This API helps to register an ontology prefix and the vocabulary link to the ontology defintion. 

```
POST https://[domain]/dls/schema/ontology?prefix=foaf&vocabularyLink=http://xmlns.com/foaf/0.1/
```

The `prefix` and `vocabularyLink` values must be individually unique. Maximum 10 word characters are allowed in `prefix` and `vocabularyLink` accepts maximum 255 characters as URL.



Only admin can create an ontology prefix in DLS.

> By default, `dct`, `dcat`, `prov`, `r3d` and `dls` are availble as pre-configured ontology prefixes. They can not be created using this API. An `HTTP 409` with message -` c` is thrown when 



### 4.6. Delete Ontology Prefix

Delete an already registered ontology prefix from DLS.

```
DELETE https://[domain]/dls/schema/ontology/[prefix]
```

An admin can delete an ontology prefix. On success, `HTTP 204` is returned.

### 4.7. Get Ontology Prefix

To get all existing ontology prefixes already registered in DLS, call this API -

```
GET https://[domain]/dls/schema/ontology
```

If there is data, it is returned in the following Map format.

```
{
  "prefix1": "vocabularyLink1",
  "prefix2": "vocabularyLink2",
  "prefix3": "vocabularyLink3"
}
```

If there is no ontology prefix registered in DLS, `HTTP 404` is returned. 

> By default, `dct`, `dcat`, `prov`, `r3d` and `dls` are availble as pre-configured ontology prefixes. These are not shown in the above Get Ontology prefix response. 



## 5. File Management

### 5.1. File Upload

DLS provides API to upload file. While uploading a file, an arbitrary set of meta-data can be sent along with the file. These meta-data are represented in `key=value` format, separated by comma. Here both `key` and `value` are user defined. Each file uploaded in DLS will have a unique `file-uri` across entire DLS. 

```
POST https://[domain]/dls/file?filename=drop.sql
```

Content-Type: `multipart/form-data`
File Part :  `-F metadata=type=sql,loc=100`

The above API call will upload a file "drop.sql" and describe it as a SQL file with 100 lines of code.
Response Body will contain the `file-uri` of the uploaded file.
Response Header : HTTP Status code `202 Accepted`

If meta-data is not in correct format then HTTP `400 Bad Request` status code with message `Meta-data is not in correct format` is returned.

> **Note** : Whitespace is not allowed in filename.

#### 5.1.1. Update Meta-data

File upload API can also be used to update the set of meta-data which have been already created for a file. In case there is no multi-part file in payload of the above API and the `filename` request parameter contains an existing file in data lake then `meta-data` gets updated in DLS and no other action is taken.

In that case, `HTTP 205 Updated` response is returned.



#### 5.1.2. Upload Out-of-the-band File

Instead of uploading a file, it is possible to link an external file in DLS. Here `filename` request parameter in the above API call will contain an URI instead of a file name.



#### 5.1.3. Save-point

While re-uploading same file after some content modification, it may be necessary to keep the previously uploaded file available in DLS. To enable this, `savepoint` can be mentioned for a file. Save-point allows multiple copies of same file to exist in DLS, under different `savepoint` names. If no save-point is mentioned, re-upload of same file will be restricted.

```
POST https://[domain]/dls/file?filename=drop.sql&savepoint=sp
```



**Use Savepoint to Save File Directory**

As on TCUP release 11, directory values can be passed in savepoint in form of `/some/directory/`

The resulting file URI will also contain this user provided directory.

**Rules for savepoint -**

- Max length 50 chars
- Only non-white-space, alphanumeric characters, `_`, `-`, `:`, `.` and `/` are allowed
- Max depth of directory hierarchy allowed is 10
- At least one alphabet character must be present in `savepoint` name
- At least one character must be present in each directory name in `savepoint` 
- Case in-sensitive



#### 5.1.4. File Upload Mode : Overwrite

Starting TCUP release 11, existing files uploaded to DLS can be overwritten. A URL parameter named `overwrite` when set to `true` will overwrite the file if exists.

#### 5.1.5. File Upload Mode : Archive

In this mode, when a file is re-uploaded, DLS will automatically archive the previously uploaded file. 
Assume there is a file `F1` created on `T1` in DLS. At time `T2`, the same file `F1` gets re-uploade with `mode=ARCHIVE`. 

Now in DLS Catalog, the latest file `F1` which created on `T2` is shown along with another file `F1_T2` which has original creation timestamp `T1`. User can both download `F1` and `F1_T2` using regular download API.

The archive file can be downloaded, overwritten, appended, archived and deleted if required.

#### 5.1.6. File Upload Mode : Append

In this mode, content of the uploading file is appended with the file already existing in DLS. 



> If no mode is mentioned, or a value `RESTRICT` is provided, the default behaviour is shown where re-upload of same file is **not** allowed.



#### 5.1.7. Notes on File URI

> **Important Note for R11 :**
>
> The file URI format has been changed in TCUP R11. Please note the the below format carefully. The old format was like -
>
> ```
> /{tcup_user}/{dls_user}/{file_extension}/{file_name}/{savepoint}/{file}
> ```

The relative path of uploaded file, or the `file-uri` is 

```/{tcup_user}/{dls_user}/{file_extension}/{file_name}/{savepoint}/{file}
/{tcup_user}/{dls_user}/{directory_id}/{savepoint}/{file}
```

For example, if a TCUP user "company_x" has one DLS user "employee_y" who has uploaded a file "payslip.pdf" then the file URI will be `/company_x/employee_y/payslip.pdf`.

If the DLS user has mentioned the save-point name as "January", then the URI will be `/company_x/employee_y/January/payslip.pdf`.

File URI is unique across DLS.



***Validation of input fields in file upload API***

 1. `filename` query parameter must match the uploaded file name.
 2. Maximum 50 meta-data can be uploaded for a file
 4. Meta-data key must be 3 to 20 characters long; only alpha-numeric and underscore are allowed
 5. Meta-data value must be 1 to 50 characters long; alpha-numeric, whitespace and  `.` `*` `\` `/` `+` `-` `:` are allowed
 6. Duplicate meta-data name, irrespective of case, can not be used while uploading a file in the same `PUT` call
 7. Meta-data name and value can not be similar, e.g `name=name` is not allowed
 8. `savepoint` query parameter length must not exceed 150 characters; only alpha-numeric, `_`and `/` are allowed 

> All above validation errors will result `HTTP 400` response from DLS

****

**By default, uploaded file size limit is 5GB, unless it is changed DLS server configuration.***

> In case, files larger than the permissible limit is being uploaded, DLS server will terminate the client HTTP connection without further processing the request. Client may not receive any response in such HTTP calls.





### 5.2. Updating Metadata of External Files

To update metadata of both internal and external (out-of-the-band) files , use the following API -

```
PUT https://[domain]/dls/file/metadata?file-uri=[URI/URL]
```

To send the new set of metadata, file part needs to be sent. 

Example of metadata file part in CURL is `-d "metadata=KEY%3DVALUE"`	

On successful updation, `HTTP 205` is returned.

If the file URI is not available in DLS, `HTTP 404` is returned.



> Metadata of an internal archived file can also be updated



#### 5.2.1 File Upload Constraints

There are several constraints applicable in file upload process. These are mostly integriety constraints and in most cases, `HTTP 409` error is returned to the user. Below are few examples -

- if the TCUP admin has set a storage limit for the tenant, file can not be updated if it's size is more than available space.
- any file larger than the configured limit (e.g 5GB) can not uploaded by HTTP API
- files with duplicate names are not allowed
- file being uploaded with a directory is rejected if either directory does not exist or user do not have write (`W`) permission on the directory
- if metadata schema is set by the admin, and ad-hoc metadata addition is not allowed, file having metadata not belonging to the metadata schema, is not allowed to be uploaded
- if file is being uploaded with directory and admin has set a metadata rule for that specific directory, there could be two scenario. In first case, when one or more file metadata is missing as per directory rule; and the enforcement type is `STRICT`, DLS returns error and does not allow file upload. In second case with enforcement type `STANDARD`, DLS allows file upload but the file is marked inconsistent. If all metadata is present as per directory metadata rule, file is uploaded as normal, consistent file.







### 5.3. Upload Multiple Files

Multiple files can be uploaded using a single API call of DLS. Following REST end-point is to be used.

```
POST https://[domain]/dls/files
```

JSON payload in HTTP request to be sent as file `descriptor` -

```
[{
	"filename": "pom.xml",
	"savepoint": "v1",
	"mode": "OVERWRITE",
	"directory": "/D",
	"comment": "xx"
	"metadata": ["key1=value1"]
}]
```

The files have to be sent in HTTP request as multipart files. The uploaded file's name must match with exactly one entry in `descriptor`. In case, there is a mismatch in the number of files uploaded and number of descriptor entities mentioned in the JSON, an `HTTP 400` error message is returned. If either of the files or descriptor entities are duplicate in this API call, again `HTTP 400` error is returned. 

In case, the file is already existing in DLS, `HTTP 409 Already Exists` error is mentioned in response JSON.

Response code - `HTTP 207` (*i.e multiple response code inside*)

Response JSON -

```
[{
	"identifier": "pom.xml",
	"message": "RR/dlsadmin/xml/pom/v1/pom.xml",
	"code" : 202
}]
```



If the file upload is successful, then the URI will be returned in `message` attribute. If there is any validation error, the error message will also be sent via this `message` attribute.

> **Notes** : The acceptable values for upload `mode` are `OVERWRITE`, `ARCHIVE` and `APPEND`. If left blank, default behaviour of restricting overwrite is shown.

The `code` attribute inside the response JSON will contain exact HTTP status codes for any failure to upload the individual files. `HTTP 202` is the success code.



Example of CURL command to upload multiple files -

```
curl -X POST "http://localhost:8080/dls/files" -H  "accept: */*" -H  "x-api-key: xx" -H  "x-dls-key: xx" -H  "Content-Type: multipart/form-data" -F "descriptor=[{"filename":"pom1.xml"},{"filename":"pom2.xml"}]" -F "file=@/path/to/file/pom1.xml" -F "file=@/path/to/file/pom2.xml"
```



### 5.4. Upload File Bundle

A bundle is a compressed file containing many other individual files. DLS provides an API to send multiple files in a REST call and create a bundle at the server-side. Each individual file in the bundle can have their own metadata. The bundle must have a unique name either supplied by user or generated as timestamp from DLS. Individual files in bundle do not have individual `file-uri`. Bundle is downloaded as compressed file itself.

To create a bundle, call this below API along with the parameters mentioned in the table

```
POST https://[domain]/dls/files/bundle
```

List of bundle parameters -

| name         | description                                                  |
| ------------ | ------------------------------------------------------------ |
| `descriptor` | The bundle descriptor is a JSON to be sent as form data      |
| `name`       | The user supplied name of the bundle; if absent, system timestamp is used as name |
| `savepoint`  | Savepoint of a bundle, if a same bundle with previously used name already exists |
| `type`       | Type of the compression to be used to create a bundle - `ZIP` and `TAR` |
| `comment`    | User's comment to be added for the bundle                    |
| `directory`  | Directory to be associated the compressed file (bundle)      |
| `file`       | List of multipart files                                      |



On successful creation of bundle, `HTTP 202` is returned with the newly created bundle `file-uri` in the response body as plain text.

JSON payload in HTTP request to be sent as bundle `descriptor` -

```
[{
	"filename": "pom.xml",
	"directory": "/D",
	"comment": "xx",
	"metadata": ["key1=value1"]
}]
```

> **Note :** The `directory` attribute in bundle descriptor is used to create directory structure inside the compressed file so that when bundle is downloaded and decompressed, desired directory structure is found. This directory is not an attribute of bundle file.



The files have to be sent in HTTP request as multipart files. The uploaded file's name must match with exactly one entry in bundle `descriptor`. In case, there is a mismatch in the number of files uploaded and number of descriptor entities mentioned in the JSON, an `HTTP 400` error message is returned. If either of the files or descriptor entities are duplicate in this API call, again `HTTP 400` error is returned. 

In case, the bundle is already existing in DLS, `HTTP 409 Already Exists` error is mentioned in response JSON.

Response code - `HTTP 207` (*i.e multiple response code inside*)

Response  -

```
/bundle/uri
```

> Bundles are useful to store many small, inter-related files under a common, downloadable `file-uri`. Individual files of a bundle can not be downloaded separately as they do not have anu individual `file-uri`.



### 5.5. Get Bundle Descriptor

The `Catalog` JSON (output of `Get Catalog` API) lists bundles along with files. A bundle in `Catalog` JSON, has an attribute called `bundle`. It has following format -

```
[{
	"filename": "pom.xml",
	"directory": "/D",
	"comment": "Maven file",
	"size-bytes" : 1024
	"metadata": ["key1=value1"]
}]
```

Each entity in this bundle descriptor is an individual file being compressed in bundle. For example, here `pom.xml` is a `1KB` file which is compressed in bundle under directory `/D`.



### 5.6. File Download

Any file can be downloaded from data lake if the unique `file-uri` is known. If it is not known, it can be searched from file catalog. To download a file, use this following API -

```
GET https://[domain]/dls/file?file-uri=[/file/uri]
```


Set the HTTP request header `Accept : application/octet-stream`

The file download API gets automatically redirected to one or more other internal APIs of DLS, in order to download the file. The HTTP client must enable redirect option while calling this API.

Irrespective of the actual back-end storage of the file, this API uniformly downloads either from HDFS or Local storage.

> Files registered in DLS as `out-of-band`, can not be downloaded using this API.

Trying to download a deleted file will throw `HTTP 409` error with message `File is already deleted`.

> Bundles can also be downloaded using thia API



#### 5.6.1 Download Multiple Files

Multiple files can be downloaded using a single API. The files are downloaded as compressed ZIP file.

```
GET https://[domain]/dls/files
```

Following query parameters can be added as filters.

| parameter name | description                                                  |
| -------------- | ------------------------------------------------------------ |
| `directory`    | Optional directory name from where files to be downloaded. If `/` is sent, files from root directory will be zipped. If no value is sent, all files will be zipped. |
| `from`         | Files uploaded after this date is zipped.                    |
| `to`           | Files uploaded before this date is zipped.                   |
| `filename`     | One or more filename separated by comma. It can have wildcard (*) search. |
| `fileCount`    | Maximum number of files to be zipped in single API call.     |
| `pageNo`       | If there are more files than what is mentioned in `fileCount`, it can be used to download next set of files as ZIP. Default is `1`. |

> **Important Note:**
>
> Please contact your administrator to learn if DLS is configured with HDFS or NFS. This API only works with files stored in NFS. Files stored in HDFS are ignored.
>
> Files which are locked, external or under the sub-directories of the searched directory, are ignored.
>
> The files inside ZIP retains the actual upload time of the files.
>
> User must have `R` permission on the directory to ZIP and download the files in it.



### 5.7. File Download from Staging Location

The file upload process in DLS, involves storing the file in a temporary location before permanently sweeping it to DFS. Such files are marked as `transfer-success` = `false` in `Catalog` to differentiate that these files are still in staging location. Following API can be used to download these type of files from staging location as well -

```
GET https://[domain]/dls/file?file-uri=[]
```

Set the HTTP request header `Accept : application/octet-stream`

This improves data availability in situations where DFS storage is unavailable temporarily.



### 5.8. Update File Metadata

The existing set of metadata of a file can be changed to a new set of metadata using the following API -

```
PUT https://[dimain]/dls/file/metadata?file-uri=[\file\uri]
```

The new metadata set needs to be sent as part of request part called `metadata` in form of 

```
metadata=key1%3Dval1&metadata=key2%3Dval2
```

> Here `%3D` is URL encoded value of `=`

On successful updation of the file metadata, `HTTP 205`  will be returned. 

> **Important Note** : This API completely overwrites the existing set of metadata. It does **not** append with existing set. For this reason, this API can also be used to remove existing set of metadata by simply sending no `metadata` in the HTTP request.





### 5.9. Update Savepoint

To rename an existing savepoint, use the following API.

```
PUT https://[domain]/dls/file/savepoint?file-uri=[URI]&savepoint=[new_value]
```

This returns the newly generated file URI along with  `HTTP 200 (OK)` status code.

In case, invalid or non-existing file URI is given in input,  `HTTP 404` is returned. 

In case, the given savepoint name conflicts with another existing savepoint, `HTTP 409` is returned.

DLS automatically renames all archive files of the original file as well. 

If savepoint value is blank, then DLS removes the existing savepoint from the file URI.



> A special file lineage is maintained for renamed file URI. User can recognise, if a file has been renamed to another URI by searching file lineage with old URI.



### 5.10. Update File Directory

Using this API, the existing directory of a file can be updated. If there was no directory attached to the file, a new directory can be added. Also, if there was already a directory attached, the existing directory can be removed by passing an empty directory. 

```
PUT https://[dimain]/dls/file/directory?directory=[]&file-uri=[]
```

> **Important Note** : After directory is updated, the existing file URI changes.

If `file-uri` sent in request does not exist, `HTTP 404` error is returned. If directory does not exist or the user does not have `W` (write) permission on destination directory or does not have `D` delete permission on source directory, `HTTP 409` with proper error message is returned. 
If the `directory` and `file-uri` is already existing, then `HTTP 409 Already Exists` error is thrown. 

> Directory can be updated for `out-of-band` files also.

If the file is already shared to other users, the directory can not be attached unless file-share is removed.

> To remove existing directory of a file, the `directory` parameter need not to be sent in this API.



### 5.11. Update File Comment

This API helps to add comments to an existing file.

```
PUT https://[dimain]/dls/file/comment?file-uri=[]
```

The comment has to be sent in the request body as plain text along with a request header `Content-Type: text/plain`. 

Multiple comments can be added for a file by a single user. In case of shared files, different users can add comments on a same file.

> **Important Note** : A single comment can be only 255 characters long.

DLS would automatically add the user and timestamp for each comment added for a file.

A file which is shared to another user, can also have comments from that user.



### 5.12. Get File Comment

To retrieve all comments added by all users for a file, use this following API

```
GET https://[dimain]/dls/file/comment?file-uri=[]
```

The response of the above API call is as below -

```
[
  {
    "user": "",
    "comment": "",
    "commented-on": "29-Apr-2020 13:25:22 UTC",
    "file-uri": ""
  }
]
```


### 5.13. Delete File Comment

Comments for a file can be entirely deleted by using following API -

```
DELETE https://[dimain]/dls/file/comment?file-uri=[]
```

This API deletes all comments added by this user for this file.



### 5.14. Delete File

By using this API, a file can be deleted.

```
DELETE https://[dimain]/dls/file?file-uri=[\file\uri]
```

On successful deletion of the file, `HTTP 204` is returned.

Trying to delete an already deleted file will throw `HTTP 409` with message `File is already deleted`.
Trying to delete a file which does not exist invalid URI will throw `HTTP 404` with message `Not found`.

Invoking the file delete API will erase the file from storage and set the `deleted` flag as shown in file catalog.



> A deleted file can again be uploaded having same file name.
>
> If the file is re-uploaded, catalog would show both the newly uploaded file as well as previously deleted files. Hence, in such scenario, catalog may contain duplicate `file-uri`. 



**NOTE :** *By default, catalog shows all deleted files. To filter out any files which have been deleted, as well as shared files which have been deleted by the owner, `deleted=false` search condition needs to be added in catalog query.*



## 6. File Link

File links are special metadata that relates two files with a custom relation name.

### 6.1. Create New Link
Uploaded files can be linked to each other using some Ad-hoc relationship names. This helps to create a transformation and dependency chain among files.

```
POST https://[domain]/dls/link/[relation]?lhs-file-uri=[/file/uri]&rhs-file-uri=[/file/uri]
```

> Relation names are not case-sensitive. All relation names are converted to lower case in the system.

Invalid relation names will result `HTTP 400`.

> `lhs` is abbreviation of Left Hand Side and `rhs` is abbreviation of Right Hand Side.



### 6.2. Create Multiple Links

Multiple files can be linked to each other with help of this API. 

```
POST https://[domain]/dls/links
```

JSON Payload to send to link multiple files -

```
[
  {
    "lhs-file-uri": "F1",
    "relation": "R1",
    "rhs-file-uri": "F2"
  }
]
```

Response code - `HTTP 207`

The response contains a JSON describing each file link and associated success or failure messages. For success, `linked` text is returned. For example -

```
[
  {
    "identifier": "F1 R1 F2",
    "message": "Invalid LHS file",
    "code": 400
  }
]
```

Here, first linking failed as the relation name was invalid, whereas the second linking succeeded.



### 6.3. Get File Link

Files can be searched using the relation name and with or without any of the two file names used in that relation. To get all files involved in a specific type of relation - 

```
GET http://[domain]/dls/link?relation=[name]
```

To get all files involved in other side of the relation -

```
GET http://[domain]/dls/link?lhs-file-uri=[/file/uri]&relation=[relation] 
```

or

```GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]&amp;relation=[relation]
GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]&relation=[relation]
```

To get all relations to other files - 

```
GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]
```

Response is strings separated by new-line delimiter. Each line contains a link details

```[lhs-file] [relation] [rhs-file]
[lhs-file] [relation] [rhs-file]
```



> To list all archived file, use relation name as `dls:archivedTo`



### 6.4. Delete File Link

To delete a link, use following API -

```
DELETE http://[domain]/dls/link?lhs-file-uri=[]&relation=[]&rhs-file-uri=[]
```

If this link is not available `HTTP 404` is thrown. After successful deletion `HTTP 200` is returned.

> Trying to delete a link for archived files using relation name as `dls:archivedTo`, is not allowed.



## 7. File Share

A DLS user can shared uploaded files to other DLS users. File sharing allows other DLS users to download a copy of the shared file but original file can not be modified. 



### 7.1. Create New Share

Following API can be used by any DLS user to share his/her uploaded files to other DLS users.

```
POST https://[domain]/dls/share/[dls-user]?file-uri=[/file/uri]
```

Here the `dls-user` URL parameter is the other DLS user to whom the file mentioned in `file-uri` query parameter, needs to be shared.

On successfully creation of file share,`HTTP 201` is returned by DLS.

If the `file-uri` value provided in query parameter does not exists in DLS or the URI belongs to other DLS users, `HTTP 404` response is returned. This restricts transitive sharing. For example, if a file is originally uploaded by DLS user A, is shared to DLS user B. This file can not be further shared to other DLS users by DLS user B.

If the `dls-user` mentioned in URL parameter does not exist, `HTTP 409` response code is returned.

Same file can be shared to multiple DLS users. 



### 7.2. Get File Share

This API helps a DLS user to know all the files that he/she has shared to other DLS users.

```
GET https://[domain]/dls/share
```

Here the all files shared to all DLS users will be listed.

```
GET https://[domain]/dls/share?dls-user=[A]
```

Here the files shared to DLS user `A` will be listed.

If no file has been shared yet, `HTTP 404` status code is returned.




### 7.3. Delete File Share

By using this API, a file which has been shared, can also be revoked from sharing.

```
DELETE https://[dimain]/dls/share/[dls-user]?file-uri=[\file\uri]
```

On successful deletion of the file share, `HTTP 200` status code is returned.

If the file share is already deleted, or `file-uri` value in query parameter does not exists in DLS or belongs to other DLS users, a `HTTP 404` status code is returned.

If the `dls-user`mentioned in URL parameter does not exist, `HTTP 409` response code is returned.





## 8. Directory

Directory is a newly introduced concept in DLS from TCUP11 onward.Now User can create Directory and assign permission to the users for that directory.User also can write meta data rules for a directory.


### 8.1. Create New Directory and Assign Permission to it

Only DLS **administrator** can create directory. 

```
POST https://[domain]/dls/directory
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "directory": "/myDir",
    "enforcement": "",
    "metadata-rule": [
      {
        "default-value": "",
        "name": "",
        "type": "",
        "value-mandatory": true
      }
    ],
    "permissions": [
      {
        "action": "",
        "directory-action": "",
        "users": [
          ""
        ]
      }
    ]
  }
]
```

**Response Codes** : `HTTP 207`

**Response Payload**

Following JSON response is returned after calling this API.

```
[
  {
    "key": "directory",
    "value": "/myDir",
    "messages": ["Directory already exists"],
    "code": 409
  }
]
```



**Notes:**
    

1.  Directory name can only contain alpha-numeric, `-` and `_`
2.  Directory name must start with `/`  and multiple sub-directories can be mentioned as well
3.  User can not and need not to create root directory  `/`
4.  While Creation of Directory permission is optional. User can create directory with or without permission assigned to it for users.
5.  if permission is asssigned for user the permitted action can be combination of `R` , `W`,  `D` 
6.  Enforcement must be STRICT or STANDARD
7.  Only TEXT/NUMERIC meta data type is supported

> **Notes on Hierarchical Directory:** 
>
> It is possible to create a hierarchy of directories in a single API call. The directory name should be in form of a directory path e.g - `/A/B`. Here multiple directories are created internally in DLS. The directory `/A` is implicitly created with the same permission intended for `/A/B`. But any directory rule given for `/A/B` is not added automatically for `/A`. Even if the directory rule validation fails for `/A/B` for any reason, directory `/A` and associated permission is added successfully in DLS. 

> **Notes on Permission Escalation:**
>
> If any user is given a specific permission on a directory, all **admin** users hierarchically above the explicitly mentioned user, would also gain the same privilege automatically. This is especially seen in organizational access control scheme of DLS.

> **Notes on Directory Rule**
>
> The directory rule mentioned during creation of directory has two important parameters. First one is `enforcement` type. It allows either of two fixed values, `STANDARD` and `STRICT`. By default, `STRICT` is assumed. The second parameter of rule is a set of metadata rule that creates a rule set. Each metadata rule has `name` and `type` of the metadata along with a flag called `value-mandatory` and a `default-value`.  Follow the below table to find the behaviour of directory rule enforcement based on these two parameters -
>
> | File Metadata                                                | Enforcement | Rule | Response                             |
> | ------------------------------------------------------------ | ----------- | ---- | ------------------------------------ |
> | All metadata present as per rule                             | `STRICT`    | Pass | Success                              |
> | Metadata is absent during file upload and no `default-value` in rule | `STRICT`    | Fail | Error                                |
> | One or more additional metadata given than rule              | `STRICT`    | Fail | Error                                |
> | Absent one or more metadata but `default-value` and `value-mandatory=false` present in rule | `STRICT`    | Pass | Default value taken                  |
> | Absent metadata with `default-value` and `value-mandatory=true`  in rule | `STRICT`    | Fail | Error                                |
> | All metadata present as per rule                             | `STANDARD`  | Pass | Success                              |
> | One or more additional metadata given                        | `STANDARD`  | Pass | Success                              |
> | Metadata is absent and no `default-value` in rule            | `STANDARD`  | Pass | File marked with `inconsistent` flag |
>
> 



#### 8.1.1 Directory Management Permission

Assign directory management permissions to users for the directory. Use appropriate `directory-action` in the permission JSON. Following table describes how permission can be set :

|                    | `R`                                 | `W`                                        | `D`                               |
| :----------------- | :---------------------------------- | :----------------------------------------- | :-------------------------------- |
| `action`           | Download files from this directory. | Upload file(s) to this directory.          | Delete file(s) of this directory. |
| `directory-action` | Read content of this directory.     | Create sub-directories, permission, rules. | Delete this directory.            |



### 8.2. Update Permission for Directory 

Only DLS administrator can update permission to a directory. 

```
PUT https://[domain]/dls/directory/permission?directory=[directory]
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "action": "",
    "directory-action": "",
    "users": [
      ""
    ]
  }
]
```


Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

**Notes:**
    

1.  ‘dls-user’ is the username of TCUP user
    
2.  ‘dls-key’ is the TCUP user’s private API key
    
3.  While updating permission to a directory for group of users directory must exist 
    
4.  Permitted action can be R,RW and RWD as of now


### 8.3. Update Directory Meta Rules

Only DLS administrator can update meta rules for a directory. 

```
POST https://[domain]/dls/directory/meta-rule?directory=[directory]&enforcement=[enforcement]
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "default-value": "",
    "name": "",
    "type": "",
    "value-mandatory": true
  }
]
```


Response Codes : `207` , `400` for invalid payload

**Notes:**
    

1.  Enforcement must be STRICT or STANDARD
4.  Only TEXT/NUMERIC type is supported



### 8.4. Get Directory


Get the details of directory along with users and permitted action

```
GET https://[domain]/dls/directory?directory=[directory]
```

The response is a list of directories along with users and permitted action assigned to that directory

```
[
  {
    "directory": "",
    "permissions": [
      {
        "users": [
          ""
        ],
        "action": ""
      }
    ]
  }
]
```


### 8.5. Delete Directory

To delete Directory , use following API -

```
DELETE https://[domain]/dls/directory?directory=[directory]
```

If this directory name is invalid `HTTP 404` is thrown.After successful deletion `HTTP 204` is returned.

**Notes:**

1.  To delete a directory with files attached to it, first remove the files from this directory. Either delete the files using `DELETE /file` API or call  `PUT /file/directory` API to attach the files to any other directory.
2.  If user deletes a directory to which permission is assigned then permission assigned to the directory will also be deleted.
3.  If sub-directories exist, they need to be deleted explicitly before deleting the directory.


### 8.6. Delete Directory Permission

To delete the permission assigned to the user for any directory, use following API -

```
DELETE https://[domain]/dls/directory/permission?directory=[directory]&user=[user]
```

If there is no permission available for the directory and/or user, `HTTP 404` is returned. After successful deletion `HTTP 204` is returned.

**Notes:**

1. User can provide either directory name or user name or combination of both while deleting permission.
2. If only directory name is mentioned, any permission of all users on this directory is removed.
3. If only user name is mentioned, permissions to directories of this user, is removed.
4. At least one of two query parameters must be mentioned.


### 8.7. Delete Directory Meta Rule

To delete Directory meta rule , use following API 

```
DELETE https://[domain]/dls/directory/meta-rule?directory=[directory]&metadata-name=[metaDataName]
```

If this directory name is invalid `HTTP 404` is thrown.After successful deletion `HTTP 200` is returned.

**Notes:**

1. Meta data name is optional,if given only that meta data will be deleted for the directory,otherwise all meta data for that directory will be deleted





## 9. File Lock

Usually, a directory has files accessible by multiple permitted users. In some scenario,  one such user might want to restrict modification or deletion of a file by other users. The file lock feature can be used to restrict other users to overwrite, append, archive, delete, update file metadata or savepoint and change the file directory. Additionally, a locked file can be hidden from other users as well. Any user, who has write `W` permission on a directory, can lock any file under it. Only the same user or an admin can unlock such locked files. 

> In the catalog API response JSON, the file `locked` and `hidden` status is shown to the user who has locked the file. 



### 9.1. Lock a File

To lock a file, call the following API- 

```
POST https://[domain]/dls/lock?file-uri=[file-uri]
```

Here only `file-uri` request parameter is mandatory.

Optionally, to add comment while locking the file, send the comments (maximum 255 characters) in HTTP request body. `Content-Type` header is `plain/text`.

On success, `HTTP 201` response code with `locked` message is returned.



A lock can **not** be obtained on a file, if

- the file is already locked by some other user,

- the file is not under any directory,

- the file is external or out-of-the-band file, 

- user does not have write (`W`) permission on the directory under which file exists

- file upload `transfer-success` status is `false`.

In all these above cases, `HTTP 409` status is returned with proper message.



#### 9.1.1 Hide and Lock a File

To hide a file while locking, following API is used -

```
POST https://[domain]/dls/lock?file-uri=[file-uri]&hide=true
```

If the locked file is hidden, it is only visible in the catalog of the user who has locked it. It is also visible to an admin who has access to that directory where that file exists. But other users, in spite of having access to the directory, can not find the hidden file in their catalog.

> Only a locked file can be hidden.



### 9.2. Unlock a File

Only the user who has locked the file can unlock the file using the below API. An admin having access to the directory where the file exists, can also unlock the locked file.

```
DELETE https://[domain]/dls/lock?file-uri=[file-uri]
```

`http 204` is returned on success.



### 9.3. Update Hidden/Shown State of Locked File 

The locked file can be either hidden or shown. Following API can be used to hide or show a locked file.

```
PUT https://[domain]/dls/lock?file-uri=[file-uri]&hide=true
```

`http 205` is returned on success.



### 9.4. Get File Lock Status

```
GET https://[domain]/dls/lock?file-uri=[file-uri]
```

Following JSON response is returned if the file is locked.

```
{
  "reason": "",
  "hidden": "",
  "locked-by": "",
  "locked-at": "Tue Mar 02 17:40:39 IST 2021",
  "status": "locked"
}
```

In case file is not locked or already unlocked, following response is returned.

```
{
  "status": "unlocked"
}
```

If the file does not exist in DLS, `HTTP 404` is returned.



## 10. User Management

There are several API available for the DLS admin to be used to manage users of that tenant.



### 10.1. Create New DLS User 

Only DLS administrator can create another DLS user. 

```
POST https://[domain]/dls/user/key
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

	[{
	    "dls-key": "",
	    "dls-user": ""
	}]

Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

**Notes:**

1.  During DLS service activation of **user** from the portal, above API needs to be called.

2.  Service deactivation will NOT call any API of DLS

3.  ‘dls-user’ is the username of TCUP user

4.  ‘dls-key’ is the TCUP user’s private API key

5.  After successful provision of user in DLS, client can call all APIs of DLS (except user provision APIs) using both `x-api-key’ and ‘x-dls-key’ having same value of the user’s public API key.

6.  Otherwise, client can pass only ‘x-api-key’ of the user; in that case, API gateway will inject additional header called ‘x-dls-key’ in the forwarding HTTP request to DLS.

7.  This API allows the TCUP user to be the user of DLS.



### 10.2. Create New DLS User with Generated DLS Keys

Only DLS administrator can create another DLS user. 

```
POST https://[domain]/dls/user
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

	[
	   "dls_user_1"
	]

The response of the above API is a JSON returned as response body :

	[
	  {
	    "key": "dls_user_1",
	    "value": "032d7e73-909b-401f-82c8-e4b09b15ded2",
	    "messages": [
	      "created"
	    ],
	    "code": 201
	  }
	]

HTTP Response Code  `207` is returned on successful registration.

> If the `dls-user` is already registered, `HTTP 409 - Already exists`  error is returned. 



### 10.3. Get DLS User

Only DLS administrator can get the details of other DLS users.

1. Get details of a specific DLS user -  `GET https://[domain]/dls/user?name=xx`
2. Get all DLS users details  -  `GET https://[domain]/dls/user`

Response JSON is as follows -

```
[
  {
    "dls-key": "24374925-e77e-48b1-8f1b-c6e90ec51850",
    "dls-user": "dls_user_2"
  }
]  
```



### 10.4. List Existing DLS User Names

Every user of DLS is allowed to fetch list of other usernames by using the following API.

```
GET https://[domain]/dls/user/names
```

This API returns the usernames in following format -

```
[
  "dls_user_1",
  "dls_user_2",
  "dls_user_3"
]
```

This API is particularly useful to know other user names before sharing a file with other users.



> If no user is found then `HTTP 404` status is returned and `Not found` message is printed in response body.



### 10.5. Delete User

DLS users can be deleted only by DLS admin. If an user is deleted, all files uploaded by the user are also deleted from HDFS. All catalog information is also deleted for the user.

```
DELETE https://[dimain]/dls/user/{username}
```

Calling the above API will return `HTTP 200` response.  If there is no such username or the user is already deleted `HTTP 404` is returned.

`HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.



### 10.6. User Role 

DLS allows to define the role of an existing user in context of the users' organization. Based on the defined role, DLS can provide more detailed access control on files and directories that the user is entitled to access.

### 10.7. Create User Role

The user role is a combination of a meaningful URN pattern called the user's organizational-position (`org-pos`) and a flag stating whether this user is admin or non-admin. To define the role, the organization must have been defined during creation of tenant. 

> For example, if a DLS tenant `T1` is created with it's organization name as `Org1` then users of this tenant optionally can have any position as shown in the following example. 

| User | `org-pos`       | Admin | Inference              |
| ---- | --------------- | ----- | ---------------------- |
| U1   | Org1/Dept1      | true  | Admin of Dept1 of Org1 |
| U2   | Org1/Dept2      | true  | Admin of Dept2 of Org1 |
| U3   | Org1/Dept2/Lab1 | false | User of Lab1           |

>  Inherently, admins with higher `org-pos` like U2 in this case will have access to files or directories owned by users with lower `org-pos` like U3 in this case.

Following end-point is called to create user roles -

```
PUT https://[domain]/dls/user/role?admin=&organization-position=
```

Only users with admin privilege can set the role of other users provided the users are from same organization hierarchy. This means, U2 is authorized to set role of U3 as /Org1/Dept2/Lab1 but U1 can not do the same.

`HTTP 409` is returned with proper messages when the admin tries to set user's organization position but either the organization is not set at tenant level or the admin does not have required organization position to set up user's role.



### 10.8. Get User Role

This API will return the role of the users. This API can either be called by admin or non-admin users. For admin users, all other normal users of same or lower organization position are returned. For non-admin users only it's own role is returned. Following URL is accessed to get the users role -

```
GET http://[domain]/dls/user/role
```

The response is a JSON in the following format -

```
[
  {
    "user-name": "OrgAdmin1",
    "org-pos": "Org1",
    "admin-user": "true"
  },
  {
    "user-name": "LabAdmin1",
    "org-pos": "Org1/Lab1",
    "admin-user": "true"
  },
  {
    "user-name": "LabUser1",
    "org-pos": "Org1/Lab1",
    "admin-user": "false"
  },
  {
    "user-name": "user_without_role",
    "admin-user": "false"
  }
]
```



### 10.9. Delete User Role

User role can be deleted by the DLS admins. In the HTTP request parameter, the specific `user-name` is to be sent. Once the user role is deleted using this API, the user is not part of any organizational hierarchy. Hence, the admins of that organization do not have any control on the user. Although, the user will exist in DLS along with all files uploaded by the user, the privilege to access any directory or file for having that role, will be immediately revoked.

```
DELETE http://[domain]/dls/user/role?user-name=[]
```

If successfully deleted, `HTTP 204` is returned.



## 11. Administrative API

In DLS, there are few API which are only accessible by TCUP admin. These APIs are mostly relevant to TCUP service developers. Application developers would not generally have any access to this APIs.

### 11.1. Provision New Tenant

A TCUP tenant can be provisioned in DLS by using following API. 

```
POST https://[domain]/dls/admin/user
```

The payload to be sent in HTTP request body is -

```
{
  "admin-dls-key": "",
  "admin-user-name": "",
  "api-key": "",
  "organization": "",
  "tcup-user": ""
}
```

Here, `organization` and `admin-user-name` are optional attributes in the above JSON. If no `admin-user-name` is sent, the default `dlsadmin` user is created for this tenant. 



### 11.2. Get Tenant

The TCUP admin can list all the provisioned tenants in DLS by using following API -

```
GET https://[domain]/dls/admin/user
```



### 11.3. Delete DLS Admin 

DLS admin can be deleted only by TCUP admin. If this DLS admin has other DLS users, `HTTP 409` is returned.

```
DELETE https://[dimain]/dls/admin/user/{username}
```

If DLS admin is deleted, all files uploaded by the DLS admin are also deleted from HDFS. All catalog information is also deleted for the admin.

Calling the above API will return `HTTP 200` response.  If there is no such username or the user is already deleted `HTTP 404` is returned.

`HTTP 403` is returned in case if this API is called by other users who do not have TCUP admin privilege.



### 11.4. Update Tenant's Organization

The organization of an existing tenant can be updated using this API. 

```
PUT https://[domain]/dls/admin/user/organization?organization=[]&tenant=[]
```

If the organization name is absent in request parameter, the existing organization of the tenant is removed. The existing organization can always be altered provided the users of this tenant do not already have any `organization-position`. If they have, the users' role must be altered before removing tenant's organization.



### 11.5. Set Tenant Storage Limit

TCUP admin can limit the total file storage for a specific tenant by using the following API -

```
PUT https://[domain]/dls/admin/storage?storage-limit=[]&tenant=[]
```

The request parameters contains the `storage-limit` value in bytes and the `tenant` name.

> By default, unlimited storage is allowed for tenant.



### 11.6. Get Tenant Storage Limit

Using the following API, the storage limit set for a tenant can be retrieved along with available and used storage.

```
GET https://[domain]/dls/admin/storage?tenant=[]
```

The response JSON is as follows -

```
{
  "allocated-storage": 1024,
  "available-storage": 512,  
  "used-storage": 512
}
```

**Important Note :** 

When storage limit is set, and the available storage is less than the size of the file to be uploaded, DLS would restrict the upload. Deletion of files, would instantly free up `used-storage`.





## 12. Data Point Management

In some scenario, the data and metadata that are stored in DLS, need to be hierarchically maintained for better classification. Further more, as DLS follows principles for [FAIR](https://www.go-fair.org/fair-principles/), there are concepts of FAIR Data Point

The data point concepts are borrowed from FAIR data principles. At the top level there is a repository. 

### 12.1 Repository

Repository is positioned at the top of the hierarchy. An user of DLS can create one or more repositories.

#### 12.1.1 Create Repository

To create a new repository, following API needs to be called. 

```
POST https://[domain]/dls/datapoint/repository
```

The JSON request body is as below -

```
[
  {
    "dct:identifier": "repo-1",
    "permissions": [
      {
        "users": [
          "string"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:someProperty": "string",
      "foaf:name": "string",
      "dct:audience": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dct:publisher": "string",
    "dct:language": [
      "string"
    ],
    "dct:license": "string",
    "dct:subject": "string",
    "dct:alternative": "string",
    "dct:rights": "string",
    "r3d:institution": "string"
  }
]
```

>  **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The repository identifier should be unique across all tenants in DLS.

Following success reponse is returned along with `HTTP 207` code.

```
[
  {
    "key": "Repository",
    "value": "repo-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 12.1.2 Get Repository

Following API is used to get the repository by using the unique repository identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}
```

Here `{repositoryIdentifier}` is to be replaced with correct value. If the repository idenfier exists, following JSON response is returned.

```
{
  "_links": {
    "catalogs": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1"
    }
  },
  "r3d:Repository": {
    "dls:prop1": "string",
    "dct:languages": "string",
    "dct:rights": "string",
    "dct:hasVersion": "string",
    "dct:alternative": "string",
    "dct:identifier": "repo-1",
    "dct:description": "string",
    "dct:subject": "string",
    "dct:title": "string",
    "dct:publisher": "string",
    "r3d:institution": "string",
    "dct:license": "string"
  }
}
```

The above JSON returns all standard and custom repository metadata as part of `r3d:Repository` object. It also returns the links to all catalogs under this repository for which user has read (`R`) access.



#### 12.1.3 Delete Repository

Following API can be used to delete a repository.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}
```

If the repository `{repositoryIdentifer}` does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 12.2. Catalog

Each repository can have one or more catalogs.

#### 12.2.1 Create Catalog

Following API is used to create a new catalog.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog
```

Here the `{repositortIdentifier}` is to be replaced the repository identifier under which this catalog is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "catalog-1",
    "permissions": [
      {
        "users": [
          "user1"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:prop1": "string",
      "foaf:name": "string",
      "dct:xx": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:publisher": "string",
    "dct:description": "string",
    "dct:languages": [
      "string"
    ],
    "dct:license": "string",
    "dct:rights": "string",
    "foaf:homepage": "string",
    "dct:themeTaxonomy": "string"
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The catalog identifier should be unique across all tenants in DLS.

On successful registration of catalog, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Catalog",
    "value": "repo-1/catalog-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 12.2.2 Get Catalog (Datapoint)

Following API is used to get the catalog by using the unique repository identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}
```

Here `{repositoryIdentifier}`  and `{catalogIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "datasets": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1"
    }
  },
  "dcat:Catalog": {
    "dls:prop1": "string",
    "foaf:name": "string",
    "foaf:homepage": "string",
    "dct:rights": "string",
    "dct:xx": "string",
    "dct:identifier": "cat-1",
    "dcat:themeTaxonomy": "string",
    "dct:license": "string",
    "dct:languages": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dct:title": "string",
    "dct:publisher": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.



#### 12.2.3 Delete Catalog

Following API can be used to delete a catalog.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}
```

If the catalog does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 12.3 Dataset

Each catalog may have one or more datasets.

#### 12.3.1 Create Dataset

Following API is used to create a new dataset.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog/{catalogIdentifier}/dataset
```

Here the `{repositortIdentifier}` and `{catalogIdentifier}` are to be replaced by the repository identifier and catalog identifier under which this dataset is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "dataset-1",
    "permissions": [
      {
        "users": [
          "user1"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:xxx": "string",
      "foaf:yyy": "string",
      "dcat:zzz": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:publisher": "string",
    "dct:description": "string",
    "dct:languages": [
      "string"
    ],
    "dct:license": "string",
    "dct:rights": "string",
    "dcat:theme": [
      "string"
    ],
    "dcat:contactPoint": "string",
    "dcat:keyword": [
      "string"
    ],
    "dcat:landingPage": "string"
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The dataset identifier should be unique across all tenants in DLS.

On successful registration of dataset, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Dataset",
    "value": "repo-1/catalog-1/dataset-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 12.3.2 Get Dataset

Following API is used to get the dataset by using the unique dataset identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}
```

Here `{repositoryIdentifier}` ,  `{catalogIdentifier}` and `{datasetIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "distributions": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1/distribution/dist-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1"
    }
  },
  "dcat:Dataset": {
    "dls:xxx": "string",
    "dcat:landingPage": "string",
    "dct:rights": "string",
    "foaf:yyy": "string",
    "dct:identifier": "dataset-1",
    "dct:license": "string",
    "dcat:zzz": "string",
    "dcat:keywords": "string",
    "dct:languages": "string",
    "dcat:contactPoint": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dcat:theme": "string",
    "dct:title": "string",
    "dct:publisher": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.



#### 12.3.3 Delete Dataset

Following API can be used to delete a dataset.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}&dataset-id={datasetIdentifier}
```

If the dataset does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.

### 12.4 Distribution

Each dataset may have one or mores distribution.

#### 12.4.1 Create Distribution

Following API is used to create a new catalog.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}/distribution
```

Here the `{repositortIdentifier}` is to be replaced the repository identifier under which this catalog is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "dist-1",
    "permissions": [
      {
        "users": [
          "RR2"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:xx": "string"
    },
    "dct:title": "string",
    "dct:license": "string",
    "dct:hasVersion": "string",
    "dct:rights": "string",
    "dct:description": "string",
    "dcat:accessURL": "http://some.external.file",
    "dcat:mediaType": "string",
    "dcat:format": "string",
    "dcat:byteSize": 24410
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The distribution identifier should be unique across all tenants in DLS.

On successful registration of distribution, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Distribution",
    "value": "repo-1/catalog-1/dataset-1/dist-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 12.4.2 Get Distribution

Following API is used to get the distribution by using the unique distribution identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}/distribution
```

Here `{repositoryIdentifier}` ,  `{catalogIdentifier}` and `{datasetIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1/distribution/dist-1"
    }
  },
  "dcat:Distribution": {
    "dcat:mediaType": "string",
    "dcat:format": "string",
    "dls:xx": "string",
    "dct:hasVersion": "string",
    "dct:rights": "string",
    "dct:identifier": "dist-1",
    "dct:description": "string",
    "dct:title": "string",
    "dcat:byteSize": "24410",
    "dct:license": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.

#### 12.4.3 Delete Distribution

Following API can be used to delete a dataset.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}&dataset-id={datasetIdentifier}&distribution-id={distributionIdentifier}
```

If the dataset does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 12.5 Discover Datapoint

To search and filter available datapoints in DLS, following API can be used -

```
GET https://[domain]/dls/datapoint?repo-id=repo-1&catalog-id=cat-1&dataset-id=dataset-1&metadata=as%3D%27as%27&exclude=REPOSITORY&exclude=CATALOG
```

The above API call returns all repositories, catalogs, datasets and distributions in DLS, provided user has read (`R`) access on that specific datapoint. Following JSON response is returned with `HTTP 200` code.

```
{
  "repository-list": [
    {
      "links": [
        {
          "rel": "catalogs",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1"
        }
      ],
      "r3d:Repository": {
        "dls:prop1": "string",
        "dct:languages": "string",
        "dct:rights": "string",
        "dct:hasVersion": "string",
        "dct:alternative": "string",
        "dct:identifier": "repo-1",
        "dct:description": "string",
        "dct:subject": "string",
        "dct:title": "string",
        "dct:publisher": "string",
        "r3d:institution": "string",
        "dct:license": "string"
      }
    }
  ],
  "catalog-list": [
    {
      "links": [
        {
          "rel": "datasets",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1"
        }
      ],
      "dcat:Catalog": {
        "dls:prop1": "string",
        "foaf:name": "string",
        "foaf:homepage": "string",
        "dct:rights": "string",
        "dct:xx": "string",
        "dct:identifier": "cat-1",
        "dcat:themeTaxonomy": "string",
        "dct:license": "string",
        "dct:languages": "string",
        "dct:hasVersion": "string",
        "dct:description": "string",
        "dct:title": "string",
        "dct:publisher": "string"
      }
    }
  ],
  "dataset-list": [
    {
      "links": [
        {
          "rel": "distributions",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1/distribution/dist-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1"
        }
      ],
      "dcat:Dataset": {
        "dls:xxx": "string",
        "dcat:landingPage": "string",
        "dct:rights": "string",
        "foaf:yyy": "string",
        "dct:identifier": "dataset-1",
        "dct:license": "string",
        "dcat:zzz": "string",
        "dcat:keywords": "string",
        "dct:languages": "string",
        "dcat:contactPoint": "string",
        "dct:hasVersion": "string",
        "dct:description": "string",
        "dcat:theme": "string",
        "dct:title": "string",
        "dct:publisher": "string"
      }
    }
  ],
  "distribution-list": [
    {
      "links": [
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1/distribution/dist-1"
        }
      ],
      "dcat:Distribution": {
        "dcat:mediaType": "string",
        "dcat:format": "string",
        "dls:xx": "string",
        "dct:hasVersion": "string",
        "dct:rights": "string",
        "dct:identifier": "dist-1",
        "dct:description": "string",
        "dct:title": "string",
        "dcat:byteSize": "24410",
        "dct:license": "string"
      }
    }
  ]
}
```

The above response can be filtered using the following URL paramters sent during API call.

| parameter name    | description                                                  |
| ----------------- | ------------------------------------------------------------ |
| `repo-id`         | Only catalogs, datasets and distributions under this repository are returned. |
| `catalog-id`      | Only datasets and distributions under this catalog are returned. |
| `dataset-id`      | Only distributions under this dataset are returned.          |
| `metadata`        | Multiple metadata can be provided in form of `key='value'`. Only matching records are returned. |
| exclude           | One or more values from the below enum can be set to exclude them from output - `REPOSITORY`, `CATALOG`, `DATASET`, `DISTRIBUTION` and `NONE` (default). |
| include-directory | Boolean `true` value to mention if the directory and files created in DLS should be automatically mapped to datapoint and included in output. Default is `false`. |



### 12.6 Datapoint Provenance

Provenance is an operation on datapoint executed by a user through an API call. By default, all operation on these datapoints, would automatically recorded as provenance. 

> **Note**: There is no API to delete a provenance record.

#### 12.6.1 Get Provenance

The get provenance API helps to retrieve all provenance records for any specific repository. Following is the API -

```
GET https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}
```

If there is any records in the system, following response is returned.

```
[
  {
    "provenance": {
      "prov:atTime": "2021-04-07 18:52:25.844905",
      "prov:value": "repo-1",
      "prov:entity": "REPOSITORY",
      "prov:wasGeneratedBy": "RR1",
      "prov:event": "CREATED"
    },
    "links": [
      {
        "rel": "entity",
        "href": "https://[domain]/dls/datapoint/repository/repo-1"
      }
    ]
  }
]
```



Following the list of default attributes of provenance that DLS automatically generates :

| Attributes of Provenance | Description                                                  |
| ------------------------ | ------------------------------------------------------------ |
| `prov:entity`            | Datapoint types. E.g - REPOSITORY                            |
| `prov:value`             | The URI of datapoint identifiers which uniquely indexes the datapoint. |
| `prov:wasGeneratedBy`    | User who performed that operation                            |
| `prov:event`             | Type of operation. E.g - CREATED, UPDATED, DELETED, FETCHED  |
| `prov:atTime`            | Time when the operation was done.                            |

> Note : There can be custom provenance attributtes inserted by users using `POST` API mentioned below.



#### 12.6.2 Create Provenance

User can create additional provenance records for a particular datapoint. The attributes need to be borrowed from prov ontology. 

To add provenance for any repository -

```
PUT https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}
```

To add provenance for catalog, dataset or distribution -

```
POST https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}?catalog-id={catalogIdentifier}&dataset-id={datasetIdentifier}&distribution-id={distributionIdentifier}
```

Following the JSON payload that needs to be sent in request body -

```
{
  "custom": {
    "prov:additionalProp1": "string",
    "prov:additionalProp2": "string",
    "prov:additionalProp3": "string"
  },
  "prov:wasGeneratedBy": "string",
  "prov:atTime": "02-FEB-2020 20:02:20",
  "prov:activity": "string",
  "prov:entity": "string",
  "prov:value": "string"
}
```

The `custom` attributes contains a map of additional provenance atributes which user can borrow from provenance ontology. `HTTP 205` is returned on successful creation of the record. 

If any of the datapoint identifiers does not exist, `HTTP 404` is returned. If the custom attribute keys are not part of `prov` prefix, `HTTP 409` with error message is returned.



### 12.7 Datapoint Metadata

The metadata already registered for any datapoint, can be updated. An existing metadata of any datapoint can be deleted as well.

#### 12.7.1 Update Metadata

To update an existing metadata of any datapoint, following API can be used.

```
PUT https://[domain]/dls/datapoint/metadata/repository/{repositoryIdentifier}
```

The URL parameters can be added to delete a specific catalog, dataset or distribution - `catalog-id`, `dataset-id`, `distribution-id`.

The JSON payload contains one or more custom metadata which gets added to the set of existing metadata.

```
{
  "dls:additionalProp1": "string",
  "foaf:additionalProp2": "string",
  "dcat:additionalProp3": "string"
}
```

If any of the metadata key is not in acceptable format, i.e the prefix used in the key name is not already known or registered in DLS, a `HTTP 409` with error message is returned. If all metadata is correct and acceptable, then `HTTP 207` is returned with JSON response payload, as below.

```
[
  {
    "key": "key",
    "value": "dls:additionalProp1",
    "messages": [
      "updated"
    ],
    "code": 205
  }
]
```



> **Important**
>
> If the metadata key already exists for this datapoint, then the value is updated. Otherwise, a new metadata is added to the existing metadata set. 



#### 12.7.2 Delete Metadata

To delete a metadata of any datapoint, use the below API

```
DELETE https://[domain]/dls/datapoint/metadata/repository/{repoIdentifier}?key={metadataKey}
```

If the above call is successful, `HTTP 204` is returned. It deletes the metadata identified by key name of this particular repository.

To delete metadata of catalog, dataset or distribution under this repository, following URL parameter can be used to identify the specific datapoint.

```
https://[domain]/dls/datapoint/metadata/repository/{repoIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]&key=[]
```

If the metadata is already deleted or could not be found, `HTTP 404` is returned.

### 12.8 Datapoint Permission

Permission once created for any datapoint can be updated. Permission can also be revoked. The retrieval, updation and deletion of permission of any datapoint is only accessible by the **datapoint creator (owner)**. For other users than the creator, `HTTP 403` is thrown. 

#### 12.8.1 Retrieve Permission

To retrieve the permission set for an existing datapoint, below API is used

```
GET https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

If permission exists following response is throws, otherwise `HTTP 404` is returned.

```json
[
  {
    "users": [
      "user1"
    ],
    "action": "RWD"
  }
]
```



#### 12.8.2 Update Permission

Permission can be added to an existing datapoint by calling the following API -

```
https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

> Here `catalog-id`, `dataset-id`, `distribution-id` are optional and required to identify specific datapoint inside the repository.

The following JSON payload is sent in HTTP request body-

```
[
  {
    "users": [
      ""
    ],
    "action": "RWD"
  }
]
```

Following table provides an example of the action string set for a repository.

| `Permission` | `Description`                                                |
| :----------- | :----------------------------------------------------------- |
| `R`          | User can view the repository metadata and catalog links      |
| `W`          | User can create catalog in this repository and change repository metadata |
| `D`          | User can delete this repository                              |

If successfully updated, `HTTP 205` is returned. If the username is not found, `HTTP 409` with proper message is thrown.



#### 12.8.3 Delete Permission

Using this API, all permissions already provided for a datapoint can be removed for all users. 

```
DELETE https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

If deletion is successful, `HTTP 204` is returned.



## 13. Appendix

### 13.1. List of Input Validation 

Following table shows the input validation effective on the various fields passed in the API.

Note : Word characters are alpha-numeric and `_`

Note : Special characters for Timestamp are `:`, '-' and `.`



| Input Field             | Allowed Characters (Example Values)                          | Length             |
| ----------------------- | ------------------------------------------------------------ | ------------------ |
| `organization`          | word and timestamp characters and single space between words (`TCS`, `TATA Consultancy Service`, `52 North`, `www.tcs.com`, ) at least one character | Min = 3, Max = 100 |
| user name               | user names with word characters, `.` and valid email Id      | Max = 50           |
| `organization-position` | `organization` followed by `/` and a name of position (word characters) | Max = 500          |
| filename                | White-space is not allowed. Case in-sensitive.               | Max=150            |
| savepoint               | Word and timestamp characters, numeric-only name is not allowed | Max=50             |
| metadata.key            | Word character                                               | Max=150            |
| metadata.type           | Either `TEXT` or `NUMERIC`                                   |                    |
| action                  | Combination of `R`, `W`, `D`. Case in-sensitive.             | Max=3              |
| enforcement             | Either of `STRICT` or `STANDARD`                             |                    |
| directory               | Word characters and `-`. Prepend `/` in each directory and sub-directory |                    |

> Case-sensitive attributes can not have same value in DLS with different cases, e.g - metadata name in schema `key1`, Key1` and `KEY1` are considered same.

### 13.2. Data Flow Diagram

```mermaid
graph TB
A(Create Tenant) -->B(Create User)
    B --> C(Upload File)
    B --> D(Create Directory)
    D --> E(Create Permission)
    C -->F(Link Files)
    E --> C
    C --> G(Share File)
    A --> H(Create Schema)
    H --> B
    D --> I(Create Directory Rule)
    I --> C
    B --> J(Create User Role)
    J --> D
    J --> C

```


### 13.3. User Management

```mermaid
  sequenceDiagram
    TCUP Admin->>DLS: create tenant
    TCUP Admin->>DLS: update organization of tenant
    DLS Admin->> DLS: create DLS users
    DLS Admin->> DLS: update user's role
    DLS User ->> DLS: Upload file

```

### 13.4. File Upload Process

```mermaid
  sequenceDiagram
    Client->>DLS REST Server: POST /file
    DLS REST Server->>PostGres: Save metadata    
    DLS REST Server->>NFS Stage: Temporarily Store File    
    DLS REST Server -->> Client : HTTP 202 Accepted
    alt HDFS enabled
    NFS Stage -->> HDFS : Sync File Store
    
    end

```


### 13.5. File Download Process

```mermaid
  sequenceDiagram
    Client->>DLS REST Server: GET /file?uri=
    DLS REST Server->>PostGres: Find file detail
    alt HDFS disabled
    NFS Stage -->> Client : File    
    else HDFS enabled
    DLS REST Server -->> Client : HTTP 302 Redirect
    
    Client->>Hadoop: redirected to WebHDFS File Download URL  
    
    Hadoop -->> Client : File
    end

```

### 13.6 Data Point Entities

```mermaid
classDiagram
      DataPoint <|-- Repository
      DataPoint <|-- Catalog
      DataPoint <|-- Dataset
      DataPoint <|-- Distribution
      DataPoint "1" --> "*"  Permission
      DataPoint "1" --> "*"  Provenance
      DataPoint "1" --> "*"  CustomMetadata
      Repository "1" --> "*" Catalog
      Catalog "1" --> "*" Dataset
      Dataset "1" --> "*" Distribution
      DataPoint : +String identifier
      DataPoint : +Permission[] permission
      DataPoint : +CustomMetadata[] custom
      DataPoint : +Provenance provenance
      DataPoint: +create()
      DataPoint: +get()
      DataPoint: +updateMetadata()
      DataPoint: +addPermission()      
      DataPoint : +addProvenance()
      DataPoint: +delete()
      class Repository{
          +String dct_title
+String dct_hasVersion
+String dct_description
+String dct_publisher
+String [] dct_language 
+String dct_license
+String dct_subject
+String dct_alternative
+String dct_rights
+String r3d_institution
+URI [] listCatalog()
      }
      class Catalog{
          +String dct_title
+String dct_hasVersion
+String dct_publisher
+String dct_description
+String [] dct_languages
+String dct_license
+String dct_rights
+String foaf_homepage
+String dct_themeTaxonomy
+URI [] listDataset()
      }
      class Dataset{
          +String dct_title
+String dct_hasVersion
+String dct_publisher
+String dct_description
+String[] dct_languages
+String dct_license
+String dct_rights
+String[] dcat_theme
+String dcat_contactPoint
+String[] dcat_keyword
+String dcat_landingPage
+URI [] listDistribution()
      }
      
      class Distribution {
      	+String dct_title
        +String dct_license
        +String dct_hasVersion
        +String dct_rights
        +String dct_description
        +String dcat_accessURL
        +String dcat_mediaType
        +String dcat_format
        +String dcat_byteSize
        +download()
      }
      
      class Permission {
       +String user
       +String action
       +update()
       +delete()
      }
      class Provenance {
       +String prov_wasGeneratedBy
        +Date prov_atTime
        +String prov_activity
        +String prov_entity
        +String prov_value
        +CustomMetadata[] custom
        +update()
        +delete()
      }
      class CustomMetadata {
      +String key
      +String value
      }
```

### 13.7 Data Point Entities (High Level)


```mermaid
erDiagram
	TENANT ||--|{ USER : has
	USER ||--|{ REPOSITORY : creates_reads_updates_deletes
	USER ||--|{ PERMISSION : requires
    REPOSITORY ||--o{ CATALOG : contains
    CATALOG ||--o{ DATASET : contains
    DATASET ||--o{ DISTRIBUTION : contains
    REPOSITORY ||--|{PROVENANCE : has    
```