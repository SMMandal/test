---
description: ''
sidebar: 'docs'
prev: '/docs/sos/'
next: '/docs/task/'
---



# Data Lake 
> `version 12.0 API Guide`
> 
> `DOCUMENT VERSION 2.1 10-07-2023` 



## 1. Introduction

### 1.1. What is Data Lake Service?
Data Lake Service (DLS) is a set of REST end-points to store and retrieve files and associated metadata in a multi-tenant cloud environment. It provides a set of API for file metadata management. Data Lake can be utilized to store and retrive various kinds of files like data files, program files, log files, binary files, analytics output files, device firmware packages etc. Depending upon the use cases the clients of DLS can be data scientists, edge applications or other TCUP services as well. DLS also provides number of file catalouging API to find files based on various filter conditions.


Following section describes various APIs of DLS. These are categorized as 

  - Catalog APIs, 
  - Metadata Schema Management APIs, 
  - File Management APIs, 
  - File Linking and Sharing APIs 
  - Directory Management APIs, 
  - File lock APIs
  - User and Role Management API. 
  - Datapoint Management APIs

The administrative APIs are meant for internal users of DLS and TCUP service depelopers.

### 1.2. Response Codes

For all API calls, the HTTP request header called `x-api-key` must be sent by clients with a correct public key of the TCUP tenant or user. Following table is an approximate summary of HTTP response codes along with their probable cause of occurances in DLS :

| HTTP Code | Reason                                                                             |
|-----------|------------------------------------------------------------------------------------|
| 200       | Success of any GET call, e.g - data found in Get Catalog API                       |
| 201       | Success of any POST call with one or more entities in request, e.g - Create User   |
| 202       | Success of POST call which is not immediately complete, e.g - Upload File          |
| 204       | Success of DELETE call with one or more entities                                   |
| 205       | Success of UPDATE call with one or more entities                                   |
| 207       | Response of call with multiple entities in request having individual response code |
| 400       | Error due to invalid input JSON or URL parameters                                  |
| 401       | Error due to invalid API Key : Unauthentic                                         |
| 403       | Error due to unauthorized call to any API or passing invalid DLS key               |
| 404       | Error due to data not found in GET calls                                           |
| 409       | Error due to inconsistent data in backend or data integrity error                  |

The `HTTP 409` may be thrown by DLS in various inconsistent situations like duplicate data, already existing data etc. For this reason, `HTTP 409`, in most scenario, will also contain a message in HTTP response body.



**Response Message**

The GET calls will return a JSON payload in HTTP response. In some scenario, the GET call returns array of text in the response whenever the response is not a in form of complex object. The POST/PUT calls will contain a simple text message when there was single entity in request. It will return a JSON whenever there are more than one entities in request.



### 1.3. Input Validation

The JSON payload sent in request body of POST or PUT calls are validated by DLS before processing further. Any error in validation, would return `HTTP 400` as a whole, even if one or many record of the JSON array are correct. 

**Response JSON Structure of Input Validation Errors (HTTP 400) returned on POST and PUT**

Following JSON response is returned along with `HTTP 400` status code, in cases where there is input validation errors on the request JSON payload.

```
[
  {
    "key": "<offending key name of the JSON>",
    "value": "<offending value as mentioned in JSON>",
    "code" : 201,
    "message": "<detail error message>"
  }
]
```

** Only message is mandatory in above JSON.*



**Constraints of Input Validation**

- Missing mandatory attributes of JSON
- Length and pattern of the attribute value
- Duplicate records in array
- Extra attribute is ignored

In case, the input JSON is not parsable or the attribute value does not conform to intended data type,  `HTTP 400` with message `Invalid input format` is returned.

## 2. Data Lake Catalog

Data Lake Catalog is the index of all uploaded files. A catalog contain name of each file, file meta-data, linked files, shared files and file transfer status.

### 2.1. Search Files and Metadata 

This api helps to **Get and Filter DLS Catalog**. A catalog is a data set which lists the available files in data lake and the unique path to access the files. Each DLS user have their own catalog and can view its own uploaded files in catalog. DLS user can not view other DLS users' catalog unless a file has been shared to.

The API to get the catalog details is as below -

```
GET https://[domain]/dls/catalog
```



**Filter Parameters**

| Parameter Name | Description                                                                                                                                                                |
|----------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| text           | Search files using free-text search. This search is done on file name, savepoint name, metadata name and value.                                                            |
| time           | A time or time-range in this format `dd-MMM-yyyy HH:mm:ss Z`                                                                                                               |
| size           | Filter files based on file size, e.g `>5.2KB` or `=1.7MB`                                                                                                                  |
| external       | By default all files are fetched. A boolean value `true` filters only external files and `false` fetches only files uploaded to DLS                                        |
| transferred    | To list all files which has failed to be uploaded set the value to `false`.                                                                                                |
| bundled        | To fetch the bundles only, add `bundled=true`. By default, both files and bundles are returned. The catalog response JSON also contains the `bundle` descriptor attribute. |
| deleted        | Set `true` to show deleted files. By default, only undeleted files are shown.                                                                                              |
| savepoint      | Search files by savepoint names. It supports wildcard character `*`.                                                                                                       |
| ownFile        | Filters and shows files which has been shared to the user by other DLS users by setting this parameter `false`                                                             |
| metadata       | List of comma-separated metadata in form of `K='V'`. It also accepts key name `K` or value `'V'` separately. E.g `K1='V1',K2='V2',K3,V4`                                   |
| uri            | Full URI or part of it                                                                                                                                                     |
| directory      | Search files by their source directory location.                                                                                                                           |
| filename       | Search by filename. Wild-card is supported.                                                                                                                                |
| sort           | Allowed values are `createdOn`, `fileName`, `size`                                                                                                                         |
| pageNo         | By default 500 files are fetched. To fetch 501 to 1000 files mention `pageNo` value as 2 and so on                                                                         |
| locked         | Default is `false`. To filter only locked files, set value to `true`.                                                                                                      |

**Wild-card Support for Query**

 As of TCUP release 11, wild-card is supported in save-point, metadata keys, metadata values and file URI search parameters. For example, metadata can be searched as `version='1.*'`. Savepoint can be searched as `/home/user/Documents/*`. 



**JSON response :**

	{
	  "count": 1,
	  "pageNumber": 1,
	  "result": [
	    {
	     "bundle": [
	        {
	          "directory": "string",
	          "filename": "string",
	          "metadata": [
	            "string"
	          ],
	          "size-bytes": 0
	        }
	      ],
	      "bundled": true,
	      "created-on": "dd-MMM-yyyy HH:mm:ss z",
	      "deleted": false,	      
	      "deleted-on": "dd-MMM-yyyy HH:mm:ss z",
	      "external-to-dls": false,
	      "file-uri": "[file-uri]",     
	      "meta-data": "comma-separated KV pair",
	      "own-file": true,
	      "shared-to": "[comma-separated DLS users]",
	      "shared-by": "if not own-file, owner of the file",
	      "savepoint": "savepoint_name",
	      "size-bytes": 1024,
	      "transfer-success": true,
	      "locked": true,
	      "hidden": true
	    }
	  ]
	}

***Notes*** : 
Timezone as shown in `created-on` time is `UTC`.
Size of the uploaded files as shown in `size-bytes` is the storage occupied in server.

| JSON Key         | Description                                                                                                                                 |
|------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| bundled          | Whether it is a file or bundle, `true` means it is a bundle                                                                                 |
| bundle           | If a bundle, the descriptor JSON                                                                                                            |
| created-on       | Date of file upload in dd-MMM-yyyy HH:mm:ss z format                                                                                        |
| deleted-on       | Date of file deletion in dd-MMM-yyyy HH:mm:ss z format, if it was deleted                                                                   |
| deleted          | `True`, if the file has been deleted                                                                                                        |
| external-to-dls  | `True`, if the file is stored outside DLS                                                                                                   |
| file-uri         | Unique file URI, use it to download                                                                                                         |
| ~~links-from~~   | `deprecated` Relation to other files, in form of `relation-name=file_URI`                                                                   |
| ~~links-to~~     | `deprecated` Relation to other files, in form of `relation-name=file_URI`                                                                   |
| meta-data        | comma-separated KV pair                                                                                                                     |
| own-file         | Boolean flag to determine whether file is uploaded by user or shared by others                                                              |
| shared-to        | Comma-separated list of DLS user names to whom this file has been shared to                                                                 |
| shared-by        | If it is not `own-file`, the name of the user who shared the file                                                                           |
| size-bytes       | Size of the uploaded file in bytes                                                                                                          |
| savepoint        | Save-point name                                                                                                                             |
| transfer-success | `False`, if the file was successfully uploaded to DLS but could not be stored on Distributed File System and is not available for download. |
| locked           | `True`, if the file is locked.                                                                                                              |
| hidden           | `True`, if the file is hidden to other users.                                                                                               |

If there is no file in catalog, `HTTP 404` status code is returned

> If any file metadata was declared private, catalog shows `[private]` keyword after the metadata key name.
> 
> If the private metadata was created by other users, the value is then masked. Example : `key1[private]=***`
>
> Important: Files are not searchable using **private** metadata key name 

***Catalog Text Search Examples***
The text search option of Catalog is applicable on all meta-data keys, values, usernames, file names and savepoint names available in DLS.
Text search is currently not applicable on file relationship names or file content.

 - use `,` or `|` to search either one of given criteria
 - use `!` as NOT operator 
 - wrap a text with `" "` to find exact match
 - white space will be treated as AND operator


- To find all CSV files, use `text=.csv` 
- To find all files other than CSV, use `text=!.csv`
- To find all CSV and PDF files, use `text=.csv,.pdf`

*Text search query parameters are **not** case-sensitive*



### 2.2. Get Directory wise catalog 

This API returns list of files which are sorted hierarchically as per the source directory structure. The response contains similar data as the above "get catalog" API but the response JSON is optimized for UI to render directory and files structure. In contrast to the above "get catalog" API, in case where directory contains no file, simple directory hierarchy is returned instead of `HTTP 404`. If there is no source directory mentioned during file upload, those files are shown under root directory named `/`.

There are various filter conditions that can be mentioned as URL parameters. To fetch all records, call this below API - 

```
GET https://[domain]/dls/catalog/directory
```

The response JSON is a hierarchy of directories and files in following format -

```
{
  "created-on": "dd-MMM-yyyy HH:mm:ss z",
  "directories": [
    ...
  ],
  "files": [
    {
      ...
      "type": "file"
    }
  ],
  "name": "string",
  "path": "string",
  "permitted-action": "string",
  "type": "directory"
}
```

The above directory JSON is hierarchical in the sense that it constructively repeats inside the attribute `directories` whenever a directory has a sub-directory and so on. The attribute `files` would contain all files which have same source directory. Below are the description of other attributes -


| JSON Key         | Description                                     |
|------------------|-------------------------------------------------|
| created-on       | Whether it is a file or bundle                  |
| name             | Name of the directory                           |
| path             | Full path of the directory                      |
| permitted-action | Read (`R`), write (`W`) or delete (`D`) actions |
| type             | Either `directory` or `file`                    |



The URL parameters that can be passed as filter condition are almost same as above "get catalog" API. Only  `pageNo` and `sort` parameters do not work with this API.



### 2.3. Get File Lineage

File lineage is all the operations on a specific file over a period of time. A file can be created, overwritten, appended with additional data, archived to another file or finally be deleted. Lineage shows all these details.

```
GET https://[domain]/dls/lineage?file-uri=[fileUri]
```

The response is a chronological list of operations along with file's size and metadata. In case of archive, the archive URI is also returned.

```
[{
    "operation": "ARCHIVE",
    "archive-uri": "something",
    "time": "08-Aug-2019 07:54:40 UTC",
    "size": 146,
    "meta-data": "ver=O2"
}]
```



### 2.4. Get All Ad-hoc Relation Names

Irrespective of tenants, all relation names created in DLS by all users, is listed using the following API -

```
GET https://[domain]/dls/relation
```

It returns newline separated text values (NSV).

In case there is no relation name created in DLS, `HTTP 404` is returned.

 

### 2.5. Get the List of Key Names and Values

This API lists all the metadata key names and values created by the DLS user. It returns a list of text specific to the DLS user.

```
GET https://[domain]/dls/keylist
```
Input parameters -

| name               | description                                                                                                 |
|--------------------|-------------------------------------------------------------------------------------------------------------|
| `withValue`        | Boolean value, default is `false`. To return both key and value in response, set `true`.                    |
| `includeDirectory` | Boolean value, default is `false`. If set `true`, returns metadata of directory which the user has created. |
| `name`             | Provide a name to fetch all matching metadata with this name. It supports wildcard, use `*`.                |
| `value`            | Provide a value to fetch all matching metadata with this value. It supports wildcard, use `*`.              |


> **Note** : `name` and `value` search is **not** case-sensitive

**Response** : Code 200

_Payload :_

`[ "metadata_key_name"]`

> If `withValue` is `true` then 
`[ "metadata_key_name=metadata_key_value"]`



### 2.6. Get the List of File URIs

This API lists the file URIs for all files which are not deleted and successfully transfered to backend storage. It returns a list of text specific to the DLS user.

```
GET https://[domain]/dls/filelist
```

**Response** : Code 200
_Payload :_
`[ "list/of/file/uri"]`



### 2.7. Get Organization Hierarchy

If the organization is set for the tenant and the respective users are having their organizational positions set, this API will list down the complete organizational tree along with the admins and users at different organizational positions.

```
GET https://[domain]/dls/organization
```

**Response** : Code 200
_Payload :_

```
{
  "position": "tcs",
  "admins": [
    "admin1"
  ],
  "organization": [
    {
      "position": "kolkata",
      "users": [
        "user1"
      ],
      "admins": [
        "admin2"
      ]
    }
  ]
}
```

> The above JSON can be read as follows - 
>
> *"In `tcs` organization, the `admin1` is the organization-level admin. There is a `tcs/kolkata` position which has an admin named `admin2` and user named `user1`"*

In the above JSON, `organization`  may **recursively** appear inside `organization`  along with other attributes like `position` (organization-position name), `users` and `admins` (respective to that organization-position). 

`users` and `admins` are lists which may not have values in some cases.



### 2.8. Get DLS Statistics

This API returns statistics of DLS user's account in terms of various parameters.

```
GET https://[domain]/dls/statistics
```

**Response**: Code 200
_Payload:_

```
{
  "first-uploaded": "dd-MMM-yyyy HH:mm:ss z",
  "last-uploaded": "dd-MMM-yyyy HH:mm:ss z",
  "total-bundled": 0,
  "total-count": 0,
  "total-deleted": 0,
  "total-external": 0,
  "total-failed": 0,
  "total-shared": 0,
  "total-volume": "string"
}
```

**Description of JSON**

| Field Name     | Description                                                |
|----------------|------------------------------------------------------------|
| total-volume   | Total volume of files stored in DLS for that user          |
| total-count    | Total number of files uploaded (including deleted files)   |
| total-shared   | Total number of files shared by other DLS users            |
| total-failed   | Total number of files which were not successfully uploaded |
| total-external | Total number of external files                             |
| total-deleted  | Total number of files deleted                              |
| total-bundled  | Total bundles uploaded                                     |
| last-uploaded  | Timestamp of the most recent file uploaded                 |
| first-uploaded | Timestamp of first uploaded file                           |



### 2.9. Get Catalog Explorer

Retrieve the cumulative records for files and directories in single API call. 
The files which have been successfully uploaded (`transfer-success = true`)
and not deleted would be visible.
```
GET https://[domain]/dls/catalog/explorer
```

Input parameters to the above API call -

| name        | description                                                                                                                                                                                                                                                     |
|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `name`      | Name of file or directory to search. Multiple names can be provided. Name accepts wildcard (`*`).                                                                                                                                                               |
| `path`      | File URI or directory path. Multiple paths can be provided. Wildcard is **not** allowed.                                                                                                                                                                        |
| `parent`    | Accepts a directory path and returns immediate files and sub-directories.                                                                                                                                                                                       |
| `savepoint` | Search files based on a list of savepoint names. Name is NOT case-sensitive and can contain wildcard (`*`).                                                                                                                                                     |
| `user`      | User name who has created directories and files. Accepts multiple usernames.                                                                                                                                                                                    |
| `size`      | Size of file, format is `<1MB` or `>=500KB`. Supported operators - `>`, `<`, `>=`, `<=`, `=`, `!=`. Size unit is up to petabyte - `pb`                                                                                                                          |
| `fileCount` | Search by count of immediate files of a directory. Example `=0` returns all empty directories, `>0` returns directories with files. As files do not have this property, providing only this query parameter would result in only directories.                   |
| `time`      | Provide maximum two timestamp values to represent a time range. Example timestamp format - `02-May-2023 00:48:02 +00:00`. If provided single timestamp, then all files and directories created on that timestamp is returned.                                   |
| `nameRegex` | Regular expression on name parameter.                                                                                                                                                                                                                           |
| `metadata`  | See below description for various metadata query.                                                                                                                                                                                                               |
| `and`       | Selecting a query param name from this `and` list, would allow that param to be `and`ed with the previous query parameter. The sequence of parameter names is as below - `name`, `path`, `parent`, `user`, `size`, `fileCount`, `time`, `nameRegex`, `metadata` |
| `sort`      | Data can be sorted based on `createdOn` (time), `createdBy` (user), `name` or `size`                                                                                                                                                                            |
| `order`     | Sorting order, either `asc` (default ascending order)or `desc` (descending order)                                                                                                                                                                               |
| `fetch`     | Searched records can be fetched as `onlyFile`, `onlyDirectory`, `fileFirst` or `directoryFirst`                                                                                                                                                                 |
| `pageNo`    | Integer positive number, default is `1` (first page).                                                                                                                                                                                                           |
| `pageSize`  | Integer positive number, default is `100` records per page.                                                                                                                                                                                                     |

#### Metadata search :

* Search for metadata key as `K`
* Search for metadata value as `'V'`
* Search specific metadata as `K='V'`
* Search multiple metadata keys matching any of them as `K1,K2`
* Search multiple metadata values matching any of them as `'V1', 'V2'` 
* Search multiple specific metadata matching any of them as `K1='V1', K2='V2'`
* Search multiple metadata keys matching all of them as `K1 & K2`
* Search multiple metadata values matching all of them as `'V1' & 'V2'`
* Search multiple specific metadata matching all of them as `K1='V1' & K2='V2'`
* Search with complex combination `K1='V1' & 'V2', K3`
* Note cond1 & cond2 , cond3 is evaluated as (cond1 AND cond2) OR cond3
* Use wildcard for metadata key or value using `K*`, `'V*'`
* There are certain character restrictions on metadata value (`&` `!` `,` `'` `"` `=`). Use wildcard search if certain characters are not allowed in value.


### Response
HTTP OK - 200
```json
{
  "current-page": 1,
  "total-page": 1,
  "record-count": 2,
  "directories": [
    {
      "name": "d2",
      "path": "/d1/d2",
      "created-on": "12-Jun-2023 04:59:00 UTC",
      "created-by": "admin1",
      "parent": "/d1",
      "metadata": [
        {
          "name": "dkey2",
          "value": "val2",
          "updated-by": "admin1"
        }
      ],
      "file-count": 1
    }
  ],
  "files": [
    {
      "name": "dls12.sql",
      "path": "tenantA/admin1/1390/dls12.sql",
      "created-on": "11-Jun-2023 06:09:29 UTC",
      "created-by": "admin1",
      "parent": "/d1",
      "metadata": [
        {
          "name": "key1",
          "value": "val1",
          "updated-by": "admin1"
        }
      ],
      "size-bytes": 22237
    }
  ]
}

```
> For file metadata, if the metadata was declared private, metadata value is masked in response for all other users apart from the metadata creator.






### 2.10. Get Catalog File Count

Returns the permissible directories in a tree structure and optionally, count of files in each directory.

```
GET https://[domain]/dls/catalog/file-count
```

Input parameters to the above API call -

| name            | description                                                                                                                       |
|-----------------|-----------------------------------------------------------------------------------------------------------------------------------|
| `directory`     | Name of parent directory whose sub-tree needs to be fetched. By default, root directory is chosen.                                |
| `immediateOnly` | Boolean flag to return only immediate nodes of the tree. By default, entire tree is returned.                                     |


### Response
HTTP OK - 200

Response with file count. 

```json
{
  "path": "/",
  "name": "/",
  "type": "directory",
  "directories": [
    {
      "path": "/ESL",
      "name": "ESL",
      "type": "directory",
      "created-on": "08-Jun-2023 08:16:41 UTC",
      "permitted-action": "RWDABC"
    },
    {
      "path": "/Kingston",
      "name": "Kingston",
      "type": "directory",
      "created-on": "08-Jun-2023 08:32:24 UTC",
      "permitted-action": "RWDABC"
    }
  ]
}
```


## 3. Metadata Schema

From TCUP R11, DLS supports defining metadata schema. Schema can be managed by **administrators** like the tenant admin or any other admins. Once metadata schema is defined, all metadata added in DLS by other users during either file upload process or directory rule creation process, must adhere to the metadata schema. Metadata schema is tenant-speciffic. 

### 3.1. Create Metadata Schema

Metadata schema contains two parts. First one is a tenant speciffic `config` which is applicable for all metadata definition. Second part is a set of `metadata`, which provides a list of valid metadata to be used by user. Either the `config` or `metadata` or both can be added during metadata creation.

```
POST https://[domain]/dls/schema
```

The payload JSON looks like -

```
{
  "config": {
    "allow-adhoc": true,
    "max-key-len": 30,
    "max-value-len": 50,    
    "max-metadata-per-file": 20
  },
  "metadata": [
    {
      "description": "expected network bandwidth while uploading a file",
      "name": "bandwidth",
      "type": "TEXT"
    }
  ]
}
```



If the given JSON is valid and accepted by DLS for processing, a response JSON in following format can be expected along with a HTTP status code `207` (i.e multi-status).

```
[
  {
    "key": "config",
    "messages": [
      "updated"
    ],
    "code": 205
  },
  {
    "key": "name",
    "value": "bandwidth",
    "messages": [
      "created"
    ],
    "code": 201
  }
]
```

The return codes mentioned in the JSON signifies `205` - config updated, `201` - new metadata created, 409 - duplicate metadata name.

**Important Note:** In the above example, the schema JSON has both `config` and `metadata` array. In other cases, if only `config` or `metadata` needs to be added, either of them can be present in JSON. Even only a few attributes of `config` can also be present, e.g - it may contain only `allow-adhoc`.

If the JSON is not valid a HTTP `400` is sent with proper messages like -

```
- Metadata name can not be blank
- Metadata type can not be blank
- "max-metadata-per-file" value should be between 0 and 255
- "max-key-len" value should be between 0 and 255
- "max-value-len" value should be between 0 and 255
- Metadata name can not be more than 255 characters long
```


Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

   **Notes:**       

    1. ‘ls-user’ is the username of TCUP user
    2. ‘dls-key’ is the TCUP user’s private API key
    3. Only TEXT/NUMERIC type is supported



### 3.2. Get Schema


Get the details of schema, optionally provide the filter fields to fetch all the matching meta-data details

```
GET https://[domain]/dls/schema?names=[names]&type=[type]
```

The response is the details of metadata schema shown below. If there is no schema available, `HTTP 404` is returned. Even if there is no matching metadata as per the query parameter `name` and/or `type`, only the `config` part of the below response is returned.

```
{
  "metadata": [
    {
      "name": "",
      "type": "",
      "description": ""
    }
  ],
  "config": {
    "max-metadata-per-file": 10,
    "max-key-len": 10,
    "max-value-len": 10,
    "allow-adhoc": true
  }
}
```

### 3.3. Delete Metadata from Schema

Using this API, a specific metadata can be removed from the set of metadata schema.

```
DELETE https://[domain]/dls/schema/metadata/{name}
```

Here `name` in the URL path is the key name of the metadata that is to be deleted. On successful deletion, the above API will return `HTTP 204` response. If meta data name is not found, then `HTTP 404` is returned. `HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.

If the metadata is already in use as part of already uploaded file, the deletion from schema would not cause any effect on the already uploaded file. Files uploaded after the deletion, would only be impacted.



### 3.4. Delete Schema

This API completely removes metadata schema and disable schema enforcement for the tenant and all users of the tenant. This makes the tenancy `non-schematic`.

```
DELETE https://[domain]/dls/schema
```

Calling the above API will return `HTTP 204` response. If Schema config is not set or already deleted, `HTTP 409` is returned. `HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.



### 3.5. Create Ontology Prefix

The metadata used for Data Point APIs must be from public ontology. This API helps to register an ontology prefix and the vocabulary link to the ontology defintion. 

```
POST https://[domain]/dls/schema/ontology?prefix=foaf&vocabularyLink=http://xmlns.com/foaf/0.1/
```

The `prefix` and `vocabularyLink` values must be individually unique. Maximum 10 word characters are allowed in `prefix` and `vocabularyLink` accepts maximum 255 characters as URL.



Only admin can create an ontology prefix in DLS.

By default, `dct`, `dcat`, `prov`, `r3d` and `dls` are availble as pre-configured ontology prefixes. They can not be created using this API. An `HTTP 409` with message -` c` is thrown when creating these ontology using API.



### 3.6. Delete Ontology Prefix

Delete an already registered ontology prefix from DLS.

```
DELETE https://[domain]/dls/schema/ontology/[prefix]
```

An admin can delete an ontology prefix. On success, `HTTP 204` is returned.

### 3.7. Get Ontology Prefix

To get all existing ontology prefixes already registered in DLS, call this API -

```
GET https://[domain]/dls/schema/ontology
```

If there is data, it is returned in the following Map format.

```
{
  "prefix1": "vocabularyLink1",
  "prefix2": "vocabularyLink2",
  "prefix3": "vocabularyLink3"
}
```

If there is no ontology prefix registered in DLS, `HTTP 404` is returned. 

**Note:** By default, `dct`, `dcat`, `prov`, `r3d` and `dls` are availble as pre-configured ontology prefixes. These are not shown in the above Get Ontology prefix response. 



## 4. File Management

### 4.1. File Upload

DLS provides API to upload file. While uploading a file, a set of meta-data can be sent along with the file. These meta-data are represented in `key=value` format, separated by comma. Here both `key` and `value` are user defined. Each file uploaded in DLS will have a unique `file-uri` across entire DLS. 

```
POST https://[domain]/dls/file?filename=drop.sql
```

Content-Type: `multipart/form-data`
File Part :  `-F metadata=type=sql,loc=100`

The above API call will upload a file "drop.sql" and describe it as a SQL file with 100 lines of code.
Response Body will contain the `file-uri` of the uploaded file.
Response Header : HTTP Status code `202 Accepted`

If meta-data is not in correct format then HTTP `400 Bad Request` status code with message `Meta-data is not in correct format` is returned.



#### 4.1.1. Update Meta-data

File upload API can also be used to update the set of meta-data which have been already created for a file. 
In case there is no multi-part file in payload of the above API and the `filename` request parameter contains an existing file in data lake then `meta-data` gets updated in DLS and no other action is taken.

In that case, `HTTP 205 Updated` response is returned.



#### 4.1.2. Upload Out-of-the-band File

Instead of uploading a file, it is possible to link an external file in DLS. Here `filename` request parameter in the above API call will contain an URI instead of a file name.



#### 4.1.3. Save-point

While re-uploading same file after some content modification, it may be necessary to keep the previously uploaded file available in DLS. To enable this, `savepoint` can be mentioned for a file. Save-point allows multiple copies of same file to exist in DLS, under different `savepoint` names. If no save-point is mentioned, re-upload of same file will be restricted.

```
POST https://[domain]/dls/file?filename=drop.sql&savepoint=sp
```



**Use Savepoint to Save File Directory**

As on TCUP release 11, directory values can be passed in savepoint in form of `/some/directory/`

The resulting file URI will also contain this user provided directory.

**Rules for savepoint -**

- Max length 50 chars
- Only non-white-space, alphanumeric characters, `_`, `-`, `:`, `.` and `/` are allowed
- Max depth of directory hierarchy allowed is 10
- At least one alphabet character must be present in `savepoint` name
- At least one character must be present in each directory name in `savepoint` 
- Case in-sensitive



#### 4.1.4. File Upload Mode : Overwrite

Starting TCUP release 11, existing files uploaded to DLS can be overwritten. A URL parameter named `overwrite` when set to `true` will overwrite the file if exists.

#### 4.1.5. File Upload Mode : Archive

In this mode, when a file is re-uploaded, DLS will automatically archive the previously uploaded file. 
Assume there is a file `F1` created on `T1` in DLS. At time `T2`, the same file `F1` gets re-uploade with `mode=ARCHIVE`. 

Now in DLS Catalog, the latest file `F1` which created on `T2` is shown along with another file `F1_T2` which has original creation timestamp `T1`. User can both download `F1` and `F1_T2` using regular download API.

The archive file can be downloaded, overwritten, appended, archived and deleted if required.

#### 4.1.6. File Upload Mode : Append

In this mode, content of the uploading file is appended with the file already existing in DLS. 



If no mode is mentioned, or a value `RESTRICT` is provided, the default behaviour is shown where re-upload of same file is **not** allowed.



#### 4.1.7. Notes on File URI

 **Important Note for R11 :**

 The file URI format has been changed in TCUP R11. Please note the the below format carefully. The old format was like -

 ```
 /{tcup_user}/{dls_user}/{file_extension}/{file_name}/{savepoint}/{file}
 ```

The relative path of uploaded file, or the `file-uri` is 

```/{tcup_user}/{dls_user}/{file_extension}/{file_name}/{savepoint}/{file}
/{tcup_user}/{dls_user}/{directory_id}/{savepoint}/{file}
```

For example, if a TCUP user "company_x" has one DLS user "employee_y" who has uploaded a file "payslip.pdf" then the file URI will be `/company_x/employee_y/payslip.pdf`.

If the DLS user has mentioned the save-point name as "January", then the URI will be `/company_x/employee_y/January/payslip.pdf`.

File URI is unique across DLS.



***Validation of input fields in file upload API***

 1. `filename` query parameter must match the uploaded file name.
 2. Maximum 50 meta-data can be uploaded for a file
 3. Meta-data key must be 3 to 20 characters long; only alpha-numeric and underscore are allowed
 4. Metadata key can contain `private@` and `public@` access modifier, prepended with key name, by default, metadata is public
 5. Meta-data value must be 1 to 50 characters long; alpha-numeric, whitespace and  `.` `*` `\` `/` `+` `-` `:` are allowed
 6. Duplicate meta-data name, irrespective of case, can not be used while uploading a file in the same `PUT` call
 7. Meta-data name and value can not be similar, e.g `name=name` is not allowed
 8. `savepoint` query parameter length must not exceed 150 characters; only alpha-numeric, `_`and `/` are allowed 

All above validation errors will result `HTTP 400` response from DLS



**By default, uploaded file size limit is 5GB, unless it is changed DLS server configuration.**

In case, files larger than the permissible limit is being uploaded, DLS server will terminate the client HTTP connection without further processing the request. Client may not receive any response in such HTTP calls.



#### 4.1.8 File Upload Constraints

There are several constraints applicable in file upload process. These are mostly integriety constraints and in most cases, `HTTP 409` error is returned to the user. Below are few examples -

- if the TCUP admin has set a storage limit for the tenant, file can not be updated if it's size is more than available space.
- any file larger than the configured limit (e.g 5GB) can not uploaded by HTTP API
- files with duplicate names are not allowed
- file being uploaded with a directory is rejected if either directory does not exist or user do not have write (`W`) permission on the directory
- if metadata schema is set by the admin, and ad-hoc metadata addition is not allowed, file having metadata not belonging to the metadata schema, is not allowed to be uploaded
- if file is being uploaded with directory and admin has set a metadata rule for that specific directory, there could be two scenario. In first case, when one or more file metadata is missing as per directory rule; and the enforcement type is `STRICT`, DLS returns error and does not allow file upload. In second case with enforcement type `STANDARD`, DLS allows file upload but the file is marked inconsistent. If all metadata is present as per directory metadata rule, file is uploaded as normal, consistent file.







### 4.2. Upload Multiple Files

Multiple files can be uploaded using a single API call of DLS. Following REST end-point is to be used.

```
POST https://[domain]/dls/files
```

JSON payload in HTTP request to be sent as file `descriptor` -

```
[{
	"filename": "pom.xml",
	"savepoint": "v1",
	"mode": "OVERWRITE",
	"directory": "/D",
	"comment": "xx"
	"metadata": ["key1=value1"]
}]
```

The files have to be sent in HTTP request as multipart files. The uploaded file's name must match with exactly one entry in `descriptor`. In case, there is a mismatch in the number of files uploaded and number of descriptor entities mentioned in the JSON, an `HTTP 400` error message is returned. If either of the files or descriptor entities are duplicate in this API call, again `HTTP 400` error is returned. 

In case, the file is already existing in DLS, `HTTP 409 Already Exists` error is mentioned in response JSON.

Response code - `HTTP 207` (*i.e multiple response code inside*)

Response JSON -

```
[{
	"identifier": "pom.xml",
	"message": "RR/dlsadmin/xml/pom/v1/pom.xml",
	"code" : 202
}]
```



If the file upload is successful, then the URI will be returned in `message` attribute. If there is any validation error, the error message will also be sent via this `message` attribute.

**Notes** : The acceptable values for upload `mode` are `OVERWRITE`, `ARCHIVE` and `APPEND`. If left blank, default behaviour of restricting overwrite is shown.

The `code` attribute inside the response JSON will contain exact HTTP status codes for any failure to upload the individual files. `HTTP 202` is the success code.



Example of CURL command to upload multiple files -

```
curl -X POST "http://localhost:8080/dls/files" -H  "accept: */*" -H  "x-api-key: xx" -H  "x-dls-key: xx" -H  "Content-Type: multipart/form-data" -F "descriptor=[{"filename":"pom1.xml"},{"filename":"pom2.xml"}]" -F "file=@/path/to/file/pom1.xml" -F "file=@/path/to/file/pom2.xml"
```



### 4.3. Upload File Bundle

A bundle is a compressed file containing many other individual files. DLS provides an API to send multiple files in a REST call and create a bundle at the server-side. Each individual file in the bundle can have their own metadata. The bundle must have a unique name either supplied by user or generated as timestamp from DLS. Individual files in bundle do not have individual `file-uri`. Bundle is downloaded as compressed file itself.

To create a bundle, call this below API along with the parameters mentioned in the table

```
POST https://[domain]/dls/files/bundle
```

List of bundle parameters -

| name         | description                                                                       |
|--------------|-----------------------------------------------------------------------------------|
| `descriptor` | The bundle descriptor is a JSON to be sent as form data                           |
| `name`       | The user supplied name of the bundle; if absent, system timestamp is used as name |
| `savepoint`  | Savepoint of a bundle, if a same bundle with previously used name already exists  |
| `type`       | Type of the compression to be used to create a bundle - `ZIP` and `TAR`           |
| `comment`    | User's comment to be added for the bundle                                         |
| `directory`  | Directory to be associated the compressed file (bundle)                           |
| `file`       | List of multipart files                                                           |



On successful creation of bundle, `HTTP 202` is returned with the newly created bundle `file-uri` in the response body as plain text.

JSON payload in HTTP request to be sent as bundle `descriptor` -

```
[{
	"filename": "pom.xml",
	"directory": "/D",
	"comment": "xx",
	"metadata": ["key1=value1"]
}]
```

**Note :** The `directory` attribute in bundle descriptor is used to create directory structure inside the compressed file so that when bundle is downloaded and decompressed, desired directory structure is found. This directory is not an attribute of bundle file.



The files have to be sent in HTTP request as multipart files. The uploaded file's name must match with exactly one entry in bundle `descriptor`. In case, there is a mismatch in the number of files uploaded and number of descriptor entities mentioned in the JSON, an `HTTP 400` error message is returned. If either of the files or descriptor entities are duplicate in this API call, again `HTTP 400` error is returned. 

In case, the bundle is already existing in DLS, `HTTP 409 Already Exists` error is mentioned in response JSON.

Response code - `HTTP 207` (*i.e multiple response code inside*)

Response  -

```
/bundle/uri
```

Bundles are useful to store many small, inter-related files under a common, downloadable `file-uri`. Individual files of a bundle can not be downloaded separately as they do not have anu individual `file-uri`.



#### 4.3.1 Get Bundle Descriptor

The `Catalog` JSON (output of `Get Catalog` API under Catalog group) lists bundles along with files. A bundle in `Catalog` JSON, has an attribute called `bundle`. It has following format -

```
[{
	"filename": "pom.xml",
	"directory": "/D",
	"comment": "Maven file",
	"size-bytes" : 1024
	"metadata": ["key1=value1"]
}]
```

Each entity in this bundle descriptor is an individual file being compressed in bundle. For example, here `pom.xml` is a `1KB` file which is compressed in bundle under directory `/D`.



### 4.4. File Download

Any file can be downloaded from data lake if the unique `file-uri` is known. If it is not known, it can be searched from file catalog. To download a file, use this following API -

```
GET https://[domain]/dls/file?file-uri=[/file/uri]
```


Set the HTTP request header `Accept : application/octet-stream`

The file download API gets automatically redirected to one or more other internal APIs of DLS, in order to download the file. The HTTP client must enable redirect option while calling this API.

Irrespective of the actual back-end storage of the file, this API uniformly downloads either from HDFS or Local storage.

Files registered in DLS as `out-of-band`, can not be downloaded using this API.

Trying to download a deleted file will throw `HTTP 409` error with message `File is already deleted`.

Bundles can also be downloaded using this API





### 4.5. File Download from Staging Location

The file upload process in DLS, involves storing the file in a temporary location before permanently sweeping it to DFS. Such files are marked as `transfer-success` = `false` in `Catalog` to differentiate that these files are still in staging location. Following API can be used to download these type of files from staging location as well -

```
GET https://[domain]/dls/file/temp?file-uri=[]
```

Set the HTTP request header `Accept : application/octet-stream`

This improves data availability in situations where DFS storage is unavailable temporarily.



### 4.6. Download Multiple Files

Multiple files can be downloaded using a single API. The files are downloaded as compressed ZIP file.

```
GET https://[domain]/dls/files
```

Following query parameters can be added as filters.

| parameter name | description                                                  |
| -------------- | ------------------------------------------------------------ |
| `directory`    | Optional directory name from where files to be downloaded. If `/` is sent, files from root directory will be zipped. If no value is sent, all files will be zipped. |
| `from`         | Files uploaded after this date is zipped.                    |
| `to`           | Files uploaded before this date is zipped.                   |
| `filename`     | One or more filename separated by comma. It can have wildcard (*) search. |
| `fileCount`    | Maximum number of files to be zipped in single API call.     |
| `pageNo`       | If there are more files than what is mentioned in `fileCount`, it can be used to download next set of files as ZIP. Default is `1`. |

> **Important Note:**
>
> Please contact your administrator to learn if DLS is configured with HDFS or NFS. This API only works with files stored in NFS. Files stored in HDFS are ignored.
>
> Files which are locked, external or under the sub-directories of the searched directory, are ignored.
>
> The files inside ZIP retains the actual upload time of the files.
>
> User must have `R` permission on the directory to ZIP and download the files in it.





### 4.7. Update File Metadata

The existing set of metadata of a file can be changed to a new set of metadata using the following API -

```
PUT https://[dimain]/dls/file/metadata?file-uri=[\file\uri]
```

The new metadata set needs to be sent as part of request part called `metadata` in form of 

```
metadata=key1%3Dval1&metadata=key2%3Dval2
```

Here '**%3D**' is URL encoded value of '**=**'

On successful updation of the file metadata, `HTTP 205`  will be returned. 

> **Important Note** : This API completely overwrites the existing set of metadata. It does **not** append with existing set. For this reason, this API can also be used to remove existing set of metadata by simply sending no `metadata` in the HTTP request.


If file is inside any directory, then to update metadata, user must have been already permitted `W` (write) action on the directory.
> This API can not change private metadata added by other users.
> 
> Private metadata can be duplicate for a specific file from multiple users. 

### 4.8. Update Savepoint

To rename an existing savepoint, use the following API.

```
PUT https://[domain]/dls/file/savepoint?file-uri=[URI]&savepoint=[new_value]
```

This returns the newly generated file URI along with  `HTTP 200 (OK)` status code.

In case, invalid or non-existing file URI is given in input,  `HTTP 404` is returned. 

In case, the given savepoint name conflicts with another existing savepoint, `HTTP 409` is returned.

DLS automatically renames all archive files of the original file as well. 

If savepoint value is blank, then DLS removes the existing savepoint from the file URI.



A special file lineage is maintained for renamed file URI. User can recognise, if a file has been renamed to another URI by searching file lineage with old URI.



### 4.9. Update File Directory

Using this API, the existing directory of a file can be updated. If there was no directory attached to the file, a new directory can be added. Also, if there was already a directory attached, the existing directory can be removed by passing an empty directory. 

```
PUT https://[dimain]/dls/file/directory?directory=[]&file-uri=[]
```

**Important Note** : After directory is updated, the existing file URI changes.

If `file-uri` sent in request does not exist, `HTTP 404` error is returned. If directory does not exist or the user does not have `W` (write) permission on destination directory or does not have `D` delete permission on source directory, `HTTP 409` with proper error message is returned. 
If the `directory` and `file-uri` is already existing, then `HTTP 409 Already Exists` error is thrown. 

Directory can be updated for `out-of-band` files also.

If the file is already shared to other users, the directory can not be attached unless file-share is removed.

To remove existing directory of a file, the `directory` parameter need not to be sent in this API.



### 4.10. Update File Comment

This API helps to add comments to an existing file.

```
PUT https://[dimain]/dls/file/comment?file-uri=[]
```

The comment has to be sent in the request body as plain text along with a request header `Content-Type: text/plain`. 

Multiple comments can be added for a file by a single user. In case of shared files, different users can add comments on a same file.

**Important Note** : A single comment can be only 255 characters long.

DLS would automatically add the user and timestamp for each comment added for a file.

A file which is shared to another user, can also have comments from that user.



### 4.11. Get File Comment

To retrieve all comments added by all users for a file, use this following API

```
GET https://[dimain]/dls/file/comment?file-uri=[]
```

The response of the above API call is as below -

```
[
  {
    "user": "",
    "comment": "",
    "commented-on": "29-Apr-2020 13:25:22 UTC",
    "file-uri": ""
  }
]
```


### 4.12. Delete File Comment

Comments for a file can be entirely deleted by using following API -

```
DELETE https://[domain]/dls/file/comment?file-uri=[]
```

This API deletes all comments added by this user for this file.



### 4.13. Delete File

By using this API, a file can be deleted.

```
DELETE https://[domain]/dls/file?file-uri=[\file\uri]
```

On successful deletion of the file, `HTTP 204` is returned.

Trying to delete an already deleted file will throw `HTTP 409` with message `File is already deleted`.
Trying to delete a file with invalid URI will throw `HTTP 404` with message `Not found`.

Invoking the file delete API will erase the file from storage and set the `deleted` flag as shown in file catalog.

> Inconsistent files which have `transfer-success : false`, can be deleted using the `forced=true` parameter in this API.

A deleted file can again be uploaded having same file name.

If the file is re-uploaded, catalog would show both the newly uploaded file and previously deleted files. Hence, in such scenario, catalog may contain duplicate `file-uri`. 



**NOTE :** *By default, catalog shows all deleted files. To filter out any files which have been deleted, as well as shared files which have been deleted by the owner, `deleted=false` search condition needs to be added in catalog query.*



## 5. File Link

File links are special metadata that relates two files with a custom relation name.

### 5.1. Create New Link
Uploaded files can be linked to each other using some Ad-hoc relationship names. This helps to create a transformation and dependency chain among files.

```
POST https://[domain]/dls/link/[relation]?lhs-file-uri=[/file/uri]&rhs-file-uri=[/file/uri]
```

Relation names are not case-sensitive. All relation names are converted to lower case in the system.

Invalid relation names will result `HTTP 400`.

`lhs` is abbreviation of Left Hand Side and `rhs` is abbreviation of Right Hand Side.



### 5.2. Create Multiple Links

Multiple files can be linked to each other with help of this API. 

```
POST https://[domain]/dls/links
```

JSON Payload to send to link multiple files -

```
[ 
  { 
    "lhs-file-uri": "F1",
    "relation": "R1",
    "rhs-file-uri": "F2" 
  }
]
```

Response code - `HTTP 207`

The response contains a JSON describing each file link and associated success or failure messages. For success, `linked` text is returned. 

Following is an example of failure message example -

```
[
  {
    "identifier": "F1 R1 F2",
    "message": "Invalid LHS file",
    "code": 400
  }
]
```

Here, first linking failed as the relation name was invalid, whereas the second linking succeeded.



### 5.3. Get File Link

Files can be searched using the relation name and with or without any of the two file names used in that relation. To get all files involved in a specific type of relation - 

```
GET http://[domain]/dls/link?relation=[name]
```

To get all files involved in other side of the relation -

```
GET http://[domain]/dls/link?lhs-file-uri=[/file/uri]&relation=[relation] 
```

or

```GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]&amp;relation=[relation]
GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]&relation=[relation]
```

To get all relations to other files - 

```
GET http://[domain]/dls/link?rhs-file-uri=[/file/uri]
```

Response is strings separated by new-line delimiter. Each line contains a link details

```[lhs-file] [relation] [rhs-file]
[lhs-file] [relation] [rhs-file]
```



**Note** To list all archived file, use relation name as `dls:archivedTo`



### 5.4. Delete File Link

To delete a link, use following API -

```
DELETE http://[domain]/dls/link?lhs-file-uri=[]&relation=[]&rhs-file-uri=[]
```

If this link is not available `HTTP 404` is thrown. After successful deletion `HTTP 200` is returned.

**Note** Trying to delete a link for archived files using relation name as `dls:archivedTo`, is not allowed.



## 6. File Share

A DLS user can shared uploaded files to other DLS users. File sharing allows other DLS users to download a copy of the shared file but original file can not be modified. 



### 6.1. Create New Share

Following API can be used by any DLS user to share his/her uploaded files to other DLS users.

```
POST https://[domain]/dls/share/[dls-user]?file-uri=[/file/uri]
```

Here the `dls-user` URL parameter is the other DLS user to whom the file mentioned in `file-uri` query parameter, needs to be shared.

On successfully creation of file share,`HTTP 201` is returned by DLS.

If the `file-uri` value provided in query parameter does not exists in DLS or the URI belongs to other DLS users, `HTTP 404` response is returned. This restricts transitive sharing. For example, if a file is originally uploaded by DLS user A, is shared to DLS user B. This file can not be further shared to other DLS users by DLS user B.

If the `dls-user` mentioned in URL parameter does not exist, `HTTP 409` response code is returned.

Same file can be shared to multiple DLS users. 



### 6.2. Get File Share

This API helps a DLS user to know all the files that he/she has shared to other DLS users.

```
GET https://[domain]/dls/share
```

Here the all files shared to all DLS users will be listed.

```
GET https://[domain]/dls/share?dls-user=[A]
```

Here the files shared to DLS user `A` will be listed.

If no file has been shared yet, `HTTP 404` status code is returned.




### 6.3. Delete File Share

By using this API, a file which has been shared, can also be revoked from sharing.

```
DELETE https://[domain]/dls/share/[dls-user]?file-uri=[\file\uri]
```

On successful deletion of the file share, `HTTP 200` status code is returned.

If the file share is already deleted, or `file-uri` value in query parameter does not exists in DLS or belongs to other DLS users, a `HTTP 404` status code is returned.

If the `dls-user`mentioned in URL parameter does not exist, `HTTP 409` response code is returned.





## 7. Directory

Directory is a newly introduced concept in DLS from TCUP11 onward.Now User can create Directory and assign permission to the users for that directory.User also can write meta data rules for a directory.


### 7.1. Create New Directory and Assign Permission to it

Only DLS **administrator** can create directory. 

```
POST https://[domain]/dls/directory
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "directory": "/myDir",
    "meta-data": "key1=value1,keyN=valueN",
    "enforcement": "",
    "metadata-rule": [
      {
        "default-value": "",
        "name": "",
        "type": "",
        "value-mandatory": true
      }
    ],
    "permissions": [
      {
        "action": "",
        "directory-action": "",
        "users": [
          ""
        ]
      }
    ]
  }
]
```

**Response Codes** : `HTTP 207`

**Response Payload**

Following JSON response is returned after calling this API if the directory already exists.

```
[
  {
    "key": "directory",
    "value": "/myDir",
    "messages": ["Directory already exists"],
    "code": 409
  }
]
```



**Notes:**
    

1.  Directory name can only contain alpha-numeric, `-` and `_`
2.  Directory name must start with `/`  and multiple sub-directories can be mentioned as well
3.  User can not and need not create root directory  `/`
4.  While creation of Directory permission is optional. User can create directory with or without permission assigned to it for users.
5.  If permission is assigned for user the permitted action can be combination of `R` , `W`,  `D` 
6.  Enforcement must be STRICT or STANDARD
7.  Only TEXT/NUMERIC metadata type is supported in rule
8.  Like file metadata, directory can also have metadata. But only public metadata is allowed here.

**Notes on Hierarchical Directory:** 
>
> It is possible to create a hierarchy of directories in a single API call. The directory name should be in form of a directory path e.g - `/A/B`. Here multiple directories are created internally in DLS. The directory `/A` is implicitly created with the same permission intended for `/A/B`. But any directory rule given for `/A/B` is not added automatically for `/A`. Even if the directory rule validation fails for `/A/B` for any reason, directory `/A` and associated permission is added successfully in DLS. 

**Notes on Permission Escalation:**
>
> If any user is given a specific permission on a directory, all **admin** users hierarchically above the explicitly mentioned user, would also gain the same privilege automatically. This is especially seen in organizational access control scheme of DLS.

**Notes on Directory Rule**
>
> The directory rule mentioned during creation of directory has two important parameters. First one is `enforcement` type. It allows either of two fixed values, `STANDARD` and `STRICT`. By default, `STRICT` is assumed. The second parameter of rule is a set of metadata rule that creates a rule set. Each metadata rule has `name` and `type` of the metadata along with a flag called `value-mandatory` and a `default-value`.  Follow the below table to find the behaviour of directory rule enforcement based on these two parameters -
>
> | File Metadata                                                                               | Enforcement | Rule | Response                             |
> |---------------------------------------------------------------------------------------------|-------------|------|--------------------------------------|
> | All metadata present as per rule                                                            | `STRICT`    | Pass | Success                              |
> | Metadata is absent during file upload and no `default-value` in rule                        | `STRICT`    | Fail | Error                                |
> | One or more additional metadata given than rule                                             | `STRICT`    | Fail | Error                                |
> | Absent one or more metadata but `default-value` and `value-mandatory=false` present in rule | `STRICT`    | Pass | Default value taken                  |
> | Absent metadata with `default-value` and `value-mandatory=true`  in rule                    | `STRICT`    | Fail | Error                                |
> | All metadata present as per rule                                                            | `STANDARD`  | Pass | Success                              |
> | One or more additional metadata given                                                       | `STANDARD`  | Pass | Success                              |
> | Metadata is absent and no `default-value` in rule                                           | `STANDARD`  | Pass | File marked with `inconsistent` flag |
>
> 



**Notes on Directory Management Permission**

> Assign directory management permissions to users for the directory. Use appropriate `directory-action` in the permission JSON. Following table describes how permission can be set :
>
> |                    | `R`                                 | `W`                                        | `D`                               |
> |:-------------------|:------------------------------------|:-------------------------------------------|:----------------------------------|
> | `action`           | Download files from this directory. | Upload file(s) to this directory.          | Delete file(s) of this directory. |
> | `directory-action` | Read content of this directory.     | Create sub-directories, permission, rules. | Delete this directory.            |



### 7.2. Update Permission for Directory 

Only DLS administrator can update permission to a directory. 

```
PUT https://[domain]/dls/directory/permission?directory=[directory]
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "action": "",
    "directory-action": "",
    "users": [
      ""
    ]
  }
]
```


Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

**Notes:**
    

1.  ‘dls-user’ is the username of TCUP user
    
2.  ‘dls-key’ is the TCUP user’s private API key
    
3.  While updating permission to a directory for group of users directory must exist 
    
4.  Permitted action can be R,RW and RWD as of now


### 7.3. Update Directory Meta Rules

Only DLS administrator can update meta rules for a directory. 

```
PUT https://[domain]/dls/directory/meta-rule?directory=[directory]&enforcement=[enforcement]
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

```
[
  {
    "default-value": "",
    "name": "",
    "type": "",
    "value-mandatory": true
  }
]
```


Response Codes : `207` , `400` for invalid payload

**Notes:**
    

1. Enforcement must be STRICT or STANDARD
2. Only TEXT/NUMERIC type is supported



### 7.4. Get Directory


Get the details of directory along with users and permitted action

```
GET https://[domain]/dls/directory?directory=[directory]
```

The response is a list of directories along with users and permitted action assigned to that directory

```
[
  {
    "directory": "",
    "permissions": [
      {
        "users": [
          ""
        ],
        "action": ""
      }
    ]
  }
]
```


### 7.5. Delete Directory

To delete Directory , use following API -

```
DELETE https://[domain]/dls/directory?directory=[directory]
```

If this directory name is invalid `HTTP 404` is thrown.After successful deletion `HTTP 204` is returned.

**Notes:**

1.  To delete a directory with files attached to it, first remove the files from this directory. Either delete the files using `DELETE /file` API or call  `PUT /file/directory` API to attach the files to any other directory.
2.  If user deletes a directory to which permission is assigned then permission assigned to the directory will also be deleted.
3.  If sub-directories exist, they need to be deleted explicitly before deleting the directory.


### 7.6. Delete Directory Permission

To delete the permission assigned to the user for any directory, use following API -

```
DELETE https://[domain]/dls/directory/permission?directory=[directory]&user=[user]
```

If there is no permission available for the directory and/or user, `HTTP 404` is returned. After successful deletion `HTTP 204` is returned.

**Notes:**

1. User can provide either directory name or user name or combination of both while deleting permission.
2. If only directory name is mentioned, any permission of all users on this directory is removed.
3. If only user name is mentioned, permissions to directories of this user, is removed.
4. At least one of two query parameters must be mentioned.


### 7.7. Delete Directory Meta Rule

To delete Directory meta rule , use following API 

```
DELETE https://[domain]/dls/directory/meta-rule?directory=[directory]&metadata-name=[metaDataName]
```

If this directory name is invalid `HTTP 404` is thrown.After successful deletion `HTTP 200` is returned.

**Notes:**

1. Meta data name is optional,if given only that meta data will be deleted for the directory,otherwise all meta data for that directory will be deleted


### 7.8. Add/Update Directory Metadata
This API helps to add new metadata or update value of existing metadata value. If the key of the given metadata does not exist, it is added.
If key already exists but a new value is provided, the value is updated.

```
PUT https://[domain]/dls/directory/metadata?directory=[directory]
```
**Header** : `Content-Type: application/json`
**Request Body**

Send a list of key value pair -
```json
[
  "key1=val1",
  "key2=val2"
]
```
**Response** 
`HTTP 205` - successful addition / updation of metadata
`HTTP 400` - validation errors with JSON response messages
`HTTP 404` - directory could not be found


### 7.9. Delete Directory Metadata
This API helps to delete existing metadata.

```
DELETE https://[domain]/dls/directory/metadata?directory=[directory]&name=[metadata key]
```

**Response**
`HTTP 204` - successful deletion of metadata
`HTTP 404` - directory and/or metadata name could not be found


## 8. File Lock

Usually, a directory has files accessible by multiple permitted users. In some scenario,  one such user might want to restrict modification or deletion of a file by other users. The file lock feature can be used to restrict other users to overwrite, append, archive, delete, update file metadata or savepoint and change the file directory. Additionally, a locked file can be hidden from other users as well. Any user, who has write `W` permission on a directory, can lock any file under it. Only the same user or an admin can unlock such locked files. 

**Note** In the catalog API response JSON, the file `locked` and `hidden` status is shown to the user who has locked the file. 



### 8.1. Lock a File

To lock a file, call the following API- 

```
POST https://[domain]/dls/lock?file-uri=[file-uri]
```

Here only `file-uri` request parameter is mandatory.

Optionally, to add comment while locking the file, send the comments (maximum 255 characters) in HTTP request body. `Content-Type` header is `plain/text`.

On success, `HTTP 201` response code with `locked` message is returned.



**Note :** A lock can **not** be obtained on a file, if

- the file is already locked by some other user,

- the file is not under any directory,

- the file is external or out-of-the-band file, 

- user does not have write (`W`) permission on the directory under which file exists

- file upload `transfer-success` status is `false`.

In all these above cases, `HTTP 409` status is returned with proper message.



#### 8.1.1 Hide and Lock a File

To hide a file while locking, following API is used -

```
POST https://[domain]/dls/lock?file-uri=[file-uri]&hide=true
```

If the locked file is hidden, it is only visible in the catalog of the user who has locked it. It is also visible to an admin who has access to that directory where that file exists. But other users, in spite of having access to the directory, can not find the hidden file in their catalog.

**Note:** Only a locked file can be hidden.



### 8.2. Unlock a File

Only the user who has locked the file can unlock the file using the below API. An admin having access to the directory where the file exists, can also unlock the locked file.

```
DELETE https://[domain]/dls/lock?file-uri=[file-uri]
```

`http 204` is returned on success.



### 8.3. Update Hidden/Shown State of Locked File 

The locked file can be either hidden or shown. Following API can be used to hide or show a locked file.

```
PUT https://[domain]/dls/lock?file-uri=[file-uri]&hide=true
```

`http 205` is returned on success.



### 8.4. Get File Lock Status

```
GET https://[domain]/dls/lock?file-uri=[file-uri]
```

Following JSON response is returned if the file is locked.

```
{
  "reason": "",
  "hidden": "",
  "locked-by": "",
  "locked-at": "Tue Mar 02 17:40:39 IST 2021",
  "status": "locked"
}
```

In case file is not locked or already unlocked, following response is returned.

```
{
  "status": "unlocked"
}
```

If the file does not exist in DLS, `HTTP 404` is returned.



## 9. User Management

There are several API available for the DLS admin to be used to manage users of that tenant.



### 9.1. Create New DLS User with User Provided Keys

Only DLS administrator can create another DLS user. 

```
POST https://[domain]/dls/user/key
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

	[{
	    "dls-key": "",
	    "dls-user": ""
	}]

Response Codes : `201`, `401` (Invalid API key), `403` (Invalid DLS key)

**Notes:**

1.  During DLS service activation of **user** from the portal, above API needs to be called.

2.  Service deactivation will NOT call any API of DLS

3.  ‘dls-user’ is the username of TCUP user

4.  ‘dls-key’ is the TCUP user’s private API key

5.  After successful provision of user in DLS, client can call all APIs of DLS (except user provision APIs) using both `x-api-key’ and ‘x-dls-key’ having same value of the user’s public API key.

6.  Otherwise, client can pass only ‘x-api-key’ of the user; in that case, API gateway will inject additional header called ‘x-dls-key’ in the forwarding HTTP request to DLS.

7.  This API allows the TCUP user to be the user of DLS.



### 9.2. Create New DLS User with Generated DLS Keys

Only DLS administrator can create another DLS user. 

```
POST https://[domain]/dls/user
```

Headers : `x-api-key` & `x-dls-key`

JSON payload in HTTP request body :

	[
	   "dls_user_1"
	]

The response of the above API is a JSON returned as response body :

	[
	  {
	    "key": "dls_user_1",
	    "value": "032d7e73-909b-401f-82c8-e4b09b15ded2",
	    "messages": [
	      "created"
	    ],
	    "code": 201
	  }
	]

HTTP Response Code  `207` is returned on successful registration.

> If the `dls-user` is already registered, `HTTP 409 - Already exists`  error is returned. 



### 9.3. Get DLS User

Only DLS administrator can get the details of other DLS users.

1. Get details of a specific DLS user -  `GET https://[domain]/dls/user?name=xx`
2. Get all DLS users details  -  `GET https://[domain]/dls/user`

Response JSON is as follows -

```
[
  {
    "dls-key": "24374925-e77e-48b1-8f1b-c6e90ec51850",
    "dls-user": "dls_user_2"
  }
]  
```



### 9.4. List Existing DLS User Names

Every user of DLS is allowed to fetch list of other usernames by using the following API.

```
GET https://[domain]/dls/user/names
```

This API returns the usernames in following format -

```
[
  "dls_user_1",
  "dls_user_2",
  "dls_user_3"
]
```

This API is particularly useful to know other user names before sharing a file with other users.



> If no user is found then `HTTP 404` status is returned and `Not found` message is printed in response body.



### 9.5. Delete User

DLS users can be deleted only by DLS admin. If an user is deleted, all files uploaded by the user are also deleted from HDFS. All catalog information is also deleted for the user.

```
DELETE https://[dimain]/dls/user/{username}
```

Calling the above API will return `HTTP 200` response.  If there is no such username or the user is already deleted `HTTP 404` is returned.

`HTTP 403` is returned in case if this API is called by other users who do not have DLS admin privilege.




### 9.6. Create User Role

DLS allows to define the role of an existing user in context of the users' organization. Based on the defined role, DLS can provide more detailed access control on files and directories that the user is entitled to access.

The user role is a combination of a meaningful URN pattern called the user's organizational-position (`org-pos`) and a flag stating whether this user is admin or non-admin. To define the role, the organization must have been defined during creation of tenant. 

> For example, if a DLS tenant `T1` is created with it's organization name as `Org1` then users of this tenant optionally can have any position as shown in the following example. 

| User | `org-pos`       | Admin | Inference              |
|------|-----------------|-------|------------------------|
| U1   | Org1/Dept1      | true  | Admin of Dept1 of Org1 |
| U2   | Org1/Dept2      | true  | Admin of Dept2 of Org1 |
| U3   | Org1/Dept2/Lab1 | false | User of Lab1           |

>  Inherently, admins with higher `org-pos` like U2 in this case will have access to files or directories owned by users with lower `org-pos` like U3 in this case.

Following end-point is called to create user roles -

```
PUT https://[domain]/dls/user/role?admin=&organization-position=
```

Only users with admin privilege can set the role of other users provided the users are from same organization hierarchy. This means, U2 is authorized to set role of U3 as /Org1/Dept2/Lab1 but U1 can not do the same.

`HTTP 409` is returned with proper messages when the admin tries to set user's organization position but either the organization is not set at tenant level or the admin does not have required organization position to set up user's role.



### 9.7. Get User Role

This API will return the role of the users. This API can either be called by admin or non-admin users. For admin users, all other normal users of same or lower organization position are returned. For non-admin users only it's own role is returned. Following URL is accessed to get the users role -

```
GET http://[domain]/dls/user/role
```

The response is a JSON in the following format -

```
[
  {
    "user-name": "OrgAdmin1",
    "org-pos": "Org1",
    "admin-user": "true"
  },
  {
    "user-name": "LabAdmin1",
    "org-pos": "Org1/Lab1",
    "admin-user": "true"
  },
  {
    "user-name": "LabUser1",
    "org-pos": "Org1/Lab1",
    "admin-user": "false"
  },
  {
    "user-name": "user_without_role",
    "admin-user": "false"
  }
]
```



### 9.8. Delete User Role

User role can be deleted by the DLS admins. In the HTTP request parameter, the specific `user-name` is to be sent. Once the user role is deleted using this API, the user is not part of any organizational hierarchy. Hence, the admins of that organization do not have any control on the user. Although, the user will exist in DLS along with all files uploaded by the user, the privilege to access any directory or file for having that role, will be immediately revoked.

```
DELETE http://[domain]/dls/user/role?user-name=[]
```

If successfully deleted, `HTTP 204` is returned.



## 10. Administrative API

In DLS, there are few API which are only accessible by TCUP admin. These APIs are mostly relevant to TCUP service developers. Application developers would not generally have any access to this APIs.


### 10.1. Register New Tenant

A TCUP tenant can be provisioned in DLS by using following API. 


```
POST https://[domain]/dls/admin/user
```

The payload to be sent in HTTP request body is -

```
{
  "admin-dls-key": "",
  "admin-user-name": "",
  "api-key": "",
  "organization": "",
  "tcup-user": ""
}
```

Here, `organization` and `admin-user-name` are optional attributes in the above JSON. If no `admin-user-name` is sent, the default `dlsadmin` user is created for this tenant. 



### 10.2. Get DLS Admin Key

Using API key of the tenant, the DLS admin key can be fetched.

```
GET https://[domain]/dls/admin/user?tenant_api_key=[API key of tenant]
```



### 10.3. Delete DLS Admin 

DLS admin can be deleted only by TCUP admin. If this DLS admin has other DLS users, `HTTP 409` is returned.

```
DELETE https://[dimain]/dls/admin/user/{username}
```

If DLS admin is deleted, all files uploaded by the DLS admin are also deleted from HDFS. All catalog information is also deleted for the admin.

Calling the above API will return `HTTP 200` response.  If there is no such username or the user is already deleted `HTTP 404` is returned.

`HTTP 403` is returned in case if this API is called by other users who do not have TCUP admin privilege.



### 10.4. Update Tenant's Organization

The organization of an existing tenant can be updated using this API. 

```
PUT https://[domain]/dls/admin/user/organization?organization=[]&tenant=[]
```

If the organization name is absent in request parameter, the existing organization of the tenant is removed. The existing organization can always be altered provided the users of this tenant do not already have any `organization-position`. If they have, the users' role must be altered before removing tenant's organization.



### 10.5. Set Tenant Storage Limit

TCUP admin can limit the total file storage for a specific tenant by using the following API -

```
PUT https://[domain]/dls/admin/storage?storage-limit=[]&tenant=[]
```

The request parameters contains the `storage-limit` value in bytes and the `tenant` name.

**Note:** By default, unlimited storage is allowed for tenant.



### 10.6. Get Tenant Storage Limit

Using the following API, the storage limit set for a tenant can be retrieved along with available and used storage.

```
GET https://[domain]/dls/admin/storage?tenant=[]
```

The response JSON is as follows -

```
{
  "allocated-storage": 1024,
  "available-storage": 512,  
  "used-storage": 512
}
```

**Important Note :** 

When storage limit is set, and the available storage is less than the size of the file to be uploaded, DLS would restrict the upload. Deletion of files, would instantly free up `used-storage`.


### 10.7. Get DLS Storage Type
DLS may use different types of underlying storages like HDFS or NFS. To know which storage option is configured with DLS, use this following API - 

```
GET https://[domain]/dls/admin/storage/type
```

It returns `HTTP 200` with following JSON payload.

```
{
  "type": "",
  "value": ""
}
```

Here `type` contains either `NFS` or `HDFS` and `value` contains the underlying storage directory location.




## 11. Data Point Management

In some scenario, the data and metadata that are stored in DLS, need to be hierarchically maintained for better classification. Further more, as DLS follows principles for [FAIR](https://www.go-fair.org/fair-principles/), there are concepts of FAIR Data Point

The data point concepts are borrowed from FAIR data principles. At the top level there is a repository. 

### 11.1 Repository

Repository is positioned at the top of the hierarchy. An user of DLS can create one or more repositories.

#### 11.1.1 Create Repository

To create a new repository, following API needs to be called. 

```
POST https://[domain]/dls/datapoint/repository
```

The JSON request body is as below -

```
[
  {
    "dct:identifier": "repo-1",
    "permissions": [
      {
        "users": [
          "string"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:someProperty": "string",
      "foaf:name": "string",
      "dct:audience": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dct:publisher": "string",
    "dct:language": [
      "string"
    ],
    "dct:license": "string",
    "dct:subject": "string",
    "dct:alternative": "string",
    "dct:rights": "string",
    "r3d:institution": "string"
  }
]
```

**Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The repository identifier should be unique across all tenants in DLS.

Following success reponse is returned along with `HTTP 207` code.

```
[
  {
    "key": "Repository",
    "value": "repo-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 11.1.2 Get Repository

Following API is used to get the repository by using the unique repository identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}
```

Here `{repositoryIdentifier}` is to be replaced with correct value. If the repository idenfier exists, following JSON response is returned.

```
{
  "_links": {
    "catalogs": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1"
    }
  },
  "r3d:Repository": {
    "dls:prop1": "string",
    "dct:languages": "string",
    "dct:rights": "string",
    "dct:hasVersion": "string",
    "dct:alternative": "string",
    "dct:identifier": "repo-1",
    "dct:description": "string",
    "dct:subject": "string",
    "dct:title": "string",
    "dct:publisher": "string",
    "r3d:institution": "string",
    "dct:license": "string"
  }
}
```

The above JSON returns all standard and custom repository metadata as part of `r3d:Repository` object. It also returns the links to all catalogs under this repository for which user has read (`R`) access.



#### 11.1.3 Delete Repository

Following API can be used to delete a repository.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}
```

If the repository `{repositoryIdentifer}` does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 11.2. Catalog

Each repository can have one or more catalogs.

#### 12.2.1 Create Catalog

Following API is used to create a new catalog.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog
```

Here the `{repositortIdentifier}` is to be replaced the repository identifier under which this catalog is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "catalog-1",
    "permissions": [
      {
        "users": [
          "user1"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:prop1": "string",
      "foaf:name": "string",
      "dct:xx": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:publisher": "string",
    "dct:description": "string",
    "dct:languages": [
      "string"
    ],
    "dct:license": "string",
    "dct:rights": "string",
    "foaf:homepage": "string",
    "dct:themeTaxonomy": "string"
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The catalog identifier should be unique across all tenants in DLS.

On successful registration of catalog, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Catalog",
    "value": "repo-1/catalog-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 11.2.2 Get Catalog (Datapoint)

Following API is used to get the catalog by using the unique repository identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}
```

Here `{repositoryIdentifier}`  and `{catalogIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "datasets": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1"
    }
  },
  "dcat:Catalog": {
    "dls:prop1": "string",
    "foaf:name": "string",
    "foaf:homepage": "string",
    "dct:rights": "string",
    "dct:xx": "string",
    "dct:identifier": "cat-1",
    "dcat:themeTaxonomy": "string",
    "dct:license": "string",
    "dct:languages": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dct:title": "string",
    "dct:publisher": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.



#### 11.2.3 Delete Catalog

Following API can be used to delete a catalog.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}
```

If the catalog does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 11.3 Dataset

Each catalog may have one or more datasets.

#### 11.3.1 Create Dataset

Following API is used to create a new dataset.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog/{catalogIdentifier}/dataset
```

Here the `{repositortIdentifier}` and `{catalogIdentifier}` are to be replaced by the repository identifier and catalog identifier under which this dataset is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "dataset-1",
    "permissions": [
      {
        "users": [
          "user1"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:xxx": "string",
      "foaf:yyy": "string",
      "dcat:zzz": "string"
    },
    "dct:title": "string",
    "dct:hasVersion": "string",
    "dct:publisher": "string",
    "dct:description": "string",
    "dct:languages": [
      "string"
    ],
    "dct:license": "string",
    "dct:rights": "string",
    "dcat:theme": [
      "string"
    ],
    "dcat:contactPoint": "string",
    "dcat:keyword": [
      "string"
    ],
    "dcat:landingPage": "string"
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The dataset identifier should be unique across all tenants in DLS.

On successful registration of dataset, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Dataset",
    "value": "repo-1/catalog-1/dataset-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 11.3.2 Get Dataset

Following API is used to get the dataset by using the unique dataset identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}
```

Here `{repositoryIdentifier}` ,  `{catalogIdentifier}` and `{datasetIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "distributions": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1/distribution/dist-1"
    },
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1"
    }
  },
  "dcat:Dataset": {
    "dls:xxx": "string",
    "dcat:landingPage": "string",
    "dct:rights": "string",
    "foaf:yyy": "string",
    "dct:identifier": "dataset-1",
    "dct:license": "string",
    "dcat:zzz": "string",
    "dcat:keywords": "string",
    "dct:languages": "string",
    "dcat:contactPoint": "string",
    "dct:hasVersion": "string",
    "dct:description": "string",
    "dcat:theme": "string",
    "dct:title": "string",
    "dct:publisher": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.



#### 11.3.3 Delete Dataset

Following API can be used to delete a dataset.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}&dataset-id={datasetIdentifier}
```

If the dataset does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.

### 11.4 Distribution

Each dataset may have one or mores distribution.

#### 11.4.1 Create Distribution

Following API is used to create a new catalog.

```
POST https://[domain]/dls/datapoint/repository/{repositortIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}/distribution
```

Here the `{repositortIdentifier}` is to be replaced the repository identifier under which this catalog is to be created.

Following JSON payload is to be sent in HTTP request body

```
[
  {
    "dct:identifier": "dist-1",
    "permissions": [
      {
        "users": [
          "RR2"
        ],
        "action": "RWD"
      }
    ],
    "custom": {
      "dls:xx": "string"
    },
    "dct:title": "string",
    "dct:license": "string",
    "dct:hasVersion": "string",
    "dct:rights": "string",
    "dct:description": "string",
    "dcat:accessURL": "http://some.external.file",
    "dcat:mediaType": "string",
    "dcat:format": "string",
    "dcat:byteSize": 24410
  }
]
```

> **Note** :  `dct:identifier` is the only mandatory attrbute in the above JSON.  The distribution identifier should be unique across all tenants in DLS.

On successful registration of distribution, following JSON response returned with `HTTP 207` code.

```
[
  {
    "key": "Distribution",
    "value": "repo-1/catalog-1/dataset-1/dist-1",
    "messages": [
      "CREATED"
    ],
    "code": 201
  }
]
```



#### 11.4.2 Get Distribution

Following API is used to get the distribution by using the unique distribution identifier.

```
GET https://[domain]/dls/datapoint/repository/{repositoryIdentifier}/catalog/{catalogIdentifier}/dataset/{datasetIdentifier}/distribution
```

Here `{repositoryIdentifier}` ,  `{catalogIdentifier}` and `{datasetIdentifier}` are to be replaced with correct values. If the idenfiers exists, following JSON response is returned.

```
{
  "_links": {
    "self": {
      "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/catalog-1/dataset/dataset-1/distribution/dist-1"
    }
  },
  "dcat:Distribution": {
    "dcat:mediaType": "string",
    "dcat:format": "string",
    "dls:xx": "string",
    "dct:hasVersion": "string",
    "dct:rights": "string",
    "dct:identifier": "dist-1",
    "dct:description": "string",
    "dct:title": "string",
    "dcat:byteSize": "24410",
    "dct:license": "string"
  }
}
```

The above JSON returns all standard and custom catalog metadata as part of `dcat:Catalog` object. It also returns the links to all datasets under this catalog for which user has read (`R`) access.

#### 11.4.3 Delete Distribution

Following API can be used to delete a dataset.

```
DELETE http://[domain]/dls/datapoint/repository/{repositoryIdentifer}?catalog-id={catalogIdentifer}&dataset-id={datasetIdentifier}&distribution-id={distributionIdentifier}
```

If the dataset does not exist or it is already deleted, `HTTP 404` is returned. On successful deletion, `HTTP 204` is returned.



### 11.5 Discover Datapoint

To search and filter available datapoints in DLS, following API can be used -

```
GET https://[domain]/dls/datapoint?repo-id=repo-1&catalog-id=cat-1&dataset-id=dataset-1&metadata=as%3D%27as%27&exclude=REPOSITORY&exclude=CATALOG
```

The above API call returns all repositories, catalogs, datasets and distributions in DLS, provided user has read (`R`) access on that specific datapoint. Following JSON response is returned with `HTTP 200` code.

```
{
  "repository-list": [
    {
      "links": [
        {
          "rel": "catalogs",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1"
        }
      ],
      "r3d:Repository": {
        "dls:prop1": "string",
        "dct:languages": "string",
        "dct:rights": "string",
        "dct:hasVersion": "string",
        "dct:alternative": "string",
        "dct:identifier": "repo-1",
        "dct:description": "string",
        "dct:subject": "string",
        "dct:title": "string",
        "dct:publisher": "string",
        "r3d:institution": "string",
        "dct:license": "string"
      }
    }
  ],
  "catalog-list": [
    {
      "links": [
        {
          "rel": "datasets",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1"
        }
      ],
      "dcat:Catalog": {
        "dls:prop1": "string",
        "foaf:name": "string",
        "foaf:homepage": "string",
        "dct:rights": "string",
        "dct:xx": "string",
        "dct:identifier": "cat-1",
        "dcat:themeTaxonomy": "string",
        "dct:license": "string",
        "dct:languages": "string",
        "dct:hasVersion": "string",
        "dct:description": "string",
        "dct:title": "string",
        "dct:publisher": "string"
      }
    }
  ],
  "dataset-list": [
    {
      "links": [
        {
          "rel": "distributions",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1/distribution/dist-1"
        },
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1"
        }
      ],
      "dcat:Dataset": {
        "dls:xxx": "string",
        "dcat:landingPage": "string",
        "dct:rights": "string",
        "foaf:yyy": "string",
        "dct:identifier": "dataset-1",
        "dct:license": "string",
        "dcat:zzz": "string",
        "dcat:keywords": "string",
        "dct:languages": "string",
        "dcat:contactPoint": "string",
        "dct:hasVersion": "string",
        "dct:description": "string",
        "dcat:theme": "string",
        "dct:title": "string",
        "dct:publisher": "string"
      }
    }
  ],
  "distribution-list": [
    {
      "links": [
        {
          "rel": "self",
          "href": "https://[domain]/dls/datapoint/repository/repo-1/catalog/cat-1/dataset/dataset-1/distribution/dist-1"
        }
      ],
      "dcat:Distribution": {
        "dcat:mediaType": "string",
        "dcat:format": "string",
        "dls:xx": "string",
        "dct:hasVersion": "string",
        "dct:rights": "string",
        "dct:identifier": "dist-1",
        "dct:description": "string",
        "dct:title": "string",
        "dcat:byteSize": "24410",
        "dct:license": "string"
      }
    }
  ]
}
```

The above response can be filtered using the following URL paramters sent during API call.

| parameter name    | description                                                  |
| ----------------- | ------------------------------------------------------------ |
| `repo-id`         | Only catalogs, datasets and distributions under this repository are returned. |
| `catalog-id`      | Only datasets and distributions under this catalog are returned. |
| `dataset-id`      | Only distributions under this dataset are returned.          |
| `metadata`        | Multiple metadata can be provided in form of `key='value'`. Only matching records are returned. |
| exclude           | One or more values from the below enum can be set to exclude them from output - `REPOSITORY`, `CATALOG`, `DATASET`, `DISTRIBUTION` and `NONE` (default). |
| include-directory | Boolean `true` value to mention if the directory and files created in DLS should be automatically mapped to datapoint and included in output. Default is `false`. |



### 11.6 Datapoint Provenance

Provenance is an operation on datapoint executed by a user through an API call. By default, all operation on these datapoints, would automatically recorded as provenance. 

> **Note**: There is no API to delete a provenance record.

#### 11.6.1 Get Provenance

The get provenance API helps to retrieve all provenance records for any specific repository. Following is the API -

```
GET https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}
```

If there is any records in the system, following response is returned.

```
[
  {
    "provenance": {
      "prov:atTime": "2021-04-07 18:52:25.844905",
      "prov:value": "repo-1",
      "prov:entity": "REPOSITORY",
      "prov:wasGeneratedBy": "RR1",
      "prov:event": "CREATED"
    },
    "links": [
      {
        "rel": "entity",
        "href": "https://[domain]/dls/datapoint/repository/repo-1"
      }
    ]
  }
]
```



Following the list of default attributes of provenance that DLS automatically generates :

| Attributes of Provenance | Description                                                  |
| ------------------------ | ------------------------------------------------------------ |
| `prov:entity`            | Datapoint types. E.g - REPOSITORY                            |
| `prov:value`             | The URI of datapoint identifiers which uniquely indexes the datapoint. |
| `prov:wasGeneratedBy`    | User who performed that operation                            |
| `prov:event`             | Type of operation. E.g - CREATED, UPDATED, DELETED, FETCHED  |
| `prov:atTime`            | Time when the operation was done.                            |

> Note : There can be custom provenance attributtes inserted by users using `POST` API mentioned below.



#### 11.6.2 Create Provenance

User can create additional provenance records for a particular datapoint. The attributes need to be borrowed from prov ontology. 

To add provenance for any repository -

```
PUT https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}
```

To add provenance for catalog, dataset or distribution -

```
POST https://[domain]/dls/datapoint/provenance/repository/{repositoryIdentifier}?catalog-id={catalogIdentifier}&dataset-id={datasetIdentifier}&distribution-id={distributionIdentifier}
```

Following the JSON payload that needs to be sent in request body -

```
{
  "custom": {
    "prov:additionalProp1": "string",
    "prov:additionalProp2": "string",
    "prov:additionalProp3": "string"
  },
  "prov:wasGeneratedBy": "string",
  "prov:atTime": "02-FEB-2020 20:02:20",
  "prov:event": "string",
  "prov:entity": "string",
  "prov:value": "string"
}
```

The `custom` attributes contains a map of additional provenance atributes which user can borrow from provenance ontology. `HTTP 205` is returned on successful creation of the record. 

If any of the datapoint identifiers does not exist, `HTTP 404` is returned. If the custom attribute keys are not part of `prov` prefix, `HTTP 409` with error message is returned.



### 11.7 Datapoint Metadata

The metadata already registered for any datapoint, can be updated. An existing metadata of any datapoint can be deleted as well.

#### 11.7.1 Update Metadata

To update an existing metadata of any datapoint, following API can be used.

```
PUT https://[domain]/dls/datapoint/metadata/repository/{repositoryIdentifier}
```

The URL parameters can be added to delete a specific catalog, dataset or distribution - `catalog-id`, `dataset-id`, `distribution-id`.

The JSON payload contains one or more custom metadata which gets added to the set of existing metadata.

```
{
  "dls:additionalProp1": "string",
  "foaf:additionalProp2": "string",
  "dcat:additionalProp3": "string"
}
```

If any of the metadata key is not in acceptable format, i.e the prefix used in the key name is not already known or registered in DLS, a `HTTP 409` with error message is returned. If all metadata is correct and acceptable, then `HTTP 207` is returned with JSON response payload, as below.

```
[
  {
    "key": "key",
    "value": "dls:additionalProp1",
    "messages": [
      "updated"
    ],
    "code": 205
  }
]
```



> **Important**
>
> If the metadata key already exists for this datapoint, then the value is updated. Otherwise, a new metadata is added to the existing metadata set. 



#### 11.7.2 Delete Metadata

To delete a metadata of any datapoint, use the below API

```
DELETE https://[domain]/dls/datapoint/metadata/repository/{repoIdentifier}?key={metadataKey}
```

If the above call is successful, `HTTP 204` is returned. It deletes the metadata identified by key name of this particular repository.

To delete metadata of catalog, dataset or distribution under this repository, following URL parameter can be used to identify the specific datapoint.

```
https://[domain]/dls/datapoint/metadata/repository/{repoIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]&key=[]
```

If the metadata is already deleted or could not be found, `HTTP 404` is returned.

### 11.8 Datapoint Permission

Permission once created for any datapoint can be updated. Permission can also be revoked. The retrieval, updation and deletion of permission of any datapoint is only accessible by the **datapoint creator (owner)**. For other users than the creator, `HTTP 403` is thrown. 

#### 11.8.1 Retrieve Permission

To retrieve the permission set for an existing datapoint, below API is used

```
GET https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

If permission exists following response is throws, otherwise `HTTP 404` is returned.

```json
[
  {
    "users": [
      "user1"
    ],
    "action": "RWD"
  }
]
```



#### 11.8.2 Update Permission

Permission can be added to an existing datapoint by calling the following API -

```
PUT https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

> Here `catalog-id`, `dataset-id`, `distribution-id` are optional and required to identify specific datapoint inside the repository.

The following JSON payload is sent in HTTP request body-

```
[
  {
    "users": [
      ""
    ],
    "action": "RWD"
  }
]
```

Following table provides an example of the action string set for a repository.

| `Permission` | `Description`                                                             |
|:-------------|:--------------------------------------------------------------------------|
| `R`          | User can view the repository metadata and catalog links                   |
| `W`          | User can create catalog in this repository and change repository metadata |
| `D`          | User can delete this repository                                           |

If successfully updated, `HTTP 205` is returned. If the username is not found, `HTTP 409` with proper message is thrown.



#### 11.8.3 Delete Permission

Using this API, all permissions already provided for a datapoint can be removed for all users. 

```
DELETE https://[domain]/dls/datapoint/permission/repository/{repositoryIdentifier}?catalog-id=[]&dataset-id=[]&distribution-id=[]
```

If deletion is successful, `HTTP 204` is returned.

​    

## 12. Metadata API
### 12.1 Manage Metadata
This API helps to add, update, delete one or more metadata for multiple files or directories in a single request.
If there is a requirement to add any arbitrary character in metadata value, this API should be used.
To add characters like `"` and `\`, these needs to be prepended with escape char `\`.


```
PUT https://[domain]/dls/metadata
```

**Request Body**
```json
[
  {
    "files": [
      "AA/admin1/1937/s1/pom.xml"
    ],
    "directories": [
      "/a1"
    ],
    "metadata": {
      "key1": "\"Microsoft\" 那是誰 ~ \\dir1\\dir2 & C$ , 'others' পথে こんにちは (Jap)"
    }
  }
]
```

> To delete an existing set of metadata from DLS, remove the `metadata` section from the payload.

**Response** 
```json
{
  "AA/admin1/1937/s1/pom.xml": "file metadata updated",
  "/a1": "directory metadata updated"
}
```

## 13. Appendix

### 13.1. List of Input Validation

Following table shows the input validation effective on the various fields passed in the API.

Note : Word characters are alpha-numeric and `_`

Note : Special characters for Timestamp are `:`, '-' and `.`

> Filename can not contain following characters `<` `>` `:` `"` `/` ` \ ` `|` `?` `*` `%`
> 
> Filename can contain whitespaces
> 
> All APIs which accept file URI as input, a standard file URI syntax validation for the above illegal characters is executed.

| Input Field             | Allowed Characters (Example Values)                                                                                                                  | Length                                       |
|-------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------|
| `organization`          | word and timestamp characters and single space between words (`TCS`, `TATA Consultancy Service`, `52 North`, `www.tcs.com`, ) at least one character | Min = 3, Max = 100                           |
| `user name`             | user names with word characters, `.` and valid email Id                                                                                              | Max = 50                                     |
| `organization-position` | `organization` followed by `/` and a name of position (word characters)                                                                              | Max = 500                                    |
| `filename`              | Case in-sensitive.                                                                                                                                   | Max=255                                      |
| `savepoint`             | Word and timestamp characters, numeric-only name is not allowed                                                                                      | Max=50                                       |
| `metadata.key`          | Word character. Case in-sensitive.                                                                                                                   | Max=150                                      |
| `metadata.value`        | Following characters are not allowed - `'`, `"`, `*`, `,`, `=`, `&`, `!`                                                                             | Max=255                                      |
| `metadata.type`         | Either `TEXT` or `NUMERIC`                                                                                                                           |                                              |
| `action`                | Combination of `R`, `W`, `D`. Case in-sensitive.                                                                                                     | Max=3                                        |
| `enforcement`           | Either of `STRICT` or `STANDARD`                                                                                                                     |                                              |
| `directory`             | Prepend `/` in each directory and sub-directory                                                                                                      | Directory name max 255, path max length 1024 |

> Directory name can not contain following characters - `#` `%` `&` `{` `}` `\ `   `<` `>` `*` `?` `$` `!` `'` `"` `:` `@` `+` `|` `=` and `
>
> Directory can contain whitespace


> Case-sensitive attributes can not have same value in DLS with different cases, e.g - metadata name in schema `key1`, Key1` and `KEY1` are considered same.
