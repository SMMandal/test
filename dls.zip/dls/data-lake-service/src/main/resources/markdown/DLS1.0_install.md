﻿# Data Lake Service
> Service Version 2.0 
**Installation Guide**
Doc Revision No 2

## Migrate to DLS 11
To migrate the DLS database schema from R10 to R11, execute `conf/alter.sql` script using PGAdmin or PSQL CLI on the existing R10 `dls` database.
## Hardware Requirement
DLS server 1 node with 4-core CPU , 8 GB RAM, 500 GB Disk space <br>
Hortonworks HDP Cluster of 10 nodes; each having VM 4-core CPU, 8 GB RAM

## Software Requirement
Open JDK 11, Hadoop 3 (Hortonworks HDP 3.1.x), Postgres 12.x


## Installation Procedure


1. Create DLS user

```
sudo -u postgres createuser dlsusr
sudo -u postgres psql
alter user dlsusr with encrypted password 'dls';
```


2. Create a database called `dls` by running the following SQL query,

```
CREATE DATABASE dls WITH OWNER = dlsusr
```
**To create R10 Tables :**

Run the following SQL script to newly create the tables for R10 - `schema.sql`

**To create R11 Tables :**

Run the following command -
```
sudo -u postgres psql -d dls -W -f  dls11.sql
```

**To migrate from R10 to R11**, run only `alter.sql`

### Enable Hadoop WebHDFS

Install Hadoop and add following `property` in `hdfs-site.xml` file

		<property>
			<name>dfs.webhdfs.enabled</name>
			<value>true</value>
		</property>


### Build DLS from Source
Build the package from source code by running the following command in `data-lake-service` directory of source :

```
mvn clean package -Dhost=[DLS_server_internal_IP] -DdbHost=[postgres_server]  -DhadoopHost=[namenode] -DswaggerHost=[public_address] -DhdfsUser=[HDFS user] -DwebHdfsUrl=[https://Knox_External_IP:8443/gateway/default] -DfailsafeDir=[local_directory] -DbundlePathDir=[local_directory] -DadminKey=[tcup admin api key] -DbuildNo=[buildNo] -DhadoopAuth=[SIMPLE or KERBEROS] -DenableHDFS=[true or false]
```

To skip unit test while building add `-DskipTests` in above maven build command.
  
> `failsafeDir` is a local directory in DLS server with write permission  
> The size of `failsafeDir` should be more than the `'maximum of concurrent users' X 'max size of each file'` 

If the build is successful, a package will be generated. Open it by - <br> 
`tar -xvzf target/dls-1.0-bin.tar.gz`

Following directories and files will be extracted under `dls-1.0` installed directory - <br>

	/bin/start.sh
	/doc/DLS1.0_apidoc.md
	/conf/logback.xml
	/conf/dls.properties
	/lib/dls-1.0.jar
	/logs/

> **Important:** 
> Go to `dls.properties` and modify the line as
` dls.swagger-host=dev.tcupiot.com`

### Start & Stop DLS

To start DLS, use the following command from installed directory `dls-1.0/bin`,  run the following command - <br>
`./start.sh --spring.datasource.password=dls` or, <br> 
`./start.sh --server.port=8080 --spring.datasource.password=dls`

> By default, DLS starts on 8080, if the port needs to be changed, give a different port number <br>
> Give Postgres database password for user `dlsusr`

Shutdown DLS service gracefully by -<br>

`curl -X POST http://[dls_server]:[dls_port]/api/dls/v2.0/shutdown`
> `{"message":"Shutting down, bye..."}` will be shown.

## Kerberos
To enable DLS to connect a Kerberos-enabled HDFS, make sure `krb5.conf` file is copied inside `dls-1.0/conf` directory.
Also make sure the `dls.keytab` exists in `/etc/security/keytabs/` directory.
### Optional Configuration
Increase heap memory of DLS by editing `start.sh` file and change the values of `-Xms512m -Xmx1024m`


> **Important Note**
>TCUP release 11 onwards, the REST URL context root of DLS is changed to `/api/dls/v2.0` instead of `/dls`. 
>To reset it to previous value, change the `server.servlet.context-path` property in `dls.properties` file. 