
update file set deleted = false where deleted is null;
update file set external = false where external is null;