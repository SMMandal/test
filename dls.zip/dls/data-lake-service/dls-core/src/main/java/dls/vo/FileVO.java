package dls.vo;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import com.vladmihalcea.hibernate.type.json.JsonNodeStringType;
import dls.service.SecretConverterHelper;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.Type;

import java.sql.Timestamp;
import java.util.List;

@Table(
	    uniqueConstraints= {
	    		@UniqueConstraint(name="uk_file", columnNames={"fsPath", "deletedOn"})
	    }       
	)
@AllArgsConstructor

/*@TypeDefs({
		@TypeDef(
				name = "string-array",
				typeClass = StringArrayType.class
		),
		@TypeDef(
				name = "json-node",
				typeClass = JsonStringType.class
		)
})*/
public @Entity(name="file") @Data @Builder class FileVO {

	public FileVO() {super();}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@ManyToOne(targetEntity=UserVO.class) 
	private UserVO user;
	private String fileName;
	private String savepoint;
	private Long sizeInByte;	
//	@CreationTimestamp
	private Timestamp createdOn;
	private String fsPath;
	private Boolean bundled;
	private Boolean uploaded;
	private String uploadStatus;
	private Boolean external;
	private Boolean deleted;
	@OneToMany(cascade={CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH, CascadeType.DETACH},mappedBy="file")
	@ToString.Exclude
	private List <FileMetaVO> meta;	
	private Timestamp deletedOn;
//	@Type( type = "string-array" )
	@Column(name = "shared_to", columnDefinition = "TEXT[]")
	@Type( StringArrayType.class )
	private String [] sharedTo;

	@Type(JsonNodeStringType.class)
	@Column(columnDefinition = "json")
	private String bundle;
	@Column(columnDefinition = "char(2)", length = 2)
	private char [] lock;
//	@Column(columnDefinition = "TEXT []")
	@Type( StringArrayType.class )
	private String [] qualifier;
	@ManyToOne
	private DirectoryVO directory;
	
	@Convert(converter = SecretConverterHelper.class)
	private String bundleHash;

	/**
	 * storage location of the file
	 * 'H' - hadoop
	 * 'L' - local
	 * define other codes, if necessary
	 */
	@Column(length = 2)
	private String storage;



}
