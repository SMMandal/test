package dls.vo;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import org.hibernate.annotations.Type;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

@Entity(name="catalog")

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString


public class CatalogVO implements Serializable {
    @Id
    private Long id;
    private char type;
    private String name;
    private String path;
    private String parent;
    private Long size;
    private Integer fileCount;
    private Integer subdirCount;
    private Timestamp createdOn;
    private String createdBy;
    private String savepoint;
    private Boolean uploaded;
    private String uploadStatus;
    private String lock;
    private Boolean bundled;
    @Type( StringArrayType.class )
    private String[] qualifier;
    @Type( StringArrayType.class )
    private String[] sharedTo;

//    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "typeId")
//    @JoinColumn(name = "typeId")
//    @Transient
//    private List<MetadataViewVO> metadata;

    @Column(columnDefinition = "BIGINT []")
    @Type( LongArrayType.class )
    private Long [] metadataIds;
    @Type(JsonBinaryType.class)
    @Column(columnDefinition = "jsonb", name = "metadata_json")
    private List<Metadata> metadataList;

    @Type(JsonBinaryType.class)
    @Column(columnDefinition = "jsonb", name = "metadata")
    private Map<String, Object> metadata;

    @Column(columnDefinition = "BIGINT []")
    @Type( LongArrayType.class )
    private Long[] permittedUsers;

    private Integer tenantId;

    public record Metadata (String name, String value, Long createdBy, Long privateTo) {

    }
}
