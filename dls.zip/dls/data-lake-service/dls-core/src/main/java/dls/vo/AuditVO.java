package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Data
@Builder
@Entity(name = "audit")
@AllArgsConstructor
@NoArgsConstructor
public class AuditVO {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
    @SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

    private Long id;
    private String entity;
    private Long entityId;
    private String event;
    private Boolean success;
    private Timestamp eventTime;
    @ManyToOne(targetEntity=UserVO.class)
    private UserVO user;
    private String provenance;
}
