package dls.vo;

import lombok.*;
import org.hibernate.annotations.Immutable;

import jakarta.persistence.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "metadata_view")
@Immutable
@ToString

public class MetadataViewVO {
    @Id
    private Long id;
    private String type;
    private Long typeId;
    private String name;
    private String value;
    private String createdBy;
    private Long schemaId;
    private Long privateTo;
//    @ManyToOne
//    @JoinColumn(name = "id", insertable = false, updatable = false)
//    private ExplorerViewVO explorerView;


}
