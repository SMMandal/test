package dls.vo;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;
import com.vladmihalcea.hibernate.type.json.JsonNodeStringType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.Type;

import java.sql.Timestamp;
import java.util.List;

import static jakarta.persistence.CascadeType.*;

@Table(
	    uniqueConstraints= {
	    		@UniqueConstraint(name="uk_file", columnNames={"fsPath", "deletedOn"})
	    }       
	)
@AllArgsConstructor

public @Entity(name="catalog_text_search") @Data @Builder class CatalogTextSearchVO {

	public CatalogTextSearchVO() {super();}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)
	@Column(name = "id")
	private Long id;
	@ManyToOne(targetEntity=UserVO.class) 
	private UserVO user;
	private String fileName;
	private String savepoint;
	private Long sizeInByte;	
//	@CreationTimestamp
	private Timestamp createdOn;
	private String fsPath;
	private Boolean bundled;
	private Boolean uploaded;
	private String uploadStatus;
	private Boolean external;
	private Boolean deleted;



	@OneToMany(cascade={PERSIST, MERGE, REMOVE, REFRESH, DETACH} ,mappedBy="file")
	@ToString.Exclude
	private List <CatalogMetaVO> meta;



	private Timestamp deletedOn;
//	@Type( type = "string-array" )




	@Column(name = "shared_to", columnDefinition = "varchar(255)[]")
	@Type( StringArrayType.class )
	private String [] sharedTo;

	@Type(JsonNodeStringType.class)
	@Column(columnDefinition = "json")
	private String bundle;
	@Column(columnDefinition = "char(2)", length = 2)
	private char [] lock;
	@Column(columnDefinition = "varchar(50)[]")
	@Type( StringArrayType.class )
	private String [] qualifier;
	@ManyToOne
	private DirectoryVO directory;
	@Type( LongArrayType.class )
	private Long[] acquiredUser;
	private String action;

	/**
	 * storage location of the file
	 * 'H' - hadoop
	 * 'L' - local
	 * define other codes, if necessary
	 */
	@Column(length = 2)
	private String storage;



}
