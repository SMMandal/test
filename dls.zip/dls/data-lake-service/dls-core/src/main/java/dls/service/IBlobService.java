package dls.service;

public interface IBlobService {
	String getBlobURL(String blobPath);
}
