package dls.repo;

import dls.vo.RelationVO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RelationRepo extends JpaRepository<RelationVO, Long> {
}
