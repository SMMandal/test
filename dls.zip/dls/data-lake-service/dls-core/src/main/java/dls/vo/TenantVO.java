package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import jakarta.persistence.*;
@Table(
	    uniqueConstraints={
	        @UniqueConstraint(name="uniqKey", columnNames={"apiKey"}),
	        @UniqueConstraint(name="uniqtcupuser", columnNames={"tcupUser"})
	        }
	)
@AllArgsConstructor
public @Entity(name="tenant") @Data @Builder class TenantVO {

	public TenantVO() {}
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)
    private Long id;   
	@Column(nullable=false)
	private String apiKey;
	@Column(nullable=false)
	private String tcupUser;
	private Boolean admin;
	private Integer maxMetaPerFile;
	private Integer maxKeyLen;
	private Integer maxValueLen;
	private Boolean allowAdhoc;
	private Boolean schematic;
	private String organization;
	private Long allocatedStorage;
	private Long usedStorage;
}
