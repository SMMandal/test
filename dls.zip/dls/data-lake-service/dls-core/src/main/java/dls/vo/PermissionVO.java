package dls.vo;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;

@AllArgsConstructor
@NoArgsConstructor

/*@TypeDefs({
	@TypeDef(
			name = "long-array",
			typeClass = LongArrayType.class
	)
})*/


public @Entity(name="permission") @Data @Builder class PermissionVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@ManyToOne(targetEntity=UserVO.class)
	private UserVO user;
	private Long permittedUser;
	@Transient
	private String permittedUserName;
	@Type( LongArrayType.class)
	@Column(
			name = "acquiredUser",
			columnDefinition = "bigint[]"
	)
	private Long[] acquiredUser;
	@ToString.Exclude
	@ManyToOne
	private DirectoryVO directory;

	private String action;
	@ManyToOne
	private TenantVO tenant;
}
