package dls.vo;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;

@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Table(name="file_meta")
public @Entity @Data @Builder class CatalogMetaVO extends AbstractFileMetaVO{

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	@Column(name = "id")
	private Long id;

	private String name;
	private String value;
	private Double value_numeric;
	@ManyToOne(targetEntity=UserVO.class)
	private UserVO user;
//	@Column(columnDefinition = "varchar(50)[]")
	@Type( StringArrayType.class )
	private String [] qualifier;
	@ManyToOne(cascade = CascadeType.ALL)
	private MetaSchemaVO schema;

	@ToString.Exclude
	@ManyToOne
	private CatalogTextSearchVO file;

}
