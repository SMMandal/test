package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import jakarta.persistence.*;
@AllArgsConstructor

@Table(
	    uniqueConstraints= {
	    		@UniqueConstraint(name="uk_link", columnNames={"lhs_file_id", "relation", "rhs_file_id"})
	    }       
	)
public @Data @Entity(name="link") @Builder class LinkVO {

	public LinkVO(){}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@OneToOne
	private FileVO lhsFile;
	private String relation;	
	@OneToOne
	private FileVO rhsFile;
	@ManyToOne(targetEntity=UserVO.class) 
	private UserVO user;
}
