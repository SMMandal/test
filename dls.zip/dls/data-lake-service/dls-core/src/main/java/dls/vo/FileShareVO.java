package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Table(
	    uniqueConstraints= {
	    		@UniqueConstraint(name="uk_access", columnNames={"file_id", "user_id"})
	    }       
	)
@AllArgsConstructor
public @Data @Entity(name="file_share") @Builder class FileShareVO {

	public FileShareVO() {}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@OneToOne
	private FileVO file;
	@OneToOne
	private UserVO user;
	private Timestamp sharedOn;

}
