package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FileSearchCriteria implements Serializable {

	private UserVO userVO;
	private String text;
	private Timestamp fromTime;
	private Timestamp toTime;
	private Long sizeInByte;
	private String sizeCheckOperator;
	private Boolean external;
	private Boolean transferred;
	private Boolean deleted;
	private Boolean ownFile;
	private Boolean bundled;
	private Boolean locked;
	private String metadata;
	private String filename;
	private String savepoint;
	private String uri;
	private String sort;
	private Long directoryId;
	private Boolean findInRootDirectory;


	public enum AndOrEnum {
		AND,OR
    }
}
