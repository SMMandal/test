package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Table(
	    uniqueConstraints={
	        @UniqueConstraint(name="uniqDirMetaKey", columnNames={"name", "directory_id", "isMeta"})
	        }
	)
@AllArgsConstructor
@NoArgsConstructor


public @Entity(name="directory_meta") @Data @Builder class DirectoryMetaVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)
	private Long id;
	@ManyToOne
	private DirectoryVO directory;
	private String name;
	private String value;
	private Double value_numeric;
	@ManyToOne(targetEntity=UserVO.class)
	private UserVO user;
	private Boolean deleted;
	private Timestamp deletedOn;
	private String type;
	private Boolean value_mandatory;
	@Builder.Default
	private Boolean isMeta = false;
	@ManyToOne(cascade = CascadeType.ALL)
	private MetaSchemaVO schema;

}
