package dls.vo;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;

@Table(
	    uniqueConstraints={
	        @UniqueConstraint(name="uniqKey", columnNames={"tenant_id", "dlsKey"}),
	        @UniqueConstraint(name="uniqdlsuser", columnNames={"tenant_id", "dlsUser"})
	        }
	)
@AllArgsConstructor
@NoArgsConstructor

/*@TypeDef(
		name = "string-array",
		typeClass = StringArrayType.class
)*/

public @Entity(name="users") @Data @Builder class UserVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)
    private Long id;
	@ManyToOne
	private TenantVO tenant;
	@Column(nullable=false)
	private String dlsKey;
	@Column(nullable=false)
	private String dlsUser;
	private Boolean admin;
	@Type( StringArrayType.class )
	@Column(columnDefinition = "text[]")
	private String [] orgPosition;
	@OneToOne
	private UserVO lastUpdatedBy;
	@UpdateTimestamp
	private Timestamp lastUpdatedOn;
}
