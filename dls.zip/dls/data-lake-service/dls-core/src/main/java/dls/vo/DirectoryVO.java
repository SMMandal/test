package dls.vo;

import lombok.*;

import jakarta.persistence.*;
import java.sql.Timestamp;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@ToString

public @Entity(name="directory") @Data @Builder class DirectoryVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)
	private Long id;
	private Timestamp createdOn;
	private Boolean deleted;
	private String directory;
	@ManyToOne(targetEntity=UserVO.class) 
	private UserVO createdBy;
	private Timestamp deletedOn;
	private Long parent;
	@OneToMany
	@JoinColumn(name = "directory_id")
	private List<FileVO> files;
	@ManyToOne
	private TenantVO tenant;
	@OneToMany
	@JoinColumn(name = "directory_id")
	@ToString.Exclude
	private List<PermissionVO> permission;
	private String enforcementType;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "directory_id")
	private List <DirectoryMetaVO> directoryMetaVOList;

}
