package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.sql.Timestamp;

@AllArgsConstructor
@NoArgsConstructor


@Table(
		uniqueConstraints= {
				@UniqueConstraint(name="uk_timestamp", columnNames={"createdOn","user_id"})
		}
)

public @Entity(name="comment") @Data @Builder class CommentsVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@ManyToOne(targetEntity=FileVO.class)
	private FileVO file;
	private String comment;
	@ManyToOne(targetEntity=UserVO.class)
	private UserVO user;
	@ManyToOne
	private TenantVO tenant;
	private Timestamp createdOn;
}
