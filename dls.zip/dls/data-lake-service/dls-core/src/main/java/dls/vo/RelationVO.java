package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.sql.Timestamp;


@Table(
	    uniqueConstraints={
	        @UniqueConstraint(name="uniqRelationKey", columnNames={"relationshipName"})
	        }
	)

@AllArgsConstructor
@NoArgsConstructor


public @Entity(name="relation") @Data @Builder class RelationVO {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	/*
	 * @ManyToOne(targetEntity=TenantVO.class,cascade=CascadeType.MERGE,fetch=
	 * FetchType.EAGER)
	 * 
	 * @JoinColumn(nullable = false )
	 */
	@Column(nullable=false)
	private String relationshipName;
	private String description;
	private Boolean deleted;
	private Timestamp deletedOn;
	
}
