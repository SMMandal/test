package dls.vo;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import org.hibernate.annotations.Type;


@MappedSuperclass
public class AbstractFileMetaVO {

	public AbstractFileMetaVO() {}

}
