package dls.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Table(
	    uniqueConstraints={
	        @UniqueConstraint(name="uniqMetaKey", columnNames={"name", "tenant_id"})
	        }
	)

@AllArgsConstructor
@NoArgsConstructor


public @Entity(name="meta_schema") @Data @Builder class MetaSchemaVO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator = "hibernate_sequence")
	@SequenceGenerator(name = "hibernate_sequence", sequenceName = "hibernate_sequence", allocationSize = 1)

	private Long id;
	@ManyToOne(targetEntity=TenantVO.class,cascade=CascadeType.MERGE,fetch=FetchType.EAGER)
	@JoinColumn(nullable = false )
	private TenantVO tenant;
	@Column(nullable=false)
	private String name;
	@Column(nullable=false)
	private String type;
	private String description;
	private Boolean deleted;
	private Timestamp deletedOn;

}
